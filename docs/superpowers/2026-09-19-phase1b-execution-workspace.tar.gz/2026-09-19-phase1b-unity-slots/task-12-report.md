# Task 12 report — unblock the offline path, and stop losing a failed worker's work

Branch `fix-outbox-dedup-and-evidence`, off `main` at `bdd3dd8`. Suite went from **280** to **295** tests,
green and warning-free under `python3 -W error -m unittest discover -s tests`.

---

## Fix A — a second work item on one issue cannot finish

### Which shape I chose, and why

**Shape 3, with shape 2's loudness folded into it as data rather than as an exception, plus two things the
brief's statement of shape 3 does not contain: an `issue_id` fence in `finish`, and a takeover path for an
outbox row that was prepared but never posted.**

Shape 2 on its own is not sufficient and the brief says so. But I did not pair it with `finish` as a *raised*
error either, for a concrete reason: if `prepare_comment` raises, the worker never learns the `action_id` of
the comment that already exists, and `finish` requires one. The worker would have to parse it out of an error
string. That is a fragile contract to hand an LLM on the exact path we are trying to stop stalling.

So the refusal is returned rather than raised: `prepare_comment` still answers with the existing row, but the
answer now carries `"deduplicated": true`, and the row's own `item_id` names the item that posted it. The
worker's existing script — `prepare-comment` → `post-comment` → `finish` — works end to end with no change to
the sequence, because `post-comment` on an already-confirmed row is a no-op and `finish` now accepts it. That
is shape 3's behaviour with shape 2's honesty, and it required no new worker step.

### Was your reasoning wrong anywhere? Yes, in one place — and it matters

> *"a different conclusion produces a different `kind`, hence a different `action_id`, hence no clash."*

**This is false.** `kind` is `CHECK(kind IN ('started','blocker','delivery'))` — three values, and it encodes
the *outcome class*, not the conclusion. Enumerating what two items can legitimately reach:

| `kind` | can two items reach it with materially different content? |
|---|---|
| `started` | Yes, but it does not matter: a start marker states no conclusion, and announcing an unchanged issue twice is exactly the spam the key exists to stop. |
| `blocker` | **Yes.** Item 1 blocks on "needs a release decision on the config export"; item 2 blocks on "cannot reproduce, need device logs". Same kind, same `action_id`, completely different thing for a reader to act on. |
| `delivery` | **Yes.** A PR delivery and a `no_change` delivery are both `kind="delivery"`. `finish` validates them differently (`no_change` vs a nonempty `prs`) but the outbox does not distinguish them at all. Two different PRs collide the same way. |

So a plain shape 3 does weaken something: the item's terminal evidence stops being attributable to the item's
own words, and when the words differ, the second worker's actual conclusion is discarded with no trace. That
is Finding 1's failure mode — a claim that cannot be adjudicated — arriving through a different door.

It does **not** make shape 3 wrong, because the alternative is worse. I checked the obvious repair, *dedup on
the body so that only identical comments collapse*, and rejected it: two LLM workers reaching the same verdict
never write byte-identical text, which is exactly what happened on FARM-1238. Body-keyed dedup would let every
operator re-run post a near-duplicate comment — the spam the key was chosen to prevent — while catching almost
nothing. Worth recording so the next person does not re-derive it.

The repair I did make: when the dedup fires on a **conclusion** (`blocker` or `delivery`) and the body differs
from what is already posted, the second item's own words are written to `audit.details.suppressed_body`
(capped at 2000 chars). The issue gets one comment; the ledger keeps both conclusions. An operator asking what
the second worker actually concluded gets an answer instead of silence.

### A second thing the brief's shape 3 would have got wrong

Shape 3 as stated is "accept a confirmed outbox row matching this item's `(issue, fingerprint, generation,
kind)` even when `item_id` differs". Implemented as *drop the `item_id` clause* — the natural reading of the
diff — it opens a hole, because the old check had no `issue_id` clause: `item_id` was carrying that duty
implicitly. `_fingerprint` is hashed from title, description, attachments and comments and **never from the
issue id**, so two issues with the same text share a fingerprint, and a comment confirmed on one issue would
then satisfy `finish` on the other. `issue_id` is now checked explicitly. `test_finish_still_refuses_a_
confirmed_comment_from_another_issue` fails if you remove it (mutation M1).

### A third case the brief did not name: the unposted row

If item 1 prepares a blocker and dies before posting it, the row exists with `remote_id IS NULL`. A pure
shape 3 leaves item 2 exactly as stuck as before: it cannot post the row (it is not its), and `finish` refuses
it (never confirmed). That is Fix A's bug wearing a different hat, and an operator `enqueue` after a crashed
worker is not an exotic path. So: **an unconfirmed row whose owner is no longer active is handed over** — its
`item_id` and `body` become the live item's, the `action_id` and marker are unchanged, and the item posts its
own words normally. Nothing was on the issue, so nothing can be double-posted. It is safe because
`one_active_item_per_issue` means two items on one issue are never running at once; the guard re-states that
rather than trusting it.

### What changed

- **`agent/ledger.py` `prepare_comment`** — three cases instead of two. Own row or no row: unchanged. Foreign
  unconfirmed row with an inactive owner: taken over. Foreign confirmed row: borrowed, `deduplicated: true`,
  audited, diverging conclusion text preserved. The return value gains a `deduplicated` key in every case.
- **`agent/ledger.py` `finish`** — `action["item_id"] != row["id"]` replaced by `action["issue_id"] !=
  row["issue_id"]`. Fingerprint, generation, kind and `remote_id` fences unchanged. A borrowed row writes an
  `audit` row (`finish` / "cited a comment another item posted") so the substitution is never silent.
- **`agent/__main__.py` `owned_action`** — `post-comment` and `confirm-comment` were scoped by `item_id`, so
  the relaxed `finish` alone would still have stalled the worker one step earlier. Now scoped by the item's
  own issue, claimed fingerprint and generation, joined from `work_items`. This is the same authority (a
  running worker may speak for its issue at the input it claimed) and it still refuses a row from another
  issue — `test_post_comment_refuses_an_action_id_from_another_item` uses `OTHER` and still passes.
- **`skills/fix/SKILL.md`** — five lines telling a worker what `"deduplicated": true` means and that it must
  not describe a borrowed comment as one it posted. Without this the fix would close the ledger hole and leave
  Finding 1's reporting hole open on the same path.

The dedup itself is untouched: the key is still `issue:fingerprint:generation:kind`, `generation` is not
repurposed, and `Ledger` still imports no `subprocess` and no `os`.

---

## Fix B — a failed item's work is swept away

- **`agent/worktrees.py` `commit_wip(item_id, message)`** — for each repository worktree of an item: skip if
  `git status --porcelain=v1` is clean, `git add --all -- .`, skip if nothing staged, commit with an explicit
  `-c user.name=FarmBot -c user.email=farmbot@localhost` identity and `--no-verify`. Returns
  `{"committed": {repo: sha}, "errors": {repo: message}}`. Per-repository failures are collected, never
  raised. **Commit only, never push.**
  - A **detached** worktree (what read-only skills get from `add_detached`) is switched to
    `farmbot/wip/<item>` first, because a commit on a detached head is referenced by nothing and
    `worktree prune` would sweep it as surely as the files it was meant to preserve. The branch is created
    *after* the staged-diff check, so a worktree with nothing to keep leaves no stray ref.
- **`agent/scheduler.py` `_retire(item_id, state)`** — the single chokepoint in front of
  `worktrees.remove`. Commits only when `state == "failed"`, wraps the commit so it can neither mask the
  failure nor stop the sweep, and logs `{"event": "wip_commit", ...}` or `{"event": "wip_commit_failed", ...}`
  as a JSON line on the same stdout surface `service.serve` already uses. Message:
  `wip(<first 8 of item id>): worker exited without finishing`.
- The three call sites that removed worktrees now go through it: `_reap`, `_recover`'s claim-timeout branch,
  and `_sweep_worktrees`. `_recover`'s lease-expiry branch has no removal of its own and is picked up by
  `_sweep_worktrees` in the same tick, so that path is covered too. `_fail_launch` is deliberately left alone:
  no worker ran, so there is nothing to preserve, and its `remove` is already best-effort.

---

## Deferred, as the brief directs

**No mechanism for `finish` to verify a worker's claims against git.** `Ledger` cannot run git by design, the
CLI's `finish` verb does not know the item's branch, and only the scheduler does; that plumbing is larger than
this task. Fix B removes most of its motivation by preserving the evidence instead — the claim on FARM-1238
would now be adjudicable after the fact, from a commit on the item's own branch in FarmBot's clone.

---

## Tests

New tests, 15 in total (280 → 295).

**`tests/test_ledger.py` — new class `SecondItemOnOneIssueTests` (7)**

- `test_a_second_item_reaching_the_same_verdict_finishes_instead_of_stalling` — the live sequence: the second
  item reaches `blocked`, one blocker row exists for the issue, the first item is untouched.
- `test_a_suppressed_second_conclusion_is_kept_in_the_audit_trail`
- `test_a_started_marker_and_an_identical_conclusion_keep_no_suppressed_body`
- `test_an_unposted_row_from_a_dead_item_is_handed_to_the_item_that_can_still_post_it`
- `test_finish_still_refuses_a_confirmed_comment_from_another_issue`
- `test_finish_still_refuses_a_confirmed_comment_from_an_earlier_generation`
- `test_finish_still_refuses_a_comment_of_the_wrong_kind_or_one_never_posted`

**`tests/test_cli.py` (1)**

- `test_a_second_item_on_one_unchanged_issue_finishes_without_posting_twice` — the same sequence through the
  CLI a worker actually drives, against the Linear stub: exactly one `create_comment` call.

**`tests/test_worktrees.py` (4, against real `git` and a real temporary origin)**

- `test_commit_wip_commits_a_failed_items_work_to_its_branch` — and the commit survives `remove`, in the clone.
- `test_commit_wip_makes_no_commit_without_work_and_none_at_all_without_a_worktree`
- `test_commit_wip_puts_a_detached_worktrees_work_on_a_branch_of_its_own`
- `test_commit_wip_reports_a_broken_worktree_and_still_commits_the_others`

**`tests/test_scheduler.py` (3)**

- `test_a_failed_items_work_is_committed_before_its_worktrees_are_swept`
- `test_a_delivered_item_is_swept_without_a_work_in_progress_commit`
- `test_a_failing_work_in_progress_commit_is_logged_and_still_sweeps`

### Failing first

Baseline before any change:

```
$ python3 -W error -m unittest discover -s tests
Ran 280 tests in 73.974s
OK
```

The defect itself, reproduced against the unmodified ledger (scratch script, `python3 -B`):

```
same action_id: True | row belongs to item one: True
finish REFUSED: finish requires a confirmed comment for this item, claimed input and outcome
state of item two: running
```

`running` is the stall: the worker exits 0 and the scheduler reaps it as `failed`. Exactly the rehearsal.

With the tests written and no implementation:

```
$ python3 -W error -m unittest discover -s tests -k SecondItemOnOneIssue
Ran 7 tests ... FAILED (failures=2, errors=2)     # KeyError: 'deduplicated'; 0 != 1 audit rows
$ python3 -W error -m unittest discover -s tests -k commit_wip
Ran 4 tests ... FAILED (errors=4)                 # AttributeError: 'Worktrees' object has no attribute 'commit_wip'
$ python3 -W error -m unittest discover -s tests -k second_item_on_one_unchanged
Ran 1 test  ... FAILED (errors=1)                 # KeyError: 'deduplicated'
$ python3 -W error -m unittest discover -s tests -k committed_before
Ran 1 test  ... FAILED (failures=1)               # ('committed', <id>, 'wip(...)...') not in trees.added
$ python3 -W error -m unittest discover -s tests -k work_in_progress
Ran 2 tests ... FAILED (failures=1)               # 'wip_commit_failed' not found in ''
```

The 3 `SecondItemOnOneIssueTests` that passed at this point are the fence tests — they assert behaviour that
must *survive* the relaxation, so passing first is correct. `-k` selections were counted, not assumed: none of
them printed `NO TESTS RAN`.

### Final

```
$ python3 -W error -m unittest discover -s tests
Ran 295 tests in 74.387s
OK

test_ledger      Ran 67 tests
test_cli         Ran 16 tests
test_worktrees   Ran 24 tests
test_scheduler   Ran 35 tests
```

---

## Mutations

Run with `python3 -B`, every `__pycache__` cleared before each run, and each file **copied aside and copied
back** — no `git checkout` anywhere near this working tree.

| | mutation | result |
|---|---|---|
| M1 | `finish`: drop the `issue_id` fence | CAUGHT |
| M2 | `finish`: put the `item_id` fence back | CAUGHT |
| M3 | `prepare_comment`: never report a dedup | CAUGHT |
| M4 | `prepare_comment`: take over a confirmed row too | CAUGHT |
| M5 | `prepare_comment`: drop the suppressed body | CAUGHT |
| M5b | `prepare_comment`: keep a `started` marker's words too | CAUGHT |
| M6 | `commit_wip`: leave a detached head detached | CAUGHT |
| M7 | `commit_wip`: drop the `status` guard | **SURVIVED** |
| M7b | `commit_wip`: drop the staged-diff guard | **SURVIVED** |
| M7c | `commit_wip`: drop **both** | CAUGHT |
| M8 | `_retire`: commit for every terminal state | CAUGHT |
| M9 | `_retire`: sweep before committing | CAUGHT |
| M10 | `owned_action`: scope by `item_id` again | CAUGHT |

M7 and M7b are redundant by design and I kept both knowingly: the requirement ("an empty worktree must not
produce an empty commit") is covered — M7c proves the pair is load-bearing — but either guard alone satisfies
it. The first exists so a clean worktree never pays for `git add --all`, which walks the whole index and a
Farm-Client worktree is gigabytes; the second because the two calls are not one atomic act and the worker's
processes have only just been killed. The comment now says exactly that, so the survivors are documented
rather than mysterious.

---

## Self-review findings

Things I found reviewing my own diff, and what I did:

1. **`owned_action` was the real second half of Fix A.** Relaxing `finish` alone would have moved the stall
   from `finish` to `post-comment` one step earlier, and I would have shipped a fix that passes a ledger test
   and still fails a live worker. Caught by writing the CLI test before the ledger implementation.
2. **The detached-branch creation was originally before the staged-diff check**, so an item whose worktree had
   nothing worth keeping would still have left a `farmbot/wip/<item>` ref behind in the clone. Reordered.
3. **The `issue_id` fence is not cosmetic.** My first instinct was that the `action_id` hash already contains
   the issue id, so the fence was redundant. It is not: `finish` looks the row up *by the caller's*
   `action_id`, and fingerprints do not contain the issue id, so two same-text issues are a real (if narrow)
   path. M1 is the proof.
4. **`suppressed_body` on a `started` marker was noise** in the first implementation — up to 2000 characters
   of "FarmBot has started" recorded for every re-run. Restricted to conclusions.
5. **The takeover updates `created_at`.** It reorders `Ledger.outbox()` output, which is sorted by
   `created_at, action_id`. Deliberate: the row now genuinely belongs to this item and was written now.
6. **`_retire` runs twice in one tick** for a freshly-failed item — once from `_reap`, once from
   `_sweep_worktrees`. Pre-existing (`remove` was already called twice) and harmless: the second
   `commit_wip` finds no directory and returns immediately without logging.

### Concerns I am leaving on the table

- **`git add --all` stages anything a repository does not ignore.** On a failure path that is the point, but a
  worker that left large untracked build output outside `.gitignore` would commit it into FarmBot's bare
  clone. Bounded by the repositories' own ignore rules; worth a look if a clone starts growing.
- **Nothing pushes the wip branch.** That is the brief's instruction and I agree with it, but it means Fix B's
  evidence is host-local — the same property Finding 5 complains about for blocked-path SHAs. An operator
  reading a `wip_commit` log line has to be on this machine to look at it.
- **Fix A is proven in tests, not live.** The whole reason it exists is that Task 11's `enqueue` path could
  not reach a terminal state; that rehearsal is still owed, and it is the only thing that will show whether a
  real worker reads `"deduplicated": true` and reports it honestly.

---

# Fix round 1 — review findings 1, 2 and 3

All three fixed. Suite **295 → 302**, green and warning-free. No disagreements: all three findings
reproduced before I changed anything, and Finding 2 in particular was real — a second item delivering a
different PR passed `finish` on the unmodified code (`AssertionError: LedgerError not raised`).

## Finding 1 — the borrow was invisible to anyone

Confirmed: `grep` for readers of `audit` returns exactly one line, the `INSERT` in `_audit`. One writer,
zero readers.

**I chose the `status` exposure, not the stdout line.** The stdout line would have been close to useless
here: `prepare_comment` and `finish` run inside the *worker's* process, not the service's, so a print lands
in the worker's captured transcript — where the CLI already prints the `prepare-comment` result JSON with
`"deduplicated": true` in it. The service never calls either method, so there is no service-log moment to
print at; unlike `_retire`, which genuinely runs on the scheduler thread. An operator tailing `serve` would
have seen nothing either way.

- **`Ledger.borrowed_comments(limit=20)`** — new reader. Lists items whose *conclusion* (`blocker` or
  `delivery`, never a `started` marker) was deduplicated against another item's comment, with the issue
  identifier, which item posted the comment, and the `suppressed_body` — the second worker's own words.
- **Not merged into `Ledger.status()`.** The scheduler calls `status()` twice a second from both `_recover`
  and `_sweep_worktrees`, and this scans `audit`, which has no index and only grows. It is merged at the two
  *operator* entry points instead — `python3 -m agent status` and `python3 -m agent.service status` — so it
  appears in the command an operator already runs without costing the hot path anything.
- The dedup audit row moved from kind `prepare_comment` / reason `"<kind> deduplicated"` to its own kind
  `deduplicated` with the comment kind as the reason, because a reader should not be built on a reason
  string.

## Finding 2 — a borrowed delivery claiming an unannounced PR

**Decided: refuse it.** Surfacing is not enough, and the asymmetry with a blocker is the reason. A blocker's
wording is prose and a reader can live with the ledger holding a second opinion the issue does not. A PR URL
is a checkable fact that the posted comment either states or does not, and a delivery is a claim that
something was *shipped* — recording one that was announced nowhere is Finding 1's failure mode with higher
stakes.

`finish` now requires every URL in `prs` to appear in the borrowed comment's body, matched as
`re.escape(pr) + r"(?![0-9])"` so that `.../pull/9` does not match a comment naming `.../pull/99`.

**This creates no new stall, which I checked before choosing it.** The refusal can only bite when the first
item *delivered* — that is the only way a `delivery` row exists at the key. Which means the second item's
`blocker` key is free, so it can prepare and post its own comment, naming its PR, and finish blocked. The
path out exists and needs no new mechanism. A `no_change` delivery carries no `prs`, so the loop is vacuous
and it borrows cleanly; that is asserted, not assumed.

## Finding 3 — three untested guarantees

All three now have teeth, proven by re-running the exact mutations:

| | mutation | before | now |
|---|---|---|---|
| R1 | `_recover` claim timeout: `_retire(id, "failed")` → `remove(id)` | SURVIVED | **CAUGHT** |
| R2 | `_sweep_worktrees`: `_retire(id, state)` → `remove(id)` | SURVIVED | **CAUGHT** |
| R3 | `finish`: delete the borrowed-comment audit row | SURVIVED | **CAUGHT** |
| R4 | `finish`: let a borrowed delivery claim any PR | — | CAUGHT |
| R5 | `finish`: match a PR URL by bare substring | — | CAUGHT |
| R6 | `borrowed_comments`: list deduplicated `started` markers too | — | CAUGHT |
| R7 | CLI `status`: stop merging the borrows in | — | CAUGHT |

The two scheduler tests are regression guards rather than failing-first tests: the behaviour was already
correct, it was simply unasserted, so they pass on arrival and the proof is that R1 and R2 no longer
survive. They are deliberately built to isolate one call site each — the claim-timeout test fails if `_reap`
is the only thing committing, and the lease-expiry test exercises the one path where `_recover` kills and
fails an item but removes nothing, leaving `_sweep_worktrees` as the only retirer.

## M7c, corrected

You are right and my report overclaimed. With both guards removed, the test fails like this:

```
{'committed': {}, 'errors': {'Farm-Client': 'WorktreeError: git -c failed: '}} != {'committed': {}, 'errors': {}}
```

So **git itself refuses the empty commit** — the brief's "an empty worktree must not produce an empty
commit" is enforced by git, not by my guards. What the guards actually prevent is a *spurious error entry*
in the report for a clean worktree, plus the cost of `git add --all` on a gigabyte tree. They are hygiene.
Calling M7/M7b "survivors" implied a gap that does not exist; there is none.

That paste also shows the deferred `_git` cosmetic defect in the wild: the message reads `git -c failed:`
because `_git` names the failing command from `args[0]`, which here is the `-c` of the commit identity.
Noted, not acted on, as instructed — along with "commit, never push" being untestable by construction,
`suppressed_body` truncating at 2000 with no marker, nothing pruning `farmbot/wip/*` from the bare clone,
and `_branch_safe()` being a no-op on a uuid4.

## Tests and commands

New (7): **`tests/test_ledger.py`** — `test_a_delivery_borrow_refuses_a_pr_the_posted_comment_never_named`,
`test_a_delivery_borrow_accepts_the_pr_the_posted_comment_does_name`,
`test_a_delivery_borrow_is_not_fooled_by_a_pr_number_that_is_only_a_prefix`,
`test_a_no_change_delivery_borrows_cleanly_because_it_carries_no_pr`,
`test_an_operator_reader_shows_which_items_borrowed_a_comment_and_what_they_had_said`.
**`tests/test_scheduler.py`** — `test_a_worker_that_never_claims_has_its_work_committed_before_the_sweep`,
`test_a_lease_that_expired_under_a_live_worker_commits_before_the_sweep`. Extended:
`test_a_second_item_reaching_the_same_verdict_finishes_instead_of_stalling` (the borrow audit row) and
`tests/test_cli.py::test_a_second_item_on_one_unchanged_issue_finishes_without_posting_twice` (the operator
`status` now names the borrow).

Failing first, with every `-k` selection counted rather than assumed — none printed `NO TESTS RAN`:

```
$ python3 -W error -m unittest discover -s tests -k SecondItemOnOneIssue
Ran 12 tests ... FAILED (failures=5, errors=1)
      AttributeError: 'Ledger' object has no attribute 'borrowed_comments'
      AssertionError: LedgerError not raised          # Finding 2, twice
      AssertionError: 0 != 1 / 0 != 2                 # the audit rows nothing was asserting
$ python3 -W error -m unittest discover -s tests -k second_item_on_one_unchanged
Ran 1 test   ... FAILED (errors=1)                    # KeyError: 'borrowed_comments'
$ python3 -W error -m unittest discover -s tests -k before_the_sweep
Ran 2 tests  ... OK                                   # regression guards; R1/R2 are their proof
```

Final:

```
$ python3 -W error -m unittest discover -s tests -k SecondItemOnOneIssue
Ran 12 tests ... OK
$ python3 -W error -m unittest discover -s tests -k before_the_sweep
Ran 2 tests  ... OK
$ python3 -W error -m unittest discover -s tests -k test_scheduler
Ran 37 tests ... OK
$ python3 -W error -m unittest discover -s tests -k test_cli
Ran 16 tests ... OK
$ python3 -W error -m unittest discover -s tests
Ran 302 tests in 75.023s
OK
```

Mutations run with `python3 -B`, `__pycache__` cleared before each, every file copied aside and copied back;
no `git checkout` near this working tree.
