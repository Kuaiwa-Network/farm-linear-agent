# Task 10 report — two items serialize on the one slot, offline

Commit: `a338fb9` — `test: two items needing Unity serialize on the single slot`
Branch: `phase1b-tasks-5-11` (parent `d0eeb37`). Working tree clean.

Suite: **277 tests, OK, warning-free** under `python3 -W error -m unittest discover -s tests`
(274 before → +2 criterion-3 tests, +1 regression test for the production gap this task found).

---

## 1. What I implemented

### Test scaffolding

- **`tests/test_end_to_end.py`** — the `setUp` body is extracted into `class Fixture:`, a plain object with a
  no-argument `build_environment()` method. `EndToEndTests` and the new `TwoPhaseTests` are both
  `(unittest.TestCase, Fixture)`; neither inherits the other's tests. The fixture additionally configures one
  Unity slot (`unity_slot:1`, `repo: Farm-Client`, with a `unity` override pointing at a touched file so
  `editor_path` never looks in `/Applications`).
- **`tests/fake_cli.py`** — `cli` mode accepts `FAKE_CLI_STEPS` as *either* a list (unchanged, what every other
  test passes) or a map keyed by item id. When the launch message carries a `resource` block the `<item>:resumed`
  script is selected. `{token_file}` is substituted from `resource.token_file`.
- **`agent/config.py`** — `StubLinear.fetch_issue` answers `issue-<ref>.json` when that file exists and falls back
  to `issue.json`.

### Production change (a gap the proof found — Step 3's explicit purpose)

- **`agent/ledger.py`** — new `Ledger.last_reservation_on(slot_id)`: the reservation that most recently held a
  slot, by `sequence DESC`. (A re-queued reservation inserts a row with `resource` NULL, so this only ever sees
  reservations that really held the slot.)
- **`agent/slots.py`** — `SlotPool.park_idle` reads the departing mode from that, and `SlotPool._departing`
  (the in-memory note written by `settle()`) is deleted.

**The gap, and which task it belongs to.** `_departing` was introduced by Task 6 (`8db579c`). `settle()` is the
*exceptional* path — it fires only when a worker died or was cancelled holding the slot. The ordinary way a slot
comes back is the worker's own `python3 -m agent release-resource`, which runs **in the worker's process against
its own connection**. The pool never observes that release, so `_departing` was empty and `park_idle` fell back
to its `"batch"` default. Every interactive slot released normally was therefore recorded `idle_closed` with its
Editor still open — directly against spec §7 ("after an interactive run the Editor stays open, parked on main"),
and the state the next request's scheduling preference and the close-before-batch decision both read. The old
code was already inconsistent with itself: it wrote `idle_closed` and then, one line later in `park()`, asked the
process listing whether an Editor was alive and was told yes.

`tests/test_slots.py` gained `PoolTests.test_a_slot_the_worker_gave_back_itself_is_parked_by_its_own_departing_mode`
as the unit-level regression guard, and
`PoolTests.test_a_stop_between_the_grant_and_the_switch_does_not_kill_the_pool_thread` had its
`idle_closed` assertion corrected to `idle_open` (see §5 — it was pinning the defect).

### Tests added

| Test | Proves |
|---|---|
| `TwoPhaseTests.test_two_items_needing_unity_serialize_on_the_single_slot` | serialization under contention, in arrival order, never overlapping |
| `TwoPhaseTests.test_the_slot_visits_each_pinned_commit_and_is_parked_back_on_main` | each pin visited, parked back on main between and after, `idle_open` after the interactive run, identity probed for interactive and never for batch |
| `PoolTests.test_a_slot_the_worker_gave_back_itself_is_parked_by_its_own_departing_mode` | the production fix above |

---

## 2. Commands and output

### Failing first (before any change beyond the tests)

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k TwoPhase
test_the_slot_visits_each_pinned_commit_and_is_parked_back_on_main ... FAIL
test_two_items_needing_unity_serialize_on_the_single_slot ... FAIL
AssertionError: the first item reached failed before it ever asked for the slot
Ran 2 tests in 2.627s
FAILED (failures=2)
```

Right reason: `fake_cli.py` could not yet read a per-item script map, so the worker exited 4 and the item failed.
**Exactly 2 tests selected, not 4** — the `Fixture` extraction really happened; `TwoPhaseTests` does not inherit
`EndToEndTests`'s methods.

After the two scaffolding changes, the next honest layer of failure:

```
FAIL: test_the_slot_visits_each_pinned_commit_and_is_parked_back_on_main
AssertionError: 'idle_closed' != 'idle_open'
FAIL: test_two_items_needing_unity_serialize_on_the_single_slot
AssertionError: 'running' != 'awaiting_resource'
Ran 2 tests in 8.797s
FAILED (failures=2)
```

The second of these was my own fixture's fault (see §3, defect 9) and I restructured the test. The first was the
production gap.

### Passing

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k TwoPhase
test_the_slot_visits_each_pinned_commit_and_is_parked_back_on_main ... ok
test_two_items_needing_unity_serialize_on_the_single_slot ... ok
Ran 2 tests in 9.310s
OK
```

Repeated three more times for flakiness: `OK` in 11.1 s, 11.4 s, 11.1 s.

### Every `-k` selection, counted (the constraint that matters most here)

| selection | matched | result |
|---|---|---|
| `TwoPhase` | **2** | OK |
| `EndToEnd` | **2** | OK |
| `gave_back_itself` | **1** | OK |
| `PoolTests` | **23** | OK |

No selection printed `NO TESTS RAN`; none exited 5.

### Whole suite

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
.............................................................................................
----------------------------------------------------------------------
Ran 277 tests in 90.357s

OK
```

The brief's Step 5 expected "215 tests (+2)"; that figure is stale — the suite was at 274 and is now 277.

---

## 3. The four reported brief defects, plus five more I found

**1. "Files says no production code, but requires modifying `agent/config.py`."** Real, and it turned out to
understate the case. `StubLinear` is the offline Linear double, reached only when `FARMBOT_LINEAR_STUB_DIR` is
set, so the one-line change there is scaffolding wherever it sits — but the task *also* needed a genuine
production change (`agent/slots.py`, `agent/ledger.py`), which the brief's own Step 3 anticipates
("if a test fails for a reason other than its own fixture, fix the production code"). I treated "no production
behaviour" as an expectation to be disproved rather than a constraint, and the commit body names the task the gap
belonged to.

**2. "Step 5 stages only one of the three files."** **Not present in the brief on disk.** Line 165 reads
`git add tests/test_end_to_end.py agent/config.py tests/fake_cli.py` — all three. The prior review either read an
earlier revision or the line was already fixed. I staged those three plus `agent/ledger.py`, `agent/slots.py` and
`tests/test_slots.py`.

**3. "`build_environment(self, root)` versus `self.build_environment()`."** **Not present in the brief on disk
either.** Line 26 explicitly says "a `build_environment(self)` method — it takes no arguments, because it uses
`self.addCleanup` and builds its own temporary root", which matches the call site on line 31. I implemented the
no-argument form.

**4. "It asserts a capability `fake_cli.py` does not have (`FARMBOT_ITEM_ID`)."** The *substance* is right and the
*evidence* given for it is wrong. `grep -rn FARMBOT_ITEM_ID` does not return nothing: `agent/launcher.py:124`
sets it on every worker's environment. But `tests/fake_cli.py` has never read it — its `cli` mode takes the item
id from `payload["item_id"]`. I checked the file rather than the brief and keyed the script selection off the
launch payload (`payload["item_id"]`, and `payload.get("resource")` to pick `:resumed`), which is also the more
honest signal: it is the same field a real worker reads to know whether it holds a reservation at all.

### Five further defects in the brief, found while implementing

**5. The heads assertion is unsatisfiable as written.** `assertEqual(observed[-3:], [commit_a, commit_b, main])`
cannot hold, for two independent reasons. (a) `tick()` runs `settle, grant, park_idle` in that order and
`acquire` will not take a slot in `switching`, so the slot is **parked back on main between the two items** and
that value is sampled — the compressed sequence is `[…, commit_a, main, commit_b, main]`. (b) The brief's
`new_commit` puts both pins on `main`, so `resolve_commit("Farm-Client")` would equal `commit_b` and the last two
entries would collapse into one. Fixed by pinning the two items at commits that main has moved *past*
(a third commit `main-moved-on` is made after them, which is also the realistic case) and asserting
`observed[-4:] == [commit_a, main, commit_b, main]`. That is strictly stronger: it proves the park back to main
*between* the items as well as after them.

**6. The `:resumed` script cannot finish.** `claim → release-resource → finish --outcome blocked` fails:
`Ledger.finish` refuses a blocked `fix` item whose evidence does not name a **confirmed** blocker comment of the
right kind, generation and fingerprint. The resumed script now prepares and posts that comment, exactly as the
existing delegated-bug test's worker does, and the fixture writes the per-item `outcome-<item>.json` once the
outbox row is confirmed (`fake_cli`'s `finish` already retries for 60 s).

**7. The fixture substitutes two collaborators and needs four.** `mcp` and `run_unsandboxed` are not enough:
`SlotPool.editor_scan` and `editor_pid` default to `agent.unity.other_editor_project` / `editor_holds_project`,
which shell out to `pgrep`. Left real, (a) the test shells out to `pgrep` against the global constraint, (b) any
developer with their own Unity Editor open fails `switch()`'s preflight and the slot is held, and (c) the
`idle_open` assertion is unreachable, because `park()` asks `editor_is_open` and the real listing knows nothing
about `FakeMcp.start`. Both are now injected the same way every test in `tests/test_slots.py` injects them.

**8. `RecordingMcp` records nothing and needs to.** The brief is right that a call log cannot prove criterion 3
(a batch switch calls the MCP zero times by design). I kept the class as `FakeMcp` with a docstring saying so,
and every assertion reads the ledger, the audit trail or git.

**9. The contention window as specified is a race, and the arrival order as specified is a coin toss.** Two items
enqueued together are launched by **one** scheduler tick, and their two workers reach `await-resource` in
whatever order the OS scheduled them — so `[(first, "batch"), (second, "interactive")]` would be an assertion
about process timing. Sequencing the enqueues instead (wait for the first to ask, then enqueue the second) fixes
the order but breaks the *contention*: I measured the first item completing its whole two-phase flow before the
second worker had even claimed, and the observed window showed `'running' != 'awaiting_resource'` — the second
request did not exist while the first held the slot, so nothing was being proved. Resolved with
`queue_two_requests()`: both items ask before the pool's first tick, in a sequenced order. Nothing artificial
about it — `serve()`'s pool loop waits 2 s between ticks, so any pair of requests arriving inside one of those
windows is queued together. The window assertion is now made against `active_reservation_on(SLOT) == first`
(sampled for the *whole* of the first item's hold, not one transient), and a `waited` flag with an explicit
`assertTrue` makes it impossible for that block to be silently skipped. The durable proof is
`acquired[1].created_at < acquired[0].released_at` — the second request existed while the first still held the
slot and was granted only after it was given back.

---

## 4. Mutation checks

All run with `python3 -B` / `PYTHONDONTWRITEBYTECODE=1`. Every mutation was applied by copying the file aside and
restored by copying it back — **no `git checkout`**. After the run I diffed all six touched files against a
pre-mutation snapshot: identical (the single later difference in `tests/fake_cli.py` was my own readability edit),
and `.local/editors/slot-1` is still detached at `7d886c72ea3f…` with a clean tracked tree.

| # | Mutation | Result |
|---|---|---|
| **M1** | `acquire` drops the free-slot filter | **KILLED** both (2 errors) — but via `ValueError: tuple.index(x)` in the preference sort, i.e. it crashed before reaching the interesting behaviour. Re-run as M1b. |
| **M1b** | `acquire` may grant a **busy** slot (filter *and* preference sort removed, so only the index stands in the way) | **KILLED** both: `sqlite3.IntegrityError: UNIQUE constraint failed: reservations.resource` → `LedgerError: unity_slot:1 is in batch_busy but a reservation still holds it`. This is the direct proof that two concurrent owners of the one slot are impossible and that the tests notice. |
| **M2** | `Ledger.release` hands the slot back but never marks the reservation released (the first item never really lets go) | **KILLED** both: `the loops did not reach a terminal state within 45s`. The second item is never granted. (Drain timeout temporarily lowered to 45 s to bound the run.) |
| **M3** | `switch()` skips `checkout_commit` — the slot is never moved to the pinned commit | **KILLED** the commit test on the `heads` list. |
| **M4** | `park()` skips its checkout — the slot is never parked back on main | **KILLED** the commit test on the `heads` list. |
| **M6** | `park_idle` reverts to defaulting the departing mode to `"batch"` (i.e. the production fix undone) | **KILLED** the commit test (`'idle_closed' != 'idle_open'`) **and**, run separately, the new unit test (`Ran 1 test … 'idle_closed' != 'idle_open'`). |
| **M7** | a batch grant also files an identity observation | **KILLED** the commit test — `[{…}] != []`. "A batch run never probes" has teeth. |
| **M8** | the Linear stub answers the same issue for every ref (the `agent/config.py` change undone) | **KILLED** both: `LedgerError: an active work item already exists for this issue`. |
| **M9** | grants made in reverse arrival order (`ORDER BY sequence DESC`) | **KILLED** both. |
| **M12** | *test* mutation: the second item is enqueued only after the first has finished (no contention at all) | **KILLED** the serialization test: `False is not true : the second item never had to wait; it was never observed queued behind the first`. This is the check that the proof is about contention and not about two items merely both completing. |
| **M13** | `park()` writes a stale `parked_commit` (folder right, ledger row wrong) | **KILLED** the commit test. |
| **M14** | the hand-over never files the identity observation | **KILLED** the commit test — `[] != ['match']`. |

**Both ways round (M5, an experiment rather than a mutation).** I ran the same end-to-end pair with the modes and
the order-dependent expectations swapped — **interactive first at `commit_a`, batch second at `commit_b`** — by
editing only the test file and restoring it by copy afterwards. Result: **`Ran 2 tests in 10.987s — OK`**. The
reverse ordering works end to end, and it is the ordering that exercises the graceful close: the interactive item
opens the Editor, is probed, releases and parks `idle_open` on main; the batch item's switch then finds the
Editor open, closes it gracefully, checks out `commit_b`, runs, releases and parks `idle_closed` on main. The
brief only claimed `PoolTests.test_two_requests_serialize_in_the_other_order_interactive_first_then_batch`
covers the reverse at unit level; it is now confirmed at the end-to-end level too. (That PoolTests file has
`test_two_requests_serialize_on_the_one_slot_batch_first_then_interactive`; the whole `PoolTests` selection is
23 tests and green.)

**Assertions I did *not* kill, and why.** `assertLessEqual(acquired[0].released_at, acquired[1].acquired_at)`
and `assertEqual({r["resource"] for r in acquired}, {SLOT})` are redundant cross-checks: the partial unique index
makes an overlap raise before either can fail (M1b), so they are belt-and-braces durable evidence rather than
independently load-bearing. I am flagging them as such rather than claiming coverage I did not demonstrate.

---

## 5. Self-review findings

- **`idle_closed → idle_open` in an existing Task 7 test.** `test_a_stop_between_the_grant_and_the_switch_…`
  failed after my fix. I checked whether I was fixing code to match a test or a test to match code: in that test
  `open_editor` really has started an Editor on the folder (`FakeMcp.start` added it to `open_folders`), the Stop
  lands after it, and `park()` never closes an Editor. `idle_open` is the truthful record; the old assertion was
  pinning the defect. Comment added at the assertion saying exactly that. **This is the one existing-test change
  in the commit and it deserves a reviewer's eye.**
- **Where the departing mode comes from.** I replaced `_departing` outright rather than adding a ledger fallback
  beside it. Two mechanisms that must agree is the worse design, and the ledger answer is correct on both paths
  (`settle()`'s and the worker's). `last_reservation_on` filters on `resource`, and `requeue_reservation` inserts
  its new row with `resource` NULL, so a re-queued request can never be mistaken for the departing holder.
- **`assertTrue(waited)`.** Without it the window block could be skipped entirely and the test would still pass —
  precisely the "looked like coverage and was not" failure mode. M12 confirms it fires.
- **Teardown.** `TwoPhaseTests` registers `settle_workers` after `build_environment`, so it runs *first* (LIFO):
  it reaps with `launcher.poll()` — deliberately not `scheduler.tick()`, which could launch a *new* worker from a
  queue left behind by a failed test — and stops any survivor. No `Popen` outlives a test; the suite is
  warning-free under `-W error`.
- **Offline and isolated.** Every origin is a local directory, `linear_api` returns `StubLinear`, no test touches
  `/Applications` (the `unity` override), no test shells out to `pgrep` (both listing calls injected), and the
  real 6.1 GB `.local/editors/slot-1` is untouched — the fixture's `local_root` is the per-test temp directory.
  Verified after the mutation runs: slot-1 still at `7d886c72ea3f49fce98b20d7ef19636bd7eabf50`, clean.
- **`-runTests` exit codes.** Not exercised here beyond `FakeUnity(total=4388, passed=4362, failed=26, code=2)`,
  which reproduces the known-red main and the inverted exit code; `read_results` parses the file and the summary
  reaches the resumed worker as `resource.batch_result`. No zero-total run was read as a pass.
- **Not done, by design:** Task 11 (the live rehearsal) is untouched.

---

# Fix round 1 of 5 — two Important findings

Commit: `dba9f34`
Suite: **280 tests, OK, warning-free** (277 → +3 covering tests). No production behaviour beyond the two
findings; `agent/slots.py`, `tests/test_end_to_end.py` and `tests/test_slots.py` touched.

## FINDING 1 — the batch half's Unity run was unasserted

**Verified the gap first.** On the committed state `a338fb9`, disabling `run_batch` entirely left both
criterion-3 tests green:

```
=== F1-before (HEAD): the pool's batch Unity run is disabled entirely: exit 0
    Ran 2 tests in 11.273s
    OK
```

The reviewer is right: the fixture injected `FakeUnity` because a batch grant calls it, and then never
looked at what it recorded. The proof covered "holds a reservation in batch mode", not "needs Unity".

**What changed** (`tests/test_end_to_end.py`, in `test_two_items_needing_unity_serialize_on_the_single_slot`):
a new `launch_payloads(item_id)` helper reads the launch messages the launcher really wrote
(`<state_dir>/<launch time>/prompt.md`, parsed the same way `fake_cli` parses them), and the test now asserts

- exactly one argv was handed to the unsandboxed runner, owned by the batch item, with `-projectPath` naming
  the slot folder;
- the resumed batch worker's launch message carries `resource.batch_result` with
  `(state, exit_code) == ("ran", 2)` and `(total, passed, failed) == (4388, 4362, 26)`, and its
  `results_file` exists on disk;
- the `resource` block carries no `unity` key — a worker is never handed the Editor's path (spec §8);
- the interactive worker's `batch_result` is `None` and its `resource.slot` is the slot.

**Mutations.**

| Mutation | Result |
|---|---|
| `run_batch` disabled entirely (the one that survived on HEAD) | **KILLED** — `AssertionError: 0 != 1` |
| `FakeUnity(total=0, passed=0, failed=0, code=0)` — the measured "exit 0 means nothing ran" case | **KILLED** — `Tuples differ: ('batch', 'gap', 0) != ('batch', 'ran', 2)` |
| the scheduler never puts `batch_result` in the resumed worker's launch message | **KILLED** — `TypeError: 'NoneType' object is not subscriptable` |

**Answering the reviewer's question:** yes — asserting `total == 4388` closes the zero-total case as well.
A zero-total run is recorded by `run_batch` as `state: "gap"` with `exit_code: 0`, so the tuple assertion
fails on both `state` and `exit_code` before `total` is even reached. Both the "no run at all" and the
"ran but verified nothing" failure modes are now covered; I did not need a separate zero-total test.

## FINDING 2 — the residual same-class defect in `_switch_failed`

**What changed** (`agent/slots.py`). `_switch_failed` no longer forces `set_slot_state(resource,
"idle_closed")` after `release()`. It returns the slot through `park()` — the one place that moves the
folder back to main and *asks* whether an Editor is there — and falls back only when `park()` itself fails:

```python
self.ledger.release(reservation["reservation_id"], reservation["token"], reason)
try:
    self.park(reservation["resource"], reservation["mode"])
except SlotError:
    slot = self.ledger.slot(reservation["resource"])
    self.ledger.set_slot_state(reservation["resource"], self._idle_state(slot, reservation["mode"]))
```

The fallback is deliberate and is the reason this is not a bare deletion: only the git stage can reach it
(its own checkout is what just failed), and spec §7 keeps a git or editor failure retryable at the tail, so
the slot must stay in the pool rather than being held — `park_idle`'s own failure path sets `held`, which
would strand the re-queued reservation for ever. `PoolTests.test_a_git_stage_failure_is_requeued_once_at_
the_tail_and_fails_the_item_the_second_time` is what holds that line and it still passes.

The idle-state decision is now one method, `SlotPool._idle_state(slot, mode)`, used by both `park()` and the
fallback, because those two used to disagree and the disagreement *was* the defect.

**Covering tests** (all new, in `PoolTests`):

- `test_a_grant_that_fails_gives_the_slot_back_through_park_and_never_asserts_its_state` — an interactive
  grant that fails at the **compile** stage (reached after `open_editor`, so the Editor really is on the
  folder): the slot is `idle_open`, `parked_commit` equals main, the folder's own head equals main, and the
  slot is still in `FREE_SLOT_STATES`. Written **failing first**: `AssertionError: 'idle_closed' !=
  'idle_open'`.
- `test_an_interactive_slot_whose_editor_died_is_parked_closed_and_its_lock_cleared` — the other half:
  interactive departure with a dead Editor parks `idle_closed` and the stale lock is removed.
- `test_a_git_failure_on_an_open_interactive_slot_still_records_the_editor_that_is_there` — the fallback
  arm: the row keeps `idle_open` over a live Editor, the slot stays grantable, and the reservation is
  re-queued.

**Mutations.**

| Mutation | Result |
|---|---|
| the give-back forces `idle_closed` again (the pre-fix line restored) | **KILLED** — 2 tests, both `'idle_closed' != 'idle_open'` |
| the git-stage fallback asserts `idle_closed` instead of asking | **KILLED** — 1 test |
| `_idle_state` stops asking whether the Editor is alive | **KILLED** — 1 test, `'idle_open' != 'idle_closed'` |

**Two process notes against myself, because both are exactly the failure modes this task is about.**

1. My first attempt at the third mutation **survived** — `_idle_state` ignoring `editor_is_open` passed all
   24 PoolTests. That is a pre-existing coverage gap (the same expression was inline in `park()` before this
   round), but I had just written a comment claiming the state was "asked rather than asserted", so it was a
   comment asserting coverage that did not exist. The two extra tests above were added for that reason, and
   the mutation is now killed.
2. One of my mutation selections was `-k "SlotPool or PoolTests or SwitchTests"`. `-k` is a plain substring
   with no boolean operators: it matched nothing and printed `NO TESTS RAN` with exit 5 — a mutation run
   that would have read as "survived" if I had not been counting. Re-run against `PoolTests` (26 matches).

## Commands

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k TwoPhase
test_the_slot_visits_each_pinned_commit_and_is_parked_back_on_main ... ok
test_two_items_needing_unity_serialize_on_the_single_slot ... ok
Ran 2 tests in 11.589s
OK

$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 280 tests in 97.360s
OK
```

Every selection counted, none empty:

| selection | matched | result |
|---|---|---|
| `TwoPhase` | 2 | OK |
| `PoolTests` | 26 | OK |
| `gives_the_slot_back_through_park` | 1 | OK |
| `editor_died_is_parked_closed` | 1 | OK |
| `git_failure_on_an_open_interactive` | 1 | OK |
| `gave_back_itself` | 1 | OK |

Every mutation was applied by copying the file aside and restored by copying it back; no `git checkout`.
`.local/editors/slot-1` re-checked afterwards: still detached at `7d886c72ea3f49fce98b20d7ef19636bd7eabf50`
with a clean tracked tree.

**Deferred as instructed, not acted on:** the tautological `aggregate == ["match"]` assertion, and brief
defect 1 (the Files/Produces claim of no production change).
