# Task 13: the readiness gate cannot pass against an idle Editor

Not part of Plan 1b as written. This task exists because Task 11 Step 4 halted on it. Full write-up:
`docs/superpowers/spikes/2026-09-20-live-rehearsal-findings.md`, section "Step 4 result".

Branch `task-13-readiness-gate`, off `task-11-live-rehearsal` at `b5964d6`. Suite is **302 tests**,
green and warning-free under `python3 -W error -m unittest discover -s tests`.

## The defect

`agent/identity.py:61`, inside `ready()`:

```python
and 0 <= now_ms-observed <= 10000
```

`observed_at_unix_ms` is **not a heartbeat**. I read the package source and confirmed the mechanism
end to end; you do not need to re-derive it, but do verify it:

- `EditorStateCache.OnUpdate` computes a `hasChanges` boolean over scene path/name, focus, play,
  pause, updating, tests-running and activity phase, plus a compilation edge.
- `if (!hasChanges) { return; }` — its own comment: *"No state change - skip the expensive
  BuildSnapshot entirely."*
- `ForceUpdate("tick")` sits **after** that guard, so it is not periodic.
- `_observedUnixMs` and `_sequence` are assigned only inside `BuildSnapshot`.
- `ForceUpdate` is `private static`. **No MCP tool exposes it.** `refresh_unity`, `execute_code` and
  `manage_editor` were all tried against a live Editor and all left `sequence` frozen.

So the field means *"when the state last changed"*. Measured live: age past **117 seconds**,
`sequence` frozen at **3**, while `is_compiling`, `is_domain_reload_pending`, `is_updating` and
`is_running` were all `False` and `execute_code` worked throughout. **The more reliably idle the
Editor, the more certainly the gate fails.**

Note `isFocused` is in the change set. That is why FarmQA never hit this — a human clicking around an
Editor keeps refreshing it. An unattended slot freezes.

Read the package yourself at (a copy identical to the slot's, `@30d2207509`):
`/Users/elendil/WorkSpaces/Farm/Farm-Client/Library/PackageCache/com.coplaydev.unity-mcp@30d2207509/Editor/Services/EditorStateCache.cs`

## Blast radius — read `collect()` before designing

`ready()` is used **twice**, and the two uses are not the same thing:

1. `if ready(before, instance):` is an **outer guard**. When it fails, the entire body is skipped, so
   every check stays `unknown`, the aggregate is `unknown`, and the pool holds the slot. This is what
   halted Step 4.
2. `ready(after, instance)` is one conjunct of the **`editor_ready` check**, which already ANDs in the
   probe's live `isPlaying`, `isPlayingOrWillChangePlaymode`, `isCompiling`, `isUpdating` and
   `scene.isDirty`.

That second fact is the key to the fix: **the live evidence is already being collected.** It is
merely gated behind a timestamp that cannot refresh.

## Direction

My assessment, which you may overturn with reasons in your report:

**Derive readiness from live evidence, not from the cache's rebuild policy.** Concretely, separate
the two concerns that `ready()` currently conflates:

- A **precondition** for proceeding: right schema version, `unity.instance_id` matches, and nothing in
  the snapshot positively says busy. No freshness requirement. A stale snapshot saying "idle" is no
  longer treated as proof of idleness — it is simply not treated as proof of *busyness* either.
- The **`editor_ready` verdict**: keeps the strict all-quiet requirement, sourced from the probe's
  live values, which execute on the main thread and cannot be stale by construction.

The safety property that must survive: **an Editor that is actually compiling, reloading, importing,
playing or running tests must never be certified ready.** Losing the timestamp must not lose that.
Argue in your report how your design preserves it.

**Investigate before you trust them:** `staleness.is_stale` and `advice.ready_for_tools` are both in
the current gate, and `ready_for_tools` was observed going `False` on the idle Editor. If either is
computed from the same frozen timestamp it is circular and cannot be load-bearing. Determine which
from the package source and say so.

**Do not** reorder `collect()` more than the fix needs. The docstring at `agent/identity.py:119-128`
explains why the order is load-bearing — the two source snapshots either side are what make "the slot
really was on that commit for the whole run" checkable. Keep both, and keep the property.

**Do not** make `collect()` raise. It never raises by contract; a failure is an `unknown` aggregate.

## This one IS testable

Unlike the probe bug fixed in `b5964d6`, this is a pure function over dictionaries plus a `collect()`
that takes an injectable client. The suite's fake MCP is sufficient. **Strict TDD, no excuses.**

Write the failing test first and confirm it fails for the right reason: a snapshot whose
`observed_at_unix_ms` is minutes old but whose every busy flag is `False`, against a probe reporting
live quiet, must produce a `match` aggregate — and today produces `unknown`. Add the converse: an old
snapshot that positively reports compiling/playing/updating/tests-running must still NOT certify.

## Global constraints

- Python 3.11+, **standard library only** in `agent/`; no third-party imports.
- Whole suite green AND warning-free under `python3 -W error -m unittest discover -s tests`, from 302.
- No test may start Unity, touch `/Applications`, reach the network, or open the real ledger.
- **A real 6.1 GB slot exists at `.local/editors/slot-1`. Nothing may write to it.** Read the package
  copy under `Farm-Client` instead.
- `unittest`'s `-k` is a plain substring with no boolean operators; a selection matching nothing
  prints `NO TESTS RAN` and exits 5, silently satisfying a failing-first gate. Count what it matches.
- Mutation-check with `python3 -B` (a same-size mutation reverted within one second can let CPython
  reuse a stale `.pyc` and give a false result either way). **Do not use `git checkout` to restore a
  mutated file** — copy it aside and copy it back; two implementers on this plan destroyed
  uncommitted work that way.
- Commit with a conventional-commit message ending
  `Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>`.

Report the real test counts, the design you chose and why, and what you found about `is_stale` and
`ready_for_tools`.
