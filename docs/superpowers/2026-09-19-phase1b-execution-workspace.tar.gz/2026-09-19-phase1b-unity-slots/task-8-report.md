# Task 8 report — the worker asks for a slot, gives it back, and the operator can see the pool

Branch `phase1b-tasks-5-11`, on top of `bae5210`.

## What I implemented

**`agent/__main__.py`** — `await-resource` stops being a refusal. The `load_config().slots` pre-check and
its `no unity slots configured on this host` message are gone; the command now calls
`ledger.await_resource` directly, so an unpinned item gets the ledger's own reason instead of a blanket
refusal. Four verbs added:

- `release-resource --item --token-file --outcome {quiescent,unclean}` — resolves the token, reads
  `active_reservation(item)`, and either holds (unclean) or releases and returns the reservation view
  (quiescent).
- `reservations`, `slots` — token-free operator readers.
- `recover-slot --slot --reason` — the only way out of `held`.

**`agent/ledger.py`** — `Ledger.note(item_id, kind, reason="", details=None)`, a public transactional
wrapper around `_audit`, so an operator act outside Linear leaves the trail a webhook would.

**`agent/service.py`** — `enqueue(config, *, issue_ref, skill, commit=None, session=None)` fetches the
issue, refuses a write-capable skill on an issue whose `delegate_id` is not this app user, mints a
synthetic `local-<issue-uuid>` session, pins a target and creates a queued work item, then records the
operator's act in `audit`. `main` gains the `enqueue` and `slots` subcommands and `--issue/--skill/--commit`.

**`agent/scheduler.py`** — `_notify` posts an issue comment instead of a session activity when the item's
session id begins `local-`.

**`skills/fix/SKILL.md`** — rungs 4 and 5 rewritten; **`docs/operating-contract.md`** — authority table,
work-item states, first limits bullet; **`README.md`** — two lines for the new operator commands.

## Test names per file

`tests/test_cli.py` (new helper `granted_item`, `seeded_item` gains `target=None`):
- `test_a_worker_requests_a_slot_and_the_request_is_queued`
- `test_an_unpinned_item_is_told_why_it_cannot_have_a_slot`
- `test_a_worker_releases_its_own_slot_and_an_unclean_one_is_held`
- `test_release_resource_refuses_an_item_that_holds_nothing` (added; see defect 5)

`tests/test_service.py` (new `EnqueueTests` class):
- `test_enqueue_creates_a_pinned_work_item_without_any_webhook`
- `test_enqueue_refuses_a_write_capable_skill_on_an_issue_nobody_delegated`
- `test_enqueue_allows_a_read_only_skill_on_an_undelegated_issue` (added; see defect 6)
- `test_the_enqueue_and_slots_subcommands_run_the_way_the_operating_contract_prints_them` (added; defect 7)

`tests/test_scheduler.py` (`FakeAPI` gains `create_comment`):
- `test_a_locally_enqueued_item_reports_by_issue_comment_because_it_has_no_linear_session` (added; defect 4)

Replaced and removed: `test_await_resource_is_refused_without_slots_and_errors_are_clean`.

## Commands and output

Baseline before any change:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 260 tests in 58.843s
OK
```

Failing-first (the brief's selection plus `-k local` for the scheduler test):

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k slot -k resource -k enqueue -k local
FAIL: test_a_worker_releases_its_own_slot_and_an_unclean_one_is_held
      -> farmbot: LedgerError: no unity slots configured on this host; record the verification gap instead
FAIL: test_a_worker_requests_a_slot_and_the_request_is_queued          (same refusal)
FAIL: test_an_unpinned_item_is_told_why_it_cannot_have_a_slot
      -> 'pinned commit' not found in 'farmbot: LedgerError: no unity slots configured...'
FAIL: test_release_resource_refuses_an_item_that_holds_nothing
      -> argparse: invalid choice: 'release-resource'
FAIL: test_a_locally_enqueued_item_reports_by_issue_comment_...
      -> activities == [('local-...','error','工作进程未完成即退出...')] != []
ERROR: test_service (unittest.loader._FailedTest) -> cannot import name 'enqueue' from 'agent.service'
Ran 77 tests in 36.349s
FAILED (failures=5, errors=1)
```

Every failure is for the intended reason. The loader error hid the three `EnqueueTests`; they were run
directly after the import existed.

Selection after implementation:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k slot -k resource -k enqueue -k local
Ran 82 tests in 38.849s
OK
```

Whole suite, final:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 268 tests in 62.447s
OK
```

260 -> 268: +9 new, -1 replaced. The brief predicted 209 (+5, -1); stale, as every task's prediction has been.

### Mutation checks (`python3 -B`, file copied aside and copied back, never `git checkout`)

| Mutation | Result |
|---|---|
| `enqueue`: `if skill in WRITE_SKILLS and not delegated:` -> `if False and ...` | `test_enqueue_refuses_...` FAILS (`RuntimeError not raised`) |
| `__main__`: `if args.outcome == "unclean":` -> `if False:` | `test_a_worker_releases_...` FAILS (slot `switching`, expected `held`) |
| `__main__`: `recover_slot(...)` -> `ledger.slot(...)` | `test_a_worker_releases_...` FAILS |
| `scheduler._notify` guard (checked as the failing-first state) | `test_a_locally_enqueued_...` FAILS |

Each file restored by copy-back and the marker line re-grepped afterwards (count 1 each time).

## Brief defects found and how I resolved them

1. **`WRITE_SKILLS` is not in `agent/receiver.py`.** The brief says "the set `agent/receiver.py` already
   defines"; it is defined in `agent/router.py:6` as a tuple and *imported* by the receiver. I import it
   from `agent/router.py`, the definer.

2. **`agent/ledger.py` is missing from the brief's Files list** although Step 4 requires a new public
   `Ledger.note`. Added there. `_audit` opens no transaction of its own, so `note` wraps it in
   `_transaction()`; without that the audit row would never commit and the test that reads it back on a
   second connection would fail.

3. **"the only place in `agent/__main__.py` that read the host configuration" is wrong.**
   `check_pr_targets` (line 72) also calls `load_config()`. The import stays; removing it as the brief
   implies would have broken every PR-target test.

4. **The brief lists `agent/scheduler.py` as modified but prescribes no test for it.** The `local-` guard
   in `_notify` would have been a silent, untested behaviour change — and it is the half of the second
   decision that makes §9's reporting surface work at all for enqueued items. Added
   `test_a_locally_enqueued_item_reports_by_issue_comment_because_it_has_no_linear_session` and gave
   `FakeAPI` a `create_comment`. The brief's line reference (`agent/scheduler.py:76`) is stale; the only
   `create_activity` in that file is in `_notify` at line 130.

5. **The brief's `run()` snippet raises `LedgerError("this item holds no resource")` but no test reaches
   it.** Added `test_release_resource_refuses_an_item_that_holds_nothing`.

6. **The refusal test alone cannot distinguish "refuses write-capable skills" from "refuses everything".**
   Added `test_enqueue_allows_a_read_only_skill_on_an_undelegated_issue` (`chat`), which is what makes the
   refusal a test of the rule rather than of the function failing.

7. **Nothing exercised `agent.service main`'s new `enqueue` and `slots` dispatch** — precisely the two
   commands the operating contract now prints for the host with no webhook. Added
   `test_the_enqueue_and_slots_subcommands_run_the_way_the_operating_contract_prints_them`, which drives
   `main(...)` with a real config file and also asserts the `--issue`-less enqueue exits rather than
   fetching `None`. (`--issue` cannot be made `required` in argparse here because one positional `command`
   serves all seven subcommands; the guard is in `main`.)

8. **The brief's `enqueue` docstring claims `activities_supported` is False on the session.** No such
   column or key exists anywhere in the ledger. The real mechanism is the `local-` prefix on the session
   id, which the scheduler and the skill both read. I rewrote the docstring to say that instead of
   documenting a field that does not exist.

9. **The brief's inline target dict in test 1 duplicates `test_ledger.PIN` exactly.** I import `PIN`
   rather than re-spelling it; `SELECTED_AT` therefore reaches the test through `PIN`, which is the same
   constant the brief asked for.

10. **`tests/test_service.py` has no `self.config` or `self.stub` outside `ServeTests`**, whose fixture
    builds four real git origins and a full `build()`. I gave `EnqueueTests` its own `setUp` with a stub
    dir, a `patch.dict` on the environment and a `Config` with `repos={}` — every test passes an explicit
    `--commit`, so `Worktrees.resolve_commit` is never called and nothing touches git or the network.

## The `skills/fix/SKILL.md` replacement range, and what I preserved

The brief said to replace "rungs 4 and 5 and the sentence beginning `Until slots exist`". That sentence is
not a sentence; it opens a three-sentence paragraph (old lines 57-59):

1. `Until slots exist, rung 4 and 5 return an error from the CLI; record the exact unverified behaviour as
   a verification gap and finish blocked or deliver with the gap named.` — superseded by this task.
2. `Never describe a source-only check as runtime evidence.` — **a standing rule.**
3. `Show a testable logic bug failing before the fix and passing after.` — **a standing rule.**

The brief's replacement text contains neither standing rule. Replacing the range as written would have
silently deleted both. I kept them, in a paragraph that also keeps the still-true half of sentence 1:

> Record any behaviour you could not verify as a verification gap and finish blocked or deliver with the gap
> named. Never describe a source-only check as runtime evidence. Show a testable logic bug failing before
> the fix and passing after.

Nothing else in that file was removed; rungs 1-3 and every section around the ladder are untouched.

I also added one sentence the brief omits and the verb is unusable without: `release-resource` is
authorised by the **reservation** token at `resource.token_file`, not by the claim token at
`STATE_DIR/token` that the Intake section tells the worker to pass on "every later call". A worker
following Intake literally would have been refused with `reservation token required` on every release.

## The carried item about `test_await_resource_is_refused_without_slots_and_errors_are_clean`

The brief said to replace lines 191-195. The test is six lines; line 196 —
`self.run_cli("claim", "--item", item, "--worker-id", "w2", success=False)` — is the "errors are clean"
half of its name and was outside the brief's range. Deleting the test wholesale would have dropped it.
The ledger-level refusal is covered by `test_ledger.py:181`, but the CLI-level assertion (clean stderr, no
traceback, non-zero exit on a second claim) is not asserted anywhere else in `test_cli.py`. I carried the
line into `test_a_worker_requests_a_slot_and_the_request_is_queued`, where the item is parked in
`awaiting_resource` and a claim is refused for the same reason, with a comment saying where it came from.

## Self-review findings

- **`release-resource --outcome unclean` does not verify the token against the reservation.** I resolve a
  token for both outcomes so the verb has one contract, but `Ledger.hold` takes no token and has no
  ownership check, so only the `quiescent` path is actually authenticated. The worst case is a
  denial-of-service on one slot that `recover-slot` undoes, and it is consistent with the standing ruling
  that `cancel` (which cancels an item's reservations) is unauthenticated on a single-user host. Adding a
  token parameter to `Ledger.hold` would be new ledger surface and new tests in a task that owns neither;
  flagging rather than doing it. **Worth a reviewer's ruling.**
- **`reservations` returns every reservation ever made**, including released and cancelled ones, because
  the brief specifies `ledger.reservations()` with no filter. `agent.service slots` filters to the three
  open states. On a long-lived host the CLI reader grows without bound. Left as specified.
- **The carried item about `fail_queued` posting no Linear notice is now half-closed.** `agent.service
  slots` gives the operator the pool view the carried item asked for, and `_notify`'s new comment path
  means a *launch* failure on an enqueued item reaches Linear. The pool's own `fail_queued` calls in
  `agent/slots.py` still post nothing — that is the pool's code, not this task's, and I did not expand
  into it.
- **`enqueue` observes the issue before the delegation check**, so a refused enqueue still writes an issue
  snapshot. That is a read-only observation and `observe_issue` is idempotent; the test asserts no work
  item is created, which is the part that matters.
- **Repeated `enqueue` on one issue reuses `local-<issue-uuid>`** (`ensure_session` is `INSERT OR IGNORE`)
  and is then refused by `create_work_item`'s active-item check. That is the same behaviour a second
  delegation gets, so I left it.
- **`.local/editors/slot-1` untouched**: still detached at `7d886c72ea3f49fce98b20d7ef19636bd7eabf50`,
  6.1 GB. No test reaches outside its own `TemporaryDirectory`; `EnqueueTests` sets `local_root` into tmp
  and `FARMBOT_CONFIG` at a non-existent path.
- No new threads, servers or subprocess handles were introduced outside `tests/test_cli.py`'s existing
  `subprocess.run` helper, and the suite is warning-free under `-W error`.

---

# Fix round 1

Commit `63b4bcb`, on top of `880c430`.

## Finding 1 (Important) — authenticate `release-resource --outcome unclean`

Accepted the ruling. `unclean` is now verified against the reservation's own hashed token, like
`quiescent` already was.

**What changed**

- `agent/ledger.py`: new `Ledger.hold_owned(reservation_id, token, reason)` — a thin wrapper that calls
  `_reservation_owned` (which raises `LedgerError("reservation token required")` on a missing, malformed or
  mismatched token) and then delegates to the unchanged `hold`.
- `agent/__main__.py`: the `release-resource` branch's `unclean` path calls `hold_owned(...)` instead of
  `hold(...)`. The comment now says both outcomes are verified against the reservation token and never the
  claim token, and why `unclean` is the consequential one.

**Why a wrapper and not a parameter on `hold`** — following the reviewer's constraint. `SlotPool.settle`
(`agent/slots.py:337`) holds *precisely because* `_read_token` returned `None`, so it can never present a
token; `SlotPool._switch_failed` (`agent/slots.py:309`) holds on a failed probe from the pool thread. A
token parameter on `hold` would break the backstop spec §7 relies on. `hold` is therefore unchanged and
stays the pool's entry point; `hold_owned` is the worker's.

**Covering tests**

- `tests/test_cli.py::CliTests::test_neither_outcome_acts_on_a_reservation_the_caller_cannot_prove_it_holds`
  (new — Finding 2)
- `tests/test_cli.py::CliTests::test_a_worker_releases_its_own_slot_and_an_unclean_one_is_held` (the happy
  path still works)
- `tests/test_slots.py::PoolTests::test_a_slot_is_held_when_the_release_gate_does_not_pass` (the pool's
  three hold paths, including the missing token file, still work)

## Finding 2 (Important) — the test that looked like coverage

Confirmed. `test_a_worker_releases_its_own_slot_and_an_unclean_one_is_held` passes the *correct* token to
both outcomes, so it would have passed against a `hold` that checked nothing — and before this round it
did exactly that. Added
`test_neither_outcome_acts_on_a_reservation_the_caller_cannot_prove_it_holds`, which crosses two wrong
tokens with both outcomes (four subTests):

- **the fresh worker's own claim token** — the realistic wrong one, because the skill's Intake section
  tells a worker to carry `STATE_DIR/token` on every other call. The test drives the real sequence:
  `granted_item` leaves the reservation active, then `Ledger.resume` stands in for `SlotPool.hand_over` so
  a fresh worker can `claim`, and that claim token is what gets refused.
- **a made-up `res_`-shaped string.**

Each subTest asserts the refusal message, empty stdout, and that nothing moved — slot still
`interactive_busy`, reservation still `active`. The test then releases with the *real* token and asserts
the slot reaches `held`, so the four refusals are about the token and not about a broken verb.

### On the second half of Finding 2

The report asked me to "add a test that `settle`'s missing-token-file hold still works". **That test
already exists** and I did not add a duplicate: `tests/test_slots.py:752`
`test_a_slot_is_held_when_the_release_gate_does_not_pass` runs three subTests, the third of which
(`"token file gone"`, line 757) unlinks `pool.token_path(item)` before the settling tick and asserts the
slot is `held`, the reservation still `active` and `settled == 0`. I checked the file rather than assuming,
and then proved the coverage is real by mutation rather than by reading it — see mutation B below, which is
the precise mistake the reviewer's constraint exists to prevent.

## Commands and output

```
$ cd tests && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=<repo> python3 -B -W error -m unittest -v \
    test_cli.CliTests.test_neither_outcome_acts_on_a_reservation_the_caller_cannot_prove_it_holds \
    test_cli.CliTests.test_a_worker_releases_its_own_slot_and_an_unclean_one_is_held \
    test_slots.PoolTests.test_a_slot_is_held_when_the_release_gate_does_not_pass
Ran 3 tests in 3.280s
OK
```

Whole suite, final:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 269 tests in 65.871s
OK
```

268 -> 269 (+1 new test, 4 subTests).

### Mutation checks (`python3 -B`, copy aside / copy back, no `git checkout`)

| Mutation | Result |
|---|---|
| A. `agent/__main__.py`: `hold_owned(res, token, ...)` -> `hold(res, ...)` (the pre-fix code) | `test_neither_outcome_acts_...` FAILS, 3 of 4 subTests: `assertNotEqual(0, returncode)` -> `0 == 0`. The fix is exactly what the new test pins. |
| B. `agent/ledger.py`: `hold` itself made token-required (`_reservation_owned` at its head) | `test_a_slot_is_held_when_the_release_gate_does_not_pass` FAILS with `LedgerError: reservation token required` on all three subTests. The pool's own hold paths are really covered, and the wrapper design is load-bearing rather than stylistic. |

Marker lines re-grepped after each copy-back (`hold_owned` count 1 in `__main__.py`; `MUTANT` count 0 in
`ledger.py`).

## Deferred, not acted on (as instructed)

`Ledger.RESERVATION_OPEN` vs the hardcoded tuple in `agent/service.py`; `resolve_token`'s "claim token
required" wording; `enqueue`'s unreachable `session=` parameter; `reservations` returning every
reservation; the pool's `fail_queued` posting no Linear notice.
