# Task 12: unblock the offline path, and stop losing a failed worker's work

Not part of Plan 1b as written. This task exists because Task 11's live rehearsal found two defects
that block it. Full write-up: `docs/superpowers/spikes/2026-09-20-live-rehearsal-findings.md`.

Branch `fix-outbox-dedup-and-evidence`, off `main` at `bdd3dd8`. Suite is **280 tests**, green and
warning-free under `python3 -W error -m unittest discover -s tests`.

## Fix A (blocking) — a second work item on one issue cannot finish

**Observed.** `python3 -m agent.service enqueue` created a second `fix` item on FARM-1238, which
already had a work item from a delegation and had not changed since. The second item did its work,
reached the same verdict, and then:

```
15:37:55  checkpoint  blocked-client-export
15:38:44  failed      worker exited without finishing (exited, code 0)
```

It posted nothing. The delegated item on the same issue, reaching the same verdict an hour earlier,
ended `blocked` with a comment on the issue.

**Mechanism, confirmed by reading the code.** `Ledger.prepare_comment` derives

```python
key = f"{row['issue_id']}:{row['claimed_fingerprint']}:{row['generation']}:{kind}"
```

backed by `UNIQUE(issue_id, fingerprint, generation, kind)` on `outbox`. The item id is deliberately
excluded so one issue cannot collect two identical `blocker` comments. When the row already exists
`prepare_comment` does **not** insert; it returns the existing row — which belongs to the other item.

`Ledger.finish` then refuses it:

```python
if (action is None or action["item_id"] != row["id"] or action["fingerprint"] != row["claimed_fingerprint"]
        or action["generation"] != row["generation"] or action["kind"] != kind or not action["remote_id"]):
    raise LedgerError("finish requires a confirmed comment for this item, claimed input and outcome")
```

and for a non-`chat` skill `comment_action_id` is mandatory, so there is no path to a terminal state
at all. The worker stalls, exits 0, and the scheduler reaps it as `failed`.

**Why it must be fixed now.** Task 11 drives every remaining step through `enqueue`, because the
webhook could not be relied on. That path cannot reach a terminal state on any issue that already
carries a work item.

**Design constraints you must respect.**

- The dedup itself is correct and must survive: the same issue, unchanged, must not receive two
  identical comments. Do not simply add `item_id` to the key — that is what the key was chosen to
  exclude, and it would let a re-run spam the issue.
- `generation` is **not** a free re-run counter. It is bumped only when the issue materially changed
  (`observe_issue` requeueing a blocked item) or when `finish` re-queues because the fingerprint moved.
  It also appears in `reservations` and `published_prs`. Do not repurpose it for "operator ran this
  twice".
- `Ledger` has **no `subprocess` or `os` imports** and must keep none.

**Three candidate shapes**, in the write-up. My assessment, which you may overturn with reasons:

1. *Item id in the key* — rejected above.
2. *`prepare_comment` raises when the existing row belongs to another item* — turns a silent stall
   into a loud, handleable refusal. Smallest change. But on its own it is **not sufficient**: the
   worker still cannot `finish`, because `comment_action_id` is mandatory for a non-chat skill. Pair
   it with a `finish` that accepts the existing row.
3. *Relax `finish`* to accept a confirmed outbox row matching this item's `(issue, fingerprint,
   generation, kind)` even when `item_id` differs. The rationale: the outbox row means "the comment
   for this issue at this fingerprint, generation and kind exists and was posted". A second item
   reaching the *same kind* of conclusion is genuinely satisfied by it — and a different conclusion
   produces a different `kind`, hence a different `action_id`, hence no clash.

Whichever you choose, the **required behaviour** is: a second work item on an unchanged issue that
reaches the same verdict must reach a terminal state (`blocked` or `delivered`), must not
double-post, and must not be reaped as `failed`. Say in your report which shape you chose and why.

## Fix B — a failed item's work is swept away

**Observed.** The same worker's final message claimed 「hive 已修正，三个针对性测试通过」 — a
farm-hive fix with three passing tests. All four `farmbot/*` branches in `farm-hive` are **0 commits
ahead of `origin/main`**. The only commits it produced anywhere are two documentation commits on a
Farm-Client branch.

The change may genuinely have been made and tested in the worktree, which `_sweep_worktrees` removed
when the item failed. Either way the work is gone and the claim can no longer be adjudicated.

**What to change.** When an item reaches `failed`, commit whatever is in its worktrees to that item's
branch before sweeping. A failure is exactly when an operator most wants to see what the worker did.
Keep it narrow:

- Only on `failed` — a `delivered` or `blocked` item has already published what it meant to.
- Commit, do not push. Pushing is a side effect this task has no mandate for.
- An empty worktree must not produce an empty commit.
- A commit failure must not mask the original failure, and must not prevent the sweep. Log it.
- The commit message should make its provenance obvious, e.g. `wip(<item>): worker exited without
  finishing`.

This also makes Fix A's world safer: a worker whose `finish` is refused leaves evidence behind.

## What this task does NOT do

Do not build a mechanism for `finish` to verify a worker's claims against git. The `Ledger` cannot
run git by design, the CLI's `finish` verb does not know the item's branch, and only the scheduler
does. That plumbing is a larger change than this task, and Fix B removes most of its motivation by
preserving the evidence instead. Note it in your report as deferred.

## Global constraints

- Python 3.11+, **standard library only** in `agent/`; no third-party imports.
- Whole suite green AND warning-free under `python3 -W error -m unittest discover -s tests`, from 280.
- One `sqlite3.Connection` per thread; never hold a transaction across a subprocess or a git call.
- No test may start Unity, touch `/Applications`, reach the network, or open the real ledger. Tests
  MAY shell out to real `git` and use real temporary SQLite and real subprocesses.
- **A real 6.1 GB slot exists at `.local/editors/slot-1`. Nothing may touch it.**
- `unittest`'s `-k` is a plain substring with no boolean operators; a selection matching nothing
  prints `NO TESTS RAN` and exits 5, silently satisfying a failing-first gate. Count what it matches.
- Commit with a conventional-commit message ending
  `Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>`.

## Method

Strict TDD. Write the failing tests first and confirm they fail for the right reason — for Fix A that
means a test reproducing the real sequence: two items on one unchanged issue, the second reaching the
same verdict, ending terminal rather than `failed`. Then implement, then the whole suite, then
self-review, then commit.

Mutation-check with `python3 -B` (a same-size mutation reverted within one second can let CPython
reuse a stale `.pyc` and give a false result either way). **Do not use `git checkout` to restore a
mutated file** — copy it aside and copy it back; two implementers on this plan destroyed uncommitted
work that way.

Report the real test counts.
