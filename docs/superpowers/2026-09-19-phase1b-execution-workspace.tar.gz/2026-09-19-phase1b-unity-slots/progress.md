# SDD ledger — plan: docs/superpowers/plans/2026-09-19-phase1b-unity-slots.md

Spec: docs/superpowers/specs/2026-09-17-farm-linear-agent-design.md (read; §5 §6 §7 §8 §10 §17 §18 bind this plan).
Branch: phase1b-unity-slots, cut from main at 7c88e0c.
Scope this session: the human asked for **Task 1 only**, then a check-in. This overrides the
skill's continuous-execution default.

## Rulings (pre-flight)

Ruling: branch in the main checkout, not a git worktree — `.local/` is git-ignored and holds
FarmBot's bare clones (`.local/repos/*.git`, 876 MB of LFS objects) and the already-built
`slot-1` (6.1 GB, imported 2026-09-19). A fresh worktree would have none of them, so Tasks 3+
would rebuild ~6 GB and re-import for no gain, and the spike's measured slot would be wasted.
Cost if wrong: implementation commits land on a branch in the shared checkout rather than an
isolated directory; recoverable by `git worktree add` later, at the cost of a re-import.

Ruling: dispatch implementers and reviewers on Opus, against the skill's Model Selection advice
to economise. The human rejected a Haiku/Sonnet mix on an earlier plan. Cost if wrong: higher
token spend per task.

## Pre-flight scan

The whole-plan cross-task scan was performed by three adversarial review passes before execution
(60, 31 and 30 findings). Blockers and the one design defect are closed; what remains is recorded
below as deferred minors so the final review can triage them.

| Check | Result |
|---|---|
| Task 1 vs Global Constraints | consistent — Task 1 adds no Unity, no slot, no network; tests use real temp SQLite |
| Task 1 produces → Task 2 consumes | `work_items.target_json` / pinned `commit_sha`; Task 2's `await_resource` refuses an item with no pin. Task 1 must actually write the pin or Task 2's tests cannot pass. Verified: Task 1 Step 5 writes it at receipt. |
| Task 1 vs agent/receiver.py reality | `receiver.py:167` really is `def _decide_and_act`; the plan now anchors its replacement on text, not line numbers. Verified by hand 2026-09-20. |
| Task 1 self-consistency (tests vs code) | claims +8 → 147; three files named. Unverified by hand — left to the task review. |
| Tasks sharing agent/ledger.py | 1, 2, 7, 8, 9 — serialised by task order; no parallel dispatch. |
| Tasks sharing agent/slots.py | 3, 4, 5, 6, 7 — created in 3, extended in order. |

Deferred minors carried from the round-3 review (not blocking Task 1; final review triages):
missing import instructions in several tasks (`json` in agent/scheduler.py, `_raise`/
`SimpleNamespace`/`SlotError` in tests/test_service.py, accumulating names in tests/test_slots.py,
`agent.unity` in agent/slots.py); `FakeLauncher` lacking `runtime` and a real `state_dir`;
Task 5's `read_resource` allow-list asserted but not introduced; a `-k` selection in Task 1 that
may miss one of the eight tests it gates; Task 2's unique-index test possibly not exercising the
index it names; `park_idle`'s default departing mode; several stale twins in the self-review.

## Progress

Task 1: implementer a8beaef890285ae96, DONE_WITH_CONCERNS, commit 7c88e0c..3e52ce9, 139 -> 147 green.
Task 1: task review — spec ✅ (faithful, no extras); quality Approved with 3 Important, 1 Minor-with-teeth, 3 Minor.
Task 1: ⚠️ "cannot verify from diff" item (147/green/warning-free) resolved by the controller — I ran
  `python3 -W error -m unittest discover -s tests` myself at 3e52ce9: 147 tests, OK, no warnings.

Task 1: Ruling: the reviewer's Important finding on the pin echo CONFLICTS with the brief, which mandates
  echoing only on the `work` and `chat` branches. I rule for the finding and against the brief. Spec §6
  requires the pin be echoed "so a human can correct it before work starts"; the brief's two-branch echo is
  its argument for satisfying that, and the reviewer showed the argument fails — because the pin is stored
  before routing and the echo is guarded on `target is None`, a session whose FIRST event is elicit/steer
  writes the pin silently and then suppresses the echo for every later event, including the one that creates
  the work. The pin is then never announced at all. The spec is the binding authority and the plan is its
  argument, so the argument loses. Fix: echo the pin wherever the first activity is sent, not on two branches.
  Cost if wrong: one extra line of zh-CN in activities for session kinds that arguably did not need it.

Task 1: Ruling: I am including the reviewer's Minor "thin test" finding in fix round 1 rather than deferring
  it, against the skill's rule that minors never enter the loop. It is two assertions, the round is already
  open, and the reviewer's grounds are test hygiene — the test "would pass with the whole pin block deleted",
  which the rubric treats as a defect rather than a preference. Cost if wrong: two lines of scope in a round
  that was happening anyway.

Task 1: minor (deferred): `requested_ref` is the literal "default", not the resolved branch name.
Task 1: minor (deferred): `resolve_commit` still leaks `TimeoutExpired`, left for Task 4.
Task 1: minor (deferred): the pin-failure sentence promises Task 2 behaviour that has not landed.
Task 1: minor (deferred): `Ledger.create_work_item` stores `json.dumps(target)` unvalidated, so the
  Interfaces claim that `checked_target` is "the only way a target enters the ledger" is not literally true.
  No hole today — the receiver passes an already-validated session view.
Task 1: fix round 1/5 (4 addressed, 0 open — pin echo via acknowledge(); narrowed except; failure
  caching in remote_head; hardened the unpinned-path test; commits 3e52ce9..b9fb2b1)
Task 1: minor (deferred): an ack followed by a later raise inside `_decide_and_act` can still produce a
  second `_send` on the same `ack_id` from `process_one`'s handler. Pre-existing, untouched by this task.
Task 1: minor (deferred): a cached `remote_head` failure surfaces as `WorktreeError` where the first call
  raised `TimeoutExpired`. No caller distinguishes them today; flagged for Task 4.
Task 1: complete (commits 7c88e0c..b9fb2b1, review clean)

Session stopped here: the human scoped this run to Task 1. Tasks 2-11 remain.

Task 2: implementer a366b93e19d1f3c66, DONE_WITH_CONCERNS, commit b9fb2b1..99c94e5, 150 -> 164 green.
Task 2: task review — spec ✅ (verbatim-faithful, nothing missing); quality Approved with 1 Important,
  4 Minor. Reviewer rebuilt the schema in a scratch SQLite DB to verify both partial indexes really
  constrain what their names claim, and confirmed all four implementer concerns.
Task 2: the implementer fixed three defects in its own brief — the FIFO test would have raised TypeError
  because `release` leaves the slot `switching`; the unique-index test violated BOTH indexes so it proved
  nothing (this was a known round-3 finding I carried into the dispatch); and the threaded test would have
  died on `check_same_thread=True` while queueing only one request. All three verified by the reviewer.
Task 2: my carried ruling on the pin refusal executed correctly — both fixtures pinned; test_cli.py:191
  needed no change because the CLI refuses before reaching the ledger (reviewer verified at __main__.py:176).
Task 2: minor (deferred): a broken invariant surfaces as raw `sqlite3.IntegrityError` rather than
  `LedgerError` if Task 3's `park_idle` frees a slot still holding an active reservation. Flag for Task 3.
Task 2: minor (deferred): the 6-line cancel CASE UPDATE is verbatim in both `cancel_reservations` and
  `cancel`; brief-mandated to avoid nesting `_transaction()`, but a helper would remove the copy.
Task 2: minor (deferred): `assertTrue(token)` in the settlement-listing test asserts nothing about the
  behaviour under test.
Task 2: minor (deferred): `reservations.attempts` is schema-only — written by nothing, exposed by
  `_reservation_view`. Brief-specified; dead surface until a later task defines it.
Task 2: fix round 1/5 (1 addressed, 0 open — mode-preference sort now covered by
  test_interactive_prefers_an_open_editor_and_batch_prefers_a_closed_one; commits 99c94e5..52e8ca6)
Task 2: METHOD NOTE for every later task — mutation checks in this repo must clear `__pycache__`
  between steps. The Task 2 implementer hit a false FAILURE because a same-size mutation restored
  within the same second let CPython reuse a stale `.pyc`; the identical condition can produce a false
  PASS, which would silently validate a test that covers nothing. Carry this into later dispatches.
Task 2: re-review — ADDRESSED. Re-reviewer reproduced the mutation evidence independently on an isolated
  `git archive` with bytecode caching off: reversing `order`, replacing the sort key with slot_id alone,
  deleting the sort, and breaking ONLY the batch branch each fail the new test and nothing else (1/165).
Task 2: METHOD NOTE (supersedes the earlier one): use `python3 -B` or PYTHONDONTWRITEBYTECODE=1 for
  mutation checks rather than hand-clearing __pycache__ — it removes the stale-.pyc hazard structurally.
Task 2: minor (deferred): the mode preference is a sort, not a filter, so an interactive request still
  takes a closed slot when no open one is free. Correct per §7 as worded, but uncovered.
Task 2: complete (commits b9fb2b1..52e8ca6, review clean)

Task 3: implementer a4c3a1f0cee4bc813, DONE_WITH_CONCERNS, commit 52e8ca6..3eca690, 165 -> 172 green.
Task 3: task review — spec ✅ (nothing missing, no extra work beyond defect fixes); 3 Important, several
  Minor. Reviewer verified every claim empirically on real git/LFS repos rather than by reading.
Task 3: the implementer found six brief defects beyond the three I carried in. The valuable one:
  `ensure` recorded `parked_commit` as the freshly resolved origin head while `add_slot` returns early on
  an existing folder — after a restart the ledger would have claimed a commit the slot had never been on,
  and Task 4's switch would skip the checkout it needs. Fixed by reading back via `Worktrees.head`.
  Also: `git ls-files -v` tags skip-worktree `S` not `h`, so the brief's assertion could never pass.
Task 3: fix round 1 opened — busy-slot invariant untested (guard deletable with -k slots green);
  SLOT_ENV cannot unset an ambient GIT_LFS_SKIP_SMUDGE; materialize's credential-vs-reachability
  classification is bypassed because with smudge on the download happens inside `git worktree add`.
Task 3: minor (deferred): `checkout_commit` dead and untested in this commit; `Paths.editors` consumed by
  nothing; `slot_entry`'s two SlotError branches untested; the "each of the four parts" test exercises
  only part three; an `idle_open` record keeps a possibly stale `parked_commit`; spec amendment lines
  exceed that file's wrap width.
Task 3: the two items the implementer left alone (origin fetch on every start; a host without git-lfs)
  were judged correctly left — both are operator concerns above this task's scope.
Task 3: fix round 1/5 (3 addressed, 0 open; commits 3eca690..2875ca9). Re-reviewer verified each by
  mutation and by direct experiment — the busy-guard deletion now fails 4 tests, and the whole suite
  passes with GIT_LFS_SKIP_SMUDGE=1 exported, which is finding 2's real guarantee.
Task 3: Ruling: accepted the implementer's deliberate deviation — `add_slot` re-raises UNLABELLED when
  `_transfer_kind` returns None, rather than defaulting to "(reachability)". `git lfs fetch` only ever
  fails as a transfer, but `git worktree add` also fails locally (bad ref, path already registered), and
  labelling those reachability would send an operator to the network for a local fault. The re-reviewer
  built a table from real git messages confirming 401 and unresolvable-host still get labelled while
  local failures fall through. Cost if wrong: a rare transfer failure reaches the operator unlabelled.
Task 3: minor (deferred): a MISSING git-lfs binary is a local fault but its message matches
  TRANSFER_FAILURE and is labelled "(reachability)" — the misdirection the deviation argues against.
Task 3: minor (deferred): the same 401 still surfaces unlabelled on `checkout_commit` (which Task 4's
  switch uses, also smudge-on) and on `ensure_clone`'s `git clone`, which on a fresh host fails before
  `add_slot`'s try. Carry into Task 4.
Task 3: complete (commits 52e8ca6..2875ca9, review clean)

Task 4: implementer ada94995dcde1ce86, DONE_WITH_CONCERNS, commit 2875ca9..ff65051, 173 -> 192 green.
Task 4: the implementer proved by mutation that three brief tests could not exercise what they claimed —
  notably `editor_is_open` reading Temp/UnityLockfile, and `wait_for_quiet` giving up on its first
  timeout, BOTH survived the brief's own suite. I had fixed the lockfile defect in the plan text; its
  test was still toothless. Added 3 tests; all 13 mutants now killed.
Task 4: Ruling: `park`'s `idle_closed` branch must NOT call `clear_stale_lock(folder, lambda: False)`.
  Spec §7 line 353 is explicit — "the launcher removes it only after confirming the process is gone".
  `lambda: False` asserts that instead of checking, so `park(..., "batch")` against a genuinely open
  Editor would delete a LIVE lock, and Unity's one-Editor-per-folder guarantee is exactly what that file
  provides. Pass a real liveness check. Cost if wrong: a park pays one extra process check.
Task 4: Ruling: the three broad `except Exception` clauses in `switch` may keep HOLDING the slot — that
  is the safe direction, since releasing a slot in an unknown state risks a second Editor on the folder —
  but they must not label a programming error as a Unity `probe` failure. An operator reading
  `recover-slot` needs to know whether Unity misbehaved or FarmBot did. Distinguish the reason.
  Cost if wrong: one extra error class to carry through the probe path.
Task 4: acted beyond the brief's Files list (flagged by the implementer, accepted): `checkout_commit`
  now classifies credentials/reachability via `_transfer_kind`, closing the carried Task 3 finding —
  it is smudge-on, so it is where a 401 surfaces on every switch after the first.
Task 4: fix round 1/5 (3 addressed, 0 open; commits ff65051..4ce2390). Re-reviewer mutated all four
  clear_stale_lock call sites and confirmed no path from a failed terminate reaches the unlink: a
  SIGTERM that kills nothing leaves editor_is_open True, clear_stale_lock returns False, and the
  lock.exists() guard raises at stage `editor` — the lock survives AND the close fails.
Task 4: the implementer found a FOURTH site beyond my ruling — close_editor treated its own
  terminate() as proof of death. Accepted; it is the same defect class as the ruling.
Task 4: minor (deferred): close_editor's new message mentions a file that could not be removed, but a
  failing unlink escapes clear_stale_lock as a bare OSError and never reaches that line. Wording only.
Task 4: minor (deferred): FARMBOT_FAULTS includes TypeError/KeyError/IndexError, which a real MCP
  client can raise on a malformed Unity payload — that would mislabel an external fault as FarmBot's.
Task 4: minor (deferred): SlotError.fault has no production consumer yet; it reaches the operator only
  through message text until recover-slot and the worker land in later tasks.
Task 4: complete (commits 2875ca9..4ce2390, review clean)

Tasks 1-4 complete. Suite 195 green. Next: Task 5 (the identity probe).

PR #1 merged to main at b4efc61 on 2026-09-20. Tasks 5-11 continue on branch `phase1b-tasks-5-11`.

Task 5: implementer a9e6a7bbfcd76103c, DONE_WITH_CONCERNS, commit b4efc61..e00ad8f, 195 -> 214 green.
Task 5: task review — spec ✅ (every interface present, adversarial FarmQA parts verbatim, all three
  loopback servers closed as well as shut down); 3 Important, several Minor.
Task 5: THE MOST VALUABLE FINDING OF THE PLAN SO FAR. The implementer read the ACTUALLY INSTALLED
  Unity MCP plugin and server source and found two brief methods that could never have worked:
  (1) `discover_instance` matched instance entries on a `path` field the HTTP branch never emits —
  `services/resources/unity_instances.py`'s own docstring marks it "(stdio only)" — so EVERY
  interactive switch would have burned `start()`'s 120 s deadline; (2) `console_errors_since` read
  `result["lines"]` but `ReadConsole.cs:418` returns a bare list under `data` for that call shape,
  an AttributeError at a call site `switch()` does not wrap. Both verified by the reviewer against
  the same installed source. Neither was reachable by any amount of reading the plan.
Task 5: three further brief pieces could not stand — the `editor_state` fixture nested `play_mode`
  wrongly so the brief's own fresh-idle test would have failed; FarmQA's permanently-`unknown`
  loaded_source/server_environment checks would have made every aggregate `unknown` and every
  interactive switch a PERMANENT HOLD on the only slot; and `collect`/`UnityIdentity` had no tests.
Task 5: the sha1 instance-id rule is independently confirmed — I measured it during the spike
  (`sha1("<slot>/Assets")[:16]` == the live `54462c1bfe7b5261`), and the reviewer confirmed the code
  implements that rule, hashing both raw and resolved spellings and only selecting a listed id.
Task 5: fix round 1 opened — `source_stable` untested (both snapshots equally dirty, the "moving"
  half never runs); half of `editor_ready` untested and the gap is PERMISSIVE; the `_client` instance
  pin untested and a silent no-op exactly during a fresh slot's first interactive switch. Plus one
  promoted Minor: `console_errors_since` blames Unity (`fault="external"`) for an unparseable
  payload, which is a FarmBot gap that `recover-slot` cannot fix.
Task 5: minor (deferred): CONSOLE_KEYS includes an "entries" shape nothing emits.
Task 5: minor (deferred): hasGameTestDriver is stored but read by nothing yet.
Task 5: minor (deferred): the pidfile test's last two lines assert nothing.
Task 5: minor (deferred): discover_instance's SlotError omits slot_id, unlike its siblings.
Task 5: minor (deferred): `f"{path}/Assets"` is POSIX-correct; the Windows slot needs the
  forward-slash spelling Unity's dataPath uses. Carry into the Windows plan.
Task 5: fix round 1/5 (4 addressed, 0 open; commits e00ad8f..121c249). Re-reviewer mutated each half
  of editor_ready SEPARATELY and confirmed restoring the OLD silent skip — not just deletion — still
  fails 3 subtests, so the regression that actually shipped is caught rather than a crude mutant.
Task 5: Ruling: accepted the implementer's THIRD option on the _client instance pin. I offered silent
  skip or refusal; it resolves a missing id from the live server and pins either way. Its reasoning
  holds — a silent skip leaves the compile gate unpinned, and a refusal breaks the fresh-slot first
  switch because the id genuinely is not in the row yet and making it present would mean reordering
  Task 4's switch(). The re-reviewer confirmed a foreign Editor can never be selected: both match
  criteria derive from this slot's own folder, and zero matches raises ("editor","external"), which
  is retryable rather than a hold. Cost if wrong: one extra MCP round-trip per call on a fresh slot.
Task 5: minor (deferred): SlotPool.wait_for_quiet catches only TimeoutError, but wait_quiet is now a
  listing call on the fresh path — an Editor briefly absent during a post-refresh domain reload
  aborts the switch instead of polling to the deadline. Strictly gentler than the recorded-instance
  path, which holds. Fix in wait_for_quiet, and note it for Task 6.
Task 5: minor (deferred): _client re-discovers on every call, so a fresh slot's quiet wait opens two
  MCP sessions per poll; memoize per (mcp_address, folder).
Task 5: minor (deferred): Handler.seen records only the tool name, so pinning the WRONG id would
  still pass; record arguments for set_active_instance.
Task 5: minor (deferred): an instance entry matching by dataPath/hash but carrying no `id` yields
  None, which is in `listed` and gets pinned as None. Pre-existing, reachable through start() too.
Task 5: complete (commits b4efc61..121c249, review clean)

Task 6: implementer a49f2a4307cacd7e7, DONE_WITH_CONCERNS, commit 121c249..8db579c, 217 -> 239 green.
Task 6: **DEPENDENCY TASK 7 MUST HONOUR.** The brief's Step 5 called
  `components.launcher.stop_all_unsandboxed()` in serve's `finally` — a method TASK 7 creates. Left in
  it is an AttributeError on every shutdown, so the implementer omitted it. Task 7 MUST restore that
  call when it adds the method. Without it a service restart orphans a batch Editor still holding the
  slot folder, which is the exact hole I wrote kill_group/stop_unsandboxed into the plan to close.
Task 6: the `lambda: False` lock defect RECURRED — this time in `settle`, whose release gate returns
  True without asking when `self.mcp is None`, so the brief's version would delete a LIVE Editor's
  lock. Same class as my Task 4 ruling; the implementer caught and fixed it independently.
Task 6: task review — spec ✅, all four carried items resolved, no extra scope. 2 Important, 4 Minor.
Task 6: THE HEADLINE FINDING. The one-connection-per-thread rule — the entire reason this task exists
  — was untested in PRODUCTION wiring. Both guarding tests built SlotPool directly; mutating
  service.py to hand the pool the scheduler's connection left the service suite green, and because
  that ledger is check_same_thread=False the failure is SILENT transaction interleaving, not a crash.
Task 6: fix round 1/5 (2 addressed, 0 open; commits 8db579c..0d8e882). The implementer EXTENDED the
  reviewer's suggested assertion rather than taking it — the re-reviewer proved the extension is
  load-bearing by mutating service.py three ways, including `SlotPool(lambda: copy.copy(ledger))`,
  a distinct Ledger sharing one connection, which plain assertIsNot would have passed.
Task 6: Ruling: accepted release-and-park over hold for a `_hand_over` bookkeeping failure. Spec
  §7:352 ("a failing probe holds the slot") sits inside the Release paragraph and governs the
  quiescence probe when a worker is killed; the hand-over window runs no probe and precedes any
  worker holding the slot, which has just passed wait_for_quiet and the identity probe. Holding
  would signal recover-slot for a host fault the operator cannot fix there. Re-reviewer verified the
  token is safe (per-item, 0o600, hash-compared) and `failed` is reachable by retry(). Cost if
  wrong: a host-fault slot is reused where an operator might have wanted to inspect it.
Task 6: minor (deferred): `_give_the_slot_back` never sets `_departing[slot_id]`, so `park_idle`
  defaults to "batch" and records idle_closed on a slot whose interactive Editor is still up.
  Confined to acquire's preference sort and operator status; cosmetic with one slot. One line.
Task 6: minor (deferred): the pool's fail_queued paths post no Linear notice — the scheduler's
  _notify has no pool-side equivalent — so a repeatedly unwritable state_dir is visible only in
  `status` and audit. Pre-existing, shared with _switch_failed.
Task 6: complete (commits 121c249..0d8e882, review clean)

Task 7: implementer afaf7b71b8bb83269, DONE_WITH_CONCERNS, commit 0d8e882..bae5210, 241 -> 260 green.
Task 7: the Task 6 debt is PAID — stop_all_unsandboxed() is called in serve's finally, before the
  thread joins (the pool thread can be blocked in run_batch for up to batch_timeout), and guarded
  end-to-end by a test that starts a real process through the production launcher.
Task 7: **DEPENDENCY TASK 9 MUST HONOUR.** `Scheduler.stop` still cannot kill a batch Editor. The
  launcher methods exist (kill_group/stop_unsandboxed/stop_all_unsandboxed) but the wiring into
  Scheduler.stop is Task 9's per the brief's own Files list. Without it a Stop during a batch run
  leaves a real Editor running up to batch_timeout on a cancelled item. The exact one-liner is in
  the Task 7 report. Task 9 is titled "Stop and recovery never orphan a slot" — this IS that.
Task 7: the implementer verified the real dependencies rather than the brief — ran `codex mcp add`
  into a scratch CODEX_HOME to confirm codex 0.154.0 writes `[mcp_servers.x] url = "..."`.
Task 7: twelve brief defects resolved, and mutation checks caught THREE tests that looked like
  coverage and were not — including one the implementer had just written itself.
Task 7: task review — spec ✅; quality **Approved with NO Critical or Important findings**, the first
  task in this plan to clear review without a fix round. Reviewer ran five independent mutations, all
  correctly fatal, and confirmed the codex-cli 0.154.0 config claims against the installed binary.
Task 7: ProcessType is now Standard in agent/deploy.py:33, pinned on both the rendered string and the
  installed plist. The measured 7.5x tax on Unity work under launchd is gone.
Task 7: minor (deferred): no test plants a `.codex/config.toml` in a worker cwd to show it inert; the
  mechanism is asserted (decoy CODEX_HOME overridden) and the reviewer verified real codex honours
  it, but the dedicated regression guard is absent.
Task 7: minor (deferred): registration race in run_unsandboxed — `_unsandboxed[owner] = process`
  happens after Popen, so a stop_all_unsandboxed() landing in that microsecond window misses the
  child. The one remaining path that can orphan an Editor.
Task 7: minor (deferred): kill_group's Windows taskkill branch is untested and beyond the brief;
  consistent with the module's existing convention. Note for the Windows plan.
Task 7: complete (commits 0d8e882..bae5210, review clean, no fix round)

Task 8: implementer ad16bc82d2958c189, commit bae5210..880c430..63b4bcb, 260 -> 269 green.
Task 8: task review — spec ✅; two-phase acquisition verified as really two phases (await_resource
  voids the first worker's claim token, _reap leaves an awaiting_resource worker alone, launch
  injects tools only for the fresh one). The SKILL.md standing rules the brief's replacement range
  would have silently deleted were both preserved and verified in the file.
Task 8: Ruling: `release-resource --outcome unclean` must be token-verified. The earlier ruling that
  cancel/recover/retry are unauthenticated covers OPERATOR commands on a single-user host; this is a
  WORKER command and the token exists so a sandboxed worker can prove which reservation it speaks
  for. The asymmetry was backwards — the benign outcome authenticated, the consequential one (taking
  the host's only slot out of the pool) open to any non-empty string, including the claim token the
  quiescent path refuses. Implemented as `Ledger.hold_owned`, a verifying wrapper, because `hold`
  must stay token-free for the pool: `settle` holds precisely BECAUSE the token file is gone.
  Cost if wrong: one extra hash comparison on a path an operator can already undo with recover-slot.
Task 8: Ruling: accepted the implementer's refusal to add a duplicate test. It declined the second
  half of a finding, showing the coverage already existed and proving it by mutation. The
  re-reviewer ran a further targeted mutation and confirmed the subTest exercises exactly settle's
  missing-token branch. Declining a duplicate is correct behaviour, not a shortfall.
Task 8: minor (deferred): resolve_token says "claim token required" on the one verb needing the
  reservation token; service.py hardcodes the open-reservation tuple where RESERVATION_OPEN exists;
  enqueue's session= is unreachable; `reservations` returns every reservation ever.
Task 8: complete (commits bae5210..63b4bcb, review clean)

Task 9: implementer a09bb8b829e154df8, commit 63b4bcb..a4f0130..d0eeb37, 269 -> 274 green.
Task 9: Task 7's debt PAID — Scheduler.stop reaches the pool-started Editor before the worker kill,
  ordering mutation-proven with an identical end state. FakeLauncher gained stop_unsandboxed.
Task 9: the brief handed over ANOTHER vacuous test — the reviewer installed the brief's end-state-only
  waiting test against pre-change scheduler.py and it PASSED, because Ledger.cancel had cancelled
  queued reservations since Task 2. The implementer caught it and rewrote a commit message that
  described a bug which did not exist.
Task 9: Ruling: I ruled AGAINST the implementer's out-of-scope call on the Stop-during-switch race,
  and the reviewer's correction is why. The implementer thought it was Task 7's microsecond
  registration race; it is a different race whose window CONTAINS the whole switch() — a 3.7 GB
  detached checkout plus LFS plus an Editor refresh — so minutes wide, on the normal path of every
  batch grant. A human pressed Stop and the machine ground a Unity Editor for up to batch_timeout on
  the only slot. The slot did come back, so the task's title survived literally but not in spirit,
  and spirit is what criterion 2 is about. Cost if wrong: a small re-check on a working path, plus
  scope the brief did not ask for. Implementer agreed my correction of the window was right.
Task 9: Ruling: accepted return-over-raise in run_batch's new re-check. Every _switch_failed arm is
  wrong for a Stop — `probe` HOLDS the slot, the very orphan this task is named for — while
  returning reaches resume's LedgerError and the existing cancelled-mid-switch path. Re-reviewer
  verified _hand_over discards run_batch's return value, the slot is released and parked rather than
  left busy, and _batch_result already substitutes an explicit gap so no absent result is read as
  evidence. Cost if wrong: a silent return where a raise would have been louder.
Task 9: minor (deferred): recover-slot firing mid-switch hands the worker resource=None with no
  batch_result key, which reads as "no slot" rather than "no evidence". Pre-existing.
Task 9: complete (commits 63b4bcb..d0eeb37, review clean)

Task 10: implementer ab451046072e03d69, commit d0eeb37..a338fb9..dba9f34, 274 -> 280 green.
Task 10: **PHASE 1 DONE-CRITERION 3 IS PROVED.** Two items serialize on the single slot through the
  two-phase flow, one batch one interactive, each switched to its own pinned commit and parked back
  on origin/main between them. Both arrival orders pass.
Task 10: the reviewer designed its own mutations rather than replaying the implementer's. V1 dropped
  the UNIQUE index AND acquire's free-state gate so two owners were physically legal — the
  assertLessEqual(released_at, acquired_at) the implementer had called belt-and-braces killed it
  independently. V4 made park() skip the checkout when another request was queued (the plausible
  later "optimisation") and the observed heads collapsed from [a, main, b, main] to [a, b, main],
  confirming the strengthening really proves "parked back on main BETWEEN them".
Task 10: the proof exposed a REAL defect I had logged in Task 6 as a cosmetic deferred minor.
  `park_idle` read the departing mode from an in-memory note settle() writes, but a worker's own
  `release-resource` runs in the WORKER'S process, so the service's note is never written — every
  normally-released interactive slot was parked idle_closed with its Editor open, against spec §7.
  Only an end-to-end proof could surface it. Fixed with Ledger.last_reservation_on; _departing gone.
  LESSON: a reviewer's "cosmetic, confined to X" on a cross-process assumption deserves suspicion.
Task 10: Ruling: accepted the flipped assertion (idle_closed -> idle_open) in a Task 6 test. An
  implementer changing an existing test to match new behaviour is how a regression gets laundered,
  so I had it verified hard. The OLD assertion encoded the bug: open_editor runs before mcp.refresh
  where the Stop lands, park() returns idle_open only when the mode is interactive AND
  editor_is_open() is live, and the old code wrote idle_closed while clear_stale_lock two lines
  later declined to delete the lock BECAUSE the Editor was alive — self-contradictory in one
  function. Cost if wrong: a Task 6 test now asserts the opposite of what it did.
Task 10: fix round 1/5 (2 addressed). The batch half's Unity run had been unasserted — both proofs
  passed with run_batch disabled entirely, so "both items NEED UNITY" was proved only as a
  reservation mode. Now pinned by durable evidence (the launcher's own prompt.md), and the
  re-reviewer's N1/N4 pair proved the argv and batch_result assertions are orthogonal: neither can
  carry the other, and no fake collaborator can satisfy both without a real parseable non-zero run.
Task 10: minor (deferred): _switch_failed catches only SlotError from park(); a LedgerError/OSError
  would escape and strand the item in awaiting_resource. park_idle has the identical shape —
  pre-existing exposure the fix widens slightly rather than introduces.
Task 10: minor (deferred): the aggregate == ["match"] assertion is tautological against FakeMcp.probe.
Task 10: complete (commits d0eeb37..dba9f34, review clean)

Tasks 1-10 complete. Only Task 11 remains: the LIVE rehearsal on the real slot and a real Editor.

=== TASK 11: live rehearsal, started 2026-09-20 ===
Ruling: Task 11 is run by the controller inline, NOT dispatched to an implementer. It writes no code;
  it opens a real Unity Editor on the operator's machine, restarts a launchd service, and needs
  real-time diagnosis against the spike's measurements. The SDD loop's value (fresh context per code
  task) does not apply. Cost if wrong: no per-task review gate on a task that produces a report.

Live findings BEFORE the rehearsal, from real delegations on 2026-09-20:
- criterion 1 proved live (FARM-1230, FARM-1238): webhook -> session -> worker -> started comment.
- criterion 2 proved live: Stop acknowledged in 0.133s against a 5s budget; round trip 1.09s; the
  worker died, no worktree orphaned.
- criterion 5 STILL UNPROVEN after three attempts. Twice my fault (FARM-1127, FARM-1230 were already
  fixed — I picked from a day-old listing). The third (FARM-1238) was genuinely open and FarmBot
  correctly found the fix is not client code: common PR #131 fixed the source tables, the client/hive
  EXPORTED artifacts are stale. It decoded the deployed protobuf, refused to call static analysis
  runtime evidence, and blocked. Right answer.
- GAP FOUND: FarmBot cannot be asked to run a config export. ConfigProtobufExporter and
  NetworkProtobufExporter both expose ExportFromCommandLine(), `fix` writes all four repos and may
  request unity_slot — but the launcher's only argv shape is batch_test_command, which hardcodes
  -runTests. `grep -rn executeMethod agent/ skills/` is empty. Needs a second batch shape plus a gate
  on which designer-source pin to export from. Phase 3+, not 1b.
- GAP FOUND (1b's checklist): the blocked path cites an unpublished commit. FarmBot committed a
  36-line report as 4aed437d0 on branch farmbot/farm-1238-… and referenced that SHA in its Linear
  blocker comment, but never pushed. The reference is unresolvable for anyone but this machine.
- The launcher has NEVER actually run Unity: last_switch_at is None, zero unity-batch.json, zero
  unity-tests.xml, zero identity_observations. Every Unity claim rests on FakeUnity. That is what
  this rehearsal exists to settle.
Task 11: HALTED at Step 3, findings written to
  docs/superpowers/spikes/2026-09-20-live-rehearsal-findings.md. Steps 1-2 passed (slot adopted, not
  rebuilt). Six findings, none reachable from the 280 passing tests:
  1. A worker CLAIMED a hive fix with three passing tests; all four farmbot branches in farm-hive are
     0 commits ahead of main. Only two docs commits exist. The delegated run on the same issue an
     hour earlier was scrupulous about evidence; this one was not. Same skill, opposite discipline.
  2. BLOCKS THE OFFLINE PATH: outbox dedup keys on (issue_id, fingerprint, generation, kind) and
     deliberately excludes item_id, so a second work item on an unchanged issue silently receives the
     FIRST item's confirmed row, cannot post, cannot finish, and is reaped as `failed`. Delegated ->
     `blocked` with a comment; enqueued -> `failed` with silence, for identical work. Task 11 runs on
     `enqueue`, so this must be fixed before Steps 3-9 can complete.
  3. Failing sweeps the worktree, so finding 1's claim can no longer be adjudicated.
  4. No -executeMethod path: the export capability and the authority both exist, the request does not.
  5. The blocked path cites an unpublished commit SHA in a Linear comment.
  6. Three real delegations, zero slot requests — the Unity path is reached far less often than the
     design assumes, so Step 3 must be driven by hand rather than by a real bug.
Task 11: Ruling: halt rather than push on. Finding 2 blocks the very path the remaining steps use, so
  running them now would measure a broken harness. Cost if wrong: the Unity path stays unproven a
  little longer, which it already was.

=== TASK 12 (not in Plan 1b — arose from Task 11's live findings) ===
Task 12: implementer ac4b558c4617f489c, branch fix-outbox-dedup-and-evidence off main bdd3dd8.
  Commits 4cd1bbd (Fix A), 6812f98 (Fix B), 9664c6f (fix round 1). 280 -> 302 green.
Task 12: Fix A — a second work item on an unchanged issue can now reach a terminal state by
  borrowing the existing outbox row, with its own words preserved and surfaced. Fix B — a failed
  item's work is committed to its branch before the worktree is swept, so the evidence survives.
Task 12: I WAS WRONG about `kind` and the implementer corrected me, confirmed from the schema:
  kind is only started/blocker/delivery, an outcome class rather than a conclusion, so two items
  can collide on the same kind with materially different content. A borrow therefore DOES discard
  the second item's prose — which is why it had to be surfaced rather than merely audited.
Task 12: the reviewer found a consequence neither of us saw — a second item delivering a DIFFERENT
  PR URL passed finish while the issue comment named only the first item's PR, so the ledger would
  record a PR never announced anywhere a human reads. Now refused, and the implementer verified the
  refusal strands nobody: a delivery row at the key means item 1 delivered, so item 2's blocker key
  is free. The re-reviewer rebuilt those sequences rather than trusting the report.
Task 12: Ruling: surface borrowed comments through `status` rather than a stdout line. prepare_comment
  and finish run in the WORKER's process, where the CLI already prints "deduplicated": true; the
  service never calls them, so there is no service-log moment to hook. Deliberately NOT added to
  Ledger.status(), which the scheduler calls twice a second and which would then full-scan an
  unindexed, ever-growing audit table. Cost if wrong: a borrow is visible only to an operator who
  runs status, not in the service log.
Task 12: minor (deferred): the prs refusal is not restricted to kind == "delivery", so a borrowed
  blocker carrying prs is refused with a message saying "a borrowed delivery"; the service.py copy
  of the status merge is asserted by no test; _git names commit failures from args[0] so they read
  `git -c failed:`; nothing prunes farmbot/wip/* from the bare clone.
Task 12: complete (commits bdd3dd8..9664c6f, review clean)

Task 11 is now UNBLOCKED: the enqueue path can reach a terminal state.
Task 11 STEP 3: PROVED. The launcher ran Unity for real — pid 46016, parent 45779 = serve, not a
  codex worker. Slot switched 7d886c72e -> 6d5b46fbe (last_switch_at no longer None), 4414 tests in
  130.9s, exit 2 with total>0 recorded as "ran", fresh worker pid 46405 resumed with batch_result,
  slot parked back clean. Known-red baseline matched EXACTLY: 26 of 4414 vs Task 0's 26 of 4388.
  PR #4's dedup fix observed working in production (`deduplicated started` at 16:51:52).
Task 11 STEP 4: HALTED with two real defects, both invisible to the suite (fake MCP, no C# executed).
  (1) FIXED: the probe read .Location on the dynamic assembly execute_code creates to run it —
      NotSupportedException, all checks unknown, slot held. Task 5 had removed FarmQA's four-name
      filter for good architectural reasons and two reviewers approved; the reasoning was right and
      the result was broken. 270 assemblies here vs FarmQA's 4. Verified fixed live. NO TEST POSSIBLE.
  (2) OPEN, needs a design decision: ready() requires observed_at_unix_ms within 10s, but
      EditorStateCache rebuilds the snapshot ONLY WHEN STATE CHANGES (its own comments say so at
      :303 and :348). The field means "when state last changed", not a heartbeat. Measured age >117s
      with sequence frozen at 3 while the Editor was demonstrably idle and usable. Nothing a client
      can call forces a rebuild — refresh_unity, execute_code and manage_editor all leave it frozen.
      Candidate 1: derive readiness from the probe's own live isCompiling/isUpdating/isPlaying.
      Candidate 2: find a force-rebuild path. Candidate 1 looks stronger — it removes the coupling
      to a third-party cache's optimisation policy, which is what broke here.
  Proved anyway: the sha1 instance rule holds in production (e7fe013d9909e41a matched exactly), the
  MCP server self-starts, and the hold/recover path is sound — clean slot both times.

TASK 13 (readiness gate) implemented at 34f6d53 on task-13-readiness-gate. Suite 302 -> 306, green and
  warning-free. 19 mutations, zero survivors.
  RULING: the implementer OVERTURNED half my brief and was right. I proposed splitting ready() into a lax
  precondition ("nothing positively says busy") plus a strict probe-sourced verdict. They kept ONE ready()
  and deleted exactly three clauses -- the 10s bound, staleness.is_stale, advice.ready_for_tools -- keeping
  every busy flag required to be explicitly False. My premise was too pessimistic: a stale snapshot saying
  idle IS proof of idleness here, because every flag ready() reads has a change trigger that forces a
  rebuild. My version would have bought nothing and cost the "missing booleans never pass" property.
  THE FINDING THAT JUSTIFIES THE WHOLE TASK, verified by me in the plugin source: the bound was not merely
  useless, it was INVERTED. GetSnapshot re-stamps observed_at_unix_ms to the read time whenever the Editor
  is NOT the active application (EditorStateCache.cs:529-532), leaving the flags untouched -- the plugin's
  own comment says "the cached timestamp grows stale even though the data is current". So a BACKGROUNDED
  Editor always looked fresh however old its flags were, while a FOREGROUNDED one -- every slot this pool
  launches and leaves alone -- was refused for flags that were current. The clause admitted precisely the
  case it could not vouch for and rejected the one it could. It also explains the 117s measurement: the
  freeze requires isApplicationActive == true.
  Both discarded clauses were circular, confirmed in the SERVER source (mcpforunityserver
  services/resources/editor_state.py:186-207): is_stale = age_ms > 2000 on the same timestamp, and is_stale
  is what appends "stale_status" to blocking_reasons, whose emptiness IS ready_for_tools. Its only other
  blockers are compiling/domain-reload/tests-running (all checked directly) and
  assets.refresh.is_refresh_in_progress, which the installed plugin hardcodes false (EditorStateCache.cs:473-478).
  BRIEF DEFECT to remember: I wrote that ready() has two call sites. It has THREE -- UnityIdentity.quiescent
  (agent/slots.py:947) is spec 7's interactive RELEASE predicate and had the same failure mode. An
  implementer following my blast-radius section literally would have missed it. Write blast radius by
  grepping, not from memory.
  Known and accepted: losing the upper bound also loses the lower one, so a clock-skewed Editor reporting
  the future is no longer refused on that basis -- harmless, since the server's own max(0, now-observed)
  clamped a negative age to zero anyway. A sub-second race on tests.is_running survives the 1s throttle,
  pre-existing and unworsened. Nothing verified against a live Editor; that belongs to Step 4's re-run.
  Two Opus reviewers dispatched: adversarial correctness, and integration/blast-radius.
  REVIEW ROUND (2 Opus reviewers, both REQUEST CHANGES, both APPROVED the production change itself):
    The adversarial reviewer tried to break the "every flag has a change trigger" argument and could not,
    then strengthened it: _lastUpdateTimeSinceStartup is assigned ONLY on the rebuild path (:363), never on
    the early return, so the 1s throttle can only bite when the previous rebuild was under 1s ago. Hence
    age > 1s IMPLIES flags are current. The old gate's admit set was age <= 2s (is_stale) -- it admitted
    EXACTLY the window where lag is possible and refused exactly the samples that were provably accurate.
    All seven flags verified covered one at a time; five are in hasChanges directly, and the two that are
    not (is_changing, is_domain_reload_pending) each carry their own unthrottled ForceUpdate.
    AGREED MAJOR, found independently by both and confirmed by me: re-injecting is_stale leaves 306 GREEN.
    Same for ready_for_tools, and for both. Only the 10s bound is pinned. Root cause is the base fixture
    (tests/test_identity.py:136-137) hardcoding is_stale=False / ready_for_tools=True, which ALSO means the
    two headline tests assert a payload the real server cannot emit (old timestamp WITH is_stale False).
    Fix: derive the fixture's staleness/advice from observed_at_unix_ms the way the server does. One change
    closes the realism gap and kills all three mutants. Dangerous because is_stale is a 2s bound -- TIGHTER
    than the one removed -- so re-introducing it restores this bug in a worse form with a green suite.
    MY ERROR, recorded so it is not repeated: reviewer 2 reported a CRITICAL "silent revert in the working
    tree" -- that was MY OWN mutation check running while it read the tree. File was restored and shasum
    verified, but the read landed inside the window. DO NOT mutate a working tree while a reviewer is
    reading it. From the outside it is indistinguishable from a real revert.
    OVERRULED: reviewer 1's MINOR-3 proposing before['sequence'] != after['sequence'] as a liveness check.
    Direction is backwards -- on a correctly idle Editor the sequence does NOT move, so requiring change
    would re-create the bug just fixed. The useful form is EQUALITY (state did not move across the probe,
    analogous to source_stable). Deferred deliberately rather than adopted: adding a gate condition that
    cannot be verified against a live Editor is exactly how both of this plan's defects arrived, and
    collect() already records both snapshots, so Step 4's re-run supplies the data for free.
    Also confirmed by reviewer 2: collect() never raises across 87 malformed inputs; no consumer of the
    identity row assumes recency; quiescent's liveness fallback is TRUE (get_editor_state round-trips to
    Unity's main thread via TransportCommandDispatcher, so a wedged Editor answers nothing and the slot is
    held). Two pre-existing, unreachable caveats noted: expected.get() outside the try, and a non-finite
    float in the raw snapshot would hit Ledger._json's allow_nan=False.
  FIX ROUND f54accb + SCOPED RE-REVIEW: APPROVE. The fixture now derives staleness/advice from
  observed_at_unix_ms exactly as the server does, and state() RAISES if a caller passes either key, so the
  impossible pairing cannot come back by convention -- it is structurally refused. I verified all four
  mutants now die (4/4/4/5 failures) and that agent/identity.py is docstrings-only by AST comparison.
  The re-reviewer did not eyeball the mirror: it extracted both functions by AST, froze the clock, and
  diffed 10,010 payloads (26 timestamps x 7 compilation x 5 tests x 11 assets shapes) including nan, inf,
  bool, str, complex and missing-key. ZERO divergences. That was the one place a failure would have looked
  exactly like success -- a DIFFERENT impossible payload -- and it is not present.
  Two cosmetic MINORs fixed inline by me rather than another round: added "sequence" to the base fixture
  (the server always emits it, and the deferred sequence work needs a fixture that can express it), and
  reworded a docstring that credited the new ASSERTIONS with killing the mutants when the DERIVATION is
  what kills them -- proven by the re-reviewer running with the assertions stripped and getting the same
  four failures. Worth fixing precisely because this task's thesis is that a docstring must not claim
  coverage the code does not provide.
  TASK 13 COMPLETE. Suite 306 green and warning-free. Still unverified against a live Editor by design;
  Task 11 Step 4's re-run is what settles it.
