# SDD ledger — plan: docs/superpowers/plans/2026-09-19-phase1b-unity-slots.md

Spec: docs/superpowers/specs/2026-09-17-farm-linear-agent-design.md (read; §5 §6 §7 §8 §10 §17 §18 bind this plan).
Branch: phase1b-unity-slots, cut from main at 7c88e0c.
Scope this session: the human asked for **Task 1 only**, then a check-in. This overrides the
skill's continuous-execution default.

## Rulings (pre-flight)

Ruling: branch in the main checkout, not a git worktree — `.local/` is git-ignored and holds
FarmBot's bare clones (`.local/repos/*.git`, 876 MB of LFS objects) and the already-built
`slot-1` (6.1 GB, imported 2026-09-19). A fresh worktree would have none of them, so Tasks 3+
would rebuild ~6 GB and re-import for no gain, and the spike's measured slot would be wasted.
Cost if wrong: implementation commits land on a branch in the shared checkout rather than an
isolated directory; recoverable by `git worktree add` later, at the cost of a re-import.

Ruling: dispatch implementers and reviewers on Opus, against the skill's Model Selection advice
to economise. The human rejected a Haiku/Sonnet mix on an earlier plan. Cost if wrong: higher
token spend per task.

## Pre-flight scan

The whole-plan cross-task scan was performed by three adversarial review passes before execution
(60, 31 and 30 findings). Blockers and the one design defect are closed; what remains is recorded
below as deferred minors so the final review can triage them.

| Check | Result |
|---|---|
| Task 1 vs Global Constraints | consistent — Task 1 adds no Unity, no slot, no network; tests use real temp SQLite |
| Task 1 produces → Task 2 consumes | `work_items.target_json` / pinned `commit_sha`; Task 2's `await_resource` refuses an item with no pin. Task 1 must actually write the pin or Task 2's tests cannot pass. Verified: Task 1 Step 5 writes it at receipt. |
| Task 1 vs agent/receiver.py reality | `receiver.py:167` really is `def _decide_and_act`; the plan now anchors its replacement on text, not line numbers. Verified by hand 2026-09-20. |
| Task 1 self-consistency (tests vs code) | claims +8 → 147; three files named. Unverified by hand — left to the task review. |
| Tasks sharing agent/ledger.py | 1, 2, 7, 8, 9 — serialised by task order; no parallel dispatch. |
| Tasks sharing agent/slots.py | 3, 4, 5, 6, 7 — created in 3, extended in order. |

Deferred minors carried from the round-3 review (not blocking Task 1; final review triages):
missing import instructions in several tasks (`json` in agent/scheduler.py, `_raise`/
`SimpleNamespace`/`SlotError` in tests/test_service.py, accumulating names in tests/test_slots.py,
`agent.unity` in agent/slots.py); `FakeLauncher` lacking `runtime` and a real `state_dir`;
Task 5's `read_resource` allow-list asserted but not introduced; a `-k` selection in Task 1 that
may miss one of the eight tests it gates; Task 2's unique-index test possibly not exercising the
index it names; `park_idle`'s default departing mode; several stale twins in the self-review.

## Progress

Task 1: implementer a8beaef890285ae96, DONE_WITH_CONCERNS, commit 7c88e0c..3e52ce9, 139 -> 147 green.
Task 1: task review — spec ✅ (faithful, no extras); quality Approved with 3 Important, 1 Minor-with-teeth, 3 Minor.
Task 1: ⚠️ "cannot verify from diff" item (147/green/warning-free) resolved by the controller — I ran
  `python3 -W error -m unittest discover -s tests` myself at 3e52ce9: 147 tests, OK, no warnings.

Task 1: Ruling: the reviewer's Important finding on the pin echo CONFLICTS with the brief, which mandates
  echoing only on the `work` and `chat` branches. I rule for the finding and against the brief. Spec §6
  requires the pin be echoed "so a human can correct it before work starts"; the brief's two-branch echo is
  its argument for satisfying that, and the reviewer showed the argument fails — because the pin is stored
  before routing and the echo is guarded on `target is None`, a session whose FIRST event is elicit/steer
  writes the pin silently and then suppresses the echo for every later event, including the one that creates
  the work. The pin is then never announced at all. The spec is the binding authority and the plan is its
  argument, so the argument loses. Fix: echo the pin wherever the first activity is sent, not on two branches.
  Cost if wrong: one extra line of zh-CN in activities for session kinds that arguably did not need it.

Task 1: Ruling: I am including the reviewer's Minor "thin test" finding in fix round 1 rather than deferring
  it, against the skill's rule that minors never enter the loop. It is two assertions, the round is already
  open, and the reviewer's grounds are test hygiene — the test "would pass with the whole pin block deleted",
  which the rubric treats as a defect rather than a preference. Cost if wrong: two lines of scope in a round
  that was happening anyway.

Task 1: minor (deferred): `requested_ref` is the literal "default", not the resolved branch name.
Task 1: minor (deferred): `resolve_commit` still leaks `TimeoutExpired`, left for Task 4.
Task 1: minor (deferred): the pin-failure sentence promises Task 2 behaviour that has not landed.
Task 1: minor (deferred): `Ledger.create_work_item` stores `json.dumps(target)` unvalidated, so the
  Interfaces claim that `checked_target` is "the only way a target enters the ledger" is not literally true.
  No hole today — the receiver passes an already-validated session view.
Task 1: fix round 1/5 (4 addressed, 0 open — pin echo via acknowledge(); narrowed except; failure
  caching in remote_head; hardened the unpinned-path test; commits 3e52ce9..b9fb2b1)
Task 1: minor (deferred): an ack followed by a later raise inside `_decide_and_act` can still produce a
  second `_send` on the same `ack_id` from `process_one`'s handler. Pre-existing, untouched by this task.
Task 1: minor (deferred): a cached `remote_head` failure surfaces as `WorktreeError` where the first call
  raised `TimeoutExpired`. No caller distinguishes them today; flagged for Task 4.
Task 1: complete (commits 7c88e0c..b9fb2b1, review clean)

Session stopped here: the human scoped this run to Task 1. Tasks 2-11 remain.

Task 2: implementer a366b93e19d1f3c66, DONE_WITH_CONCERNS, commit b9fb2b1..99c94e5, 150 -> 164 green.
Task 2: task review — spec ✅ (verbatim-faithful, nothing missing); quality Approved with 1 Important,
  4 Minor. Reviewer rebuilt the schema in a scratch SQLite DB to verify both partial indexes really
  constrain what their names claim, and confirmed all four implementer concerns.
Task 2: the implementer fixed three defects in its own brief — the FIFO test would have raised TypeError
  because `release` leaves the slot `switching`; the unique-index test violated BOTH indexes so it proved
  nothing (this was a known round-3 finding I carried into the dispatch); and the threaded test would have
  died on `check_same_thread=True` while queueing only one request. All three verified by the reviewer.
Task 2: my carried ruling on the pin refusal executed correctly — both fixtures pinned; test_cli.py:191
  needed no change because the CLI refuses before reaching the ledger (reviewer verified at __main__.py:176).
Task 2: minor (deferred): a broken invariant surfaces as raw `sqlite3.IntegrityError` rather than
  `LedgerError` if Task 3's `park_idle` frees a slot still holding an active reservation. Flag for Task 3.
Task 2: minor (deferred): the 6-line cancel CASE UPDATE is verbatim in both `cancel_reservations` and
  `cancel`; brief-mandated to avoid nesting `_transaction()`, but a helper would remove the copy.
Task 2: minor (deferred): `assertTrue(token)` in the settlement-listing test asserts nothing about the
  behaviour under test.
Task 2: minor (deferred): `reservations.attempts` is schema-only — written by nothing, exposed by
  `_reservation_view`. Brief-specified; dead surface until a later task defines it.
Task 2: fix round 1/5 (1 addressed, 0 open — mode-preference sort now covered by
  test_interactive_prefers_an_open_editor_and_batch_prefers_a_closed_one; commits 99c94e5..52e8ca6)
Task 2: METHOD NOTE for every later task — mutation checks in this repo must clear `__pycache__`
  between steps. The Task 2 implementer hit a false FAILURE because a same-size mutation restored
  within the same second let CPython reuse a stale `.pyc`; the identical condition can produce a false
  PASS, which would silently validate a test that covers nothing. Carry this into later dispatches.
Task 2: re-review — ADDRESSED. Re-reviewer reproduced the mutation evidence independently on an isolated
  `git archive` with bytecode caching off: reversing `order`, replacing the sort key with slot_id alone,
  deleting the sort, and breaking ONLY the batch branch each fail the new test and nothing else (1/165).
Task 2: METHOD NOTE (supersedes the earlier one): use `python3 -B` or PYTHONDONTWRITEBYTECODE=1 for
  mutation checks rather than hand-clearing __pycache__ — it removes the stale-.pyc hazard structurally.
Task 2: minor (deferred): the mode preference is a sort, not a filter, so an interactive request still
  takes a closed slot when no open one is free. Correct per §7 as worded, but uncovered.
Task 2: complete (commits b9fb2b1..52e8ca6, review clean)

Task 3: implementer a4c3a1f0cee4bc813, DONE_WITH_CONCERNS, commit 52e8ca6..3eca690, 165 -> 172 green.
Task 3: task review — spec ✅ (nothing missing, no extra work beyond defect fixes); 3 Important, several
  Minor. Reviewer verified every claim empirically on real git/LFS repos rather than by reading.
Task 3: the implementer found six brief defects beyond the three I carried in. The valuable one:
  `ensure` recorded `parked_commit` as the freshly resolved origin head while `add_slot` returns early on
  an existing folder — after a restart the ledger would have claimed a commit the slot had never been on,
  and Task 4's switch would skip the checkout it needs. Fixed by reading back via `Worktrees.head`.
  Also: `git ls-files -v` tags skip-worktree `S` not `h`, so the brief's assertion could never pass.
Task 3: fix round 1 opened — busy-slot invariant untested (guard deletable with -k slots green);
  SLOT_ENV cannot unset an ambient GIT_LFS_SKIP_SMUDGE; materialize's credential-vs-reachability
  classification is bypassed because with smudge on the download happens inside `git worktree add`.
Task 3: minor (deferred): `checkout_commit` dead and untested in this commit; `Paths.editors` consumed by
  nothing; `slot_entry`'s two SlotError branches untested; the "each of the four parts" test exercises
  only part three; an `idle_open` record keeps a possibly stale `parked_commit`; spec amendment lines
  exceed that file's wrap width.
Task 3: the two items the implementer left alone (origin fetch on every start; a host without git-lfs)
  were judged correctly left — both are operator concerns above this task's scope.
Task 3: fix round 1/5 (3 addressed, 0 open; commits 3eca690..2875ca9). Re-reviewer verified each by
  mutation and by direct experiment — the busy-guard deletion now fails 4 tests, and the whole suite
  passes with GIT_LFS_SKIP_SMUDGE=1 exported, which is finding 2's real guarantee.
Task 3: Ruling: accepted the implementer's deliberate deviation — `add_slot` re-raises UNLABELLED when
  `_transfer_kind` returns None, rather than defaulting to "(reachability)". `git lfs fetch` only ever
  fails as a transfer, but `git worktree add` also fails locally (bad ref, path already registered), and
  labelling those reachability would send an operator to the network for a local fault. The re-reviewer
  built a table from real git messages confirming 401 and unresolvable-host still get labelled while
  local failures fall through. Cost if wrong: a rare transfer failure reaches the operator unlabelled.
Task 3: minor (deferred): a MISSING git-lfs binary is a local fault but its message matches
  TRANSFER_FAILURE and is labelled "(reachability)" — the misdirection the deviation argues against.
Task 3: minor (deferred): the same 401 still surfaces unlabelled on `checkout_commit` (which Task 4's
  switch uses, also smudge-on) and on `ensure_clone`'s `git clone`, which on a fresh host fails before
  `add_slot`'s try. Carry into Task 4.
Task 3: complete (commits 52e8ca6..2875ca9, review clean)

Task 4: implementer ada94995dcde1ce86, DONE_WITH_CONCERNS, commit 2875ca9..ff65051, 173 -> 192 green.
Task 4: the implementer proved by mutation that three brief tests could not exercise what they claimed —
  notably `editor_is_open` reading Temp/UnityLockfile, and `wait_for_quiet` giving up on its first
  timeout, BOTH survived the brief's own suite. I had fixed the lockfile defect in the plan text; its
  test was still toothless. Added 3 tests; all 13 mutants now killed.
Task 4: Ruling: `park`'s `idle_closed` branch must NOT call `clear_stale_lock(folder, lambda: False)`.
  Spec §7 line 353 is explicit — "the launcher removes it only after confirming the process is gone".
  `lambda: False` asserts that instead of checking, so `park(..., "batch")` against a genuinely open
  Editor would delete a LIVE lock, and Unity's one-Editor-per-folder guarantee is exactly what that file
  provides. Pass a real liveness check. Cost if wrong: a park pays one extra process check.
Task 4: Ruling: the three broad `except Exception` clauses in `switch` may keep HOLDING the slot — that
  is the safe direction, since releasing a slot in an unknown state risks a second Editor on the folder —
  but they must not label a programming error as a Unity `probe` failure. An operator reading
  `recover-slot` needs to know whether Unity misbehaved or FarmBot did. Distinguish the reason.
  Cost if wrong: one extra error class to carry through the probe path.
Task 4: acted beyond the brief's Files list (flagged by the implementer, accepted): `checkout_commit`
  now classifies credentials/reachability via `_transfer_kind`, closing the carried Task 3 finding —
  it is smudge-on, so it is where a 401 surfaces on every switch after the first.
