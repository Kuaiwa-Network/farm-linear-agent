### Task 9: Stop and recovery never orphan a slot

Spec §7: "Stop cancels queued reservations, marks active ones `cancel_requested`, kills the worker, then applies the release rule." The order matters in both directions.

**Why:** `Scheduler.stop` kills the worker before taking its lock, deliberately, so a human pressing Stop is never queued behind an in-flight tick — done-criterion 2 gives it five seconds. A quiescence probe talks to a possibly wedged Editor over MCP and cannot run inside that budget. And in the other direction, an item stopped while in `awaiting_resource` must have its queued reservation cancelled, or the pool will later perform a multi-minute slot switch for a worker that no longer exists.

**Decision this task encodes:** `Scheduler.stop` does three fast things — cancel reservations, kill, cancel the item — and never probes. The probe happens on the pool thread, on the next pool tick, which is what makes `cancel_requested` a state rather than a flag. Every other path that drives an item terminal (`_reap`, `_recover`, a worker's own `finish`) needs no new code at all, because `reservations_to_settle` already selects on the item's state.

**Files:**
- Modify: `agent/scheduler.py` (`stop`)
- Test: `tests/test_scheduler.py`, `tests/test_slots.py`

**Interfaces:**
- Consumes: `Ledger.cancel_reservations` from Task 2.
- Produces: no signature change. `Scheduler.stop(item_id, reason)` gains one call, before the kill.

- [ ] **Step 1: Write the failing tests**

In `tests/test_scheduler.py`:

```python
    def test_stop_cancels_the_reservation_before_it_kills_the_worker(self):
        """Ordering is asserted, not implied: both orders leave the same end state, so the fake launcher
        samples the reservation at the moment stop() reaches it. A wall-clock assertion here would prove
        nothing — FakeLauncher.stop appends to a list and returns, so it is fast whatever the real one does.
        Done-criterion 2's five-second budget is defended by the rule that stop() only touches SQLite and
        signals, which this ordering assertion is the test of."""
        item = self.granted_item(mode="interactive")
        self.scheduler.tick()
        seen = []
        self.launcher.on_stop = lambda i: seen.append(self.ledger.active_reservation(i)["state"])
        self.scheduler.stop(item, "Linear stop")
        self.assertEqual(seen, ["cancel_requested"])
        reservation = self.ledger.active_reservation(item)
        self.assertEqual(reservation["state"], "cancel_requested")
        self.assertEqual(self.ledger.item(item)["state"], "cancelled")
        # Still held: stop() never touches the slot row. granted_item leaves it in the busy state the pool's
        # switch would have written, so this asserts that stop left it alone rather than releasing it — the
        # release is the pool's, on its next tick, after a quiescence probe that does not fit five seconds.
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "interactive_busy")

    def test_stop_on_an_item_that_is_only_waiting_kills_its_queued_request(self):
        item = self.waiting_item(mode="batch")
        self.scheduler.stop(item, "Linear stop")
        self.assertEqual([r["state"] for r in self.ledger.reservations() if r["item_id"] == item], ["cancelled"])
        self.assertEqual(self.ledger.item(item)["state"], "cancelled")

    def test_stop_reaches_the_batch_editor_the_worker_no_longer_owns(self):
        """This task is named 'Stop and recovery never orphan a slot', and the sandbox redesign put the one
        process that can orphan one outside everything Stop used to reach. The Editor is started by the
        launcher on the pool thread, the worker that asked for it has already exited, and `launcher.stop`
        resolves a `spawn` handle that was never written for it. So Stop must kill it explicitly, and it
        must do so BEFORE the worker kill, for the same reason the cancel comes first: the pool thread is
        sitting in `wait()` and the sooner it is released the sooner the slot can settle."""
        item = self.waiting_item(mode="batch")
        self.scheduler.stop(item, "Linear stop")
        self.assertEqual(self.launcher.unsandboxed_stopped, [item])
        self.assertLess(self.launcher.order.index(("unsandboxed", item)),
                        self.launcher.order.index(("worker", item)))
```

`FakeLauncher` gains the mechanism both ordering assertions need: `self.on_stop = None`,
`self.unsandboxed_stopped = []` and `self.order = []` in `__init__`; `self.on_stop and self.on_stop(item_id)`
plus `self.order.append(("worker", item_id))` as the first statements of `stop`; and a
`stop_unsandboxed(self, owner)` that appends to both `unsandboxed_stopped` and `order` and returns `True`.
Without that last method the fake no longer matches the real `Launcher`, and `Scheduler.stop` would raise
`AttributeError` in every existing Stop test rather than in a new one — which is the failure this test is
here to make loud.

In `tests/test_slots.py`, inside `PoolTests`:

```python
    def test_the_pool_settles_a_cancel_requested_reservation_as_cancelled_and_parks(self):
        self.pool().ensure()
        item = self.waiting(ISSUE, self.commit("fix"), "interactive")
        pool = self.pool(mcp=FakeMcp())
        pool.tick()
        self.ledger.cancel_reservations(item, "Linear stop")
        self.ledger.cancel(item, "Linear stop")
        self.assertEqual(pool.tick()["settled"], 1)
        self.assertEqual([r["state"] for r in self.ledger.reservations()], ["cancelled"])
        self.assertEqual(self.ledger.slot("unity_slot:1")["parked_commit"],
                         self.trees.resolve_commit("Farm-Client"))
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k stop -k settles`
Expected: FAIL. Stop leaves the reservation `active`, and the queued request of a waiting item survives.

- [ ] **Step 3: Cancel first, then kill**

In `agent/scheduler.py`, at the top of `stop`:

```python
    def stop(self, item_id, reason):
        # First, so a worker polling its reservation sees cancel_requested and so the pool can no longer hand
        # a slot to an item whose worker is about to be dead. All three steps here are SQLite and signals; the
        # quiescence probe belongs to the pool thread and would not fit the 5-second budget (spec §7, §17).
        try:
            self.ledger.cancel_reservations(item_id, reason)
        except LedgerError:
            pass
        # The batch Editor is not a worker and never went through `spawn`, so `launcher.stop` below cannot
        # see it: its handle lookup and its `descendants` walk both start from a worker pid, and by now that
        # worker has already exited — it asked for the reservation and quit. Killing the group here is what
        # keeps this task's title true. It is one `killpg` plus a bounded wait, well inside the 5-second
        # budget of done-criterion 2, and it is idempotent when no batch run is in flight.
        self.launcher.stop_unsandboxed(item_id)
        killed = self.launcher.stop(item_id)
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k stop -k settles`
Expected: PASS, four new tests plus the existing Stop tests.

- [ ] **Step 5: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 213 tests (+4).

```bash
git add agent/scheduler.py tests/test_scheduler.py tests/test_slots.py
git commit -m "fix(scheduler): Stop cancels reservations before it kills the worker

A stop on a waiting item left its queued request alive, so the pool would have paid
for a slot switch for a worker that no longer existed. An active reservation is now
marked cancel_requested and keeps the slot until the pool's own probe releases or
holds it, which keeps the kill inside its five-second budget.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

