# Task 9 report — Stop and recovery never orphan a slot

Branch `phase1b-tasks-5-11`, commit **a4f0130** (parent 63b4bcb).
`fix(scheduler): Stop cancels reservations and kills the batch Editor first`

Files changed: `agent/scheduler.py` (+21), `tests/test_scheduler.py` (+63), `tests/test_slots.py` (+15). No other file touched.

---

## 1. What I implemented

### `agent/scheduler.py` — `Scheduler.stop`

Two calls added at the very top of `stop`, both before the existing `killed = self.launcher.stop(item_id)`:

1. `self.ledger.cancel_reservations(item_id, reason)`, wrapped in `try/except LedgerError: pass`.
2. `self.launcher.stop_unsandboxed(item_id)`.

Everything below is unchanged: the worker kill, the `with self.lock` block, the retry of
`launcher.stop` when the first kill found no handle, `self.active.pop`, and `ledger.cancel`.
No signature changed; nothing else in the file was touched.

Final order inside `stop`, before the lock is taken:

```
cancel_reservations  ->  stop_unsandboxed  ->  launcher.stop  ->  (lock) ... ledger.cancel
```

### `tests/test_scheduler.py` — `FakeLauncher`

Gained, exactly as the brief specified, the mechanism the two ordering assertions need:
`self.on_stop = None`, `self.unsandboxed_stopped = []` and `self.order = []` in `__init__`;
`self.on_stop and self.on_stop(item_id)` plus `self.order.append(("worker", item_id))` as the first
statements of `stop`; and a new `stop_unsandboxed(self, owner)` that appends to both lists and returns
`True`. `HandleAwareLauncher` inherits all of it and needed no change.

---

## 2. CONFIRMATION: `Scheduler.stop` now reaches the batch Editor, and the ordering is tested

**Reaches it.** `Scheduler.stop` calls `Launcher.stop_unsandboxed(item_id)`
(`agent/launcher.py:240`), which looks the item up in the launcher's `_unsandboxed` registry — the
registry `run_unsandboxed` writes under `owner` at `agent/launcher.py:178`, which is the one place the
batch Editor's `Popen` is recorded — and calls `kill_group(process.pid)` on it: `killpg(SIGTERM)`,
bounded wait, then `killpg(SIGKILL)`. This is the only route to that process. `Launcher.stop` cannot
take it: `stop` resolves `self._handles`, which only `spawn` populates, and the batch Editor never went
through `spawn`; its `_kill` then walks `descendants` from a worker pid that, by the time the Editor is
running, belongs to a worker that has already exited. Task 7 left this wiring undone and the brief
scoped it here; it is now done. `tests/test_scheduler.py::test_stop_reaches_the_batch_editor_the_worker_no_longer_owns`
asserts `self.launcher.unsandboxed_stopped == [item]`, and it failed before the change with `[] != [...]`
(output in §4).

**Ordering is tested, and the tests really are order-sensitive.** I verified this by mutation rather
than by reading, because "this test asserts an order" is exactly the claim that has been hollow in
earlier tasks of this plan. Three mutations, each run with `python3 -B -W error`, each restored by
copying a pristine copy back (never `git checkout`):

| Mutation to `Scheduler.stop` | Result |
|---|---|
| A. `cancel_reservations` moved to *after* `launcher.stop` | **FAILED (failures=2)** — `test_stop_cancels_the_reservation_before_it_kills_the_worker` and `test_stop_on_an_item_that_is_only_waiting_kills_its_queued_request` |
| B. `stop_unsandboxed` moved to *after* `launcher.stop` | **FAILED (failures=1)** — `test_stop_reaches_the_batch_editor_the_worker_no_longer_owns` (the `assertLess` on `order` indices) |
| C. `stop_unsandboxed` call deleted entirely | **FAILED (failures=1)** — same test, on `unsandboxed_stopped == []` |

Mutation B is the important one: it changes *only* the order, leaves the identical end state, and the
test still fails. That is the property the brief's warning was about.

I also ran the mutation the brief predicted on the double itself — deleting `FakeLauncher.stop_unsandboxed`
— and confirmed the failure is loud: `Ran 16 tests ... FAILED (failures=2, errors=5)`, five
`AttributeError`s across the pre-existing Stop tests rather than one quiet skip.

**The budget is not at risk.** Done-criterion 2 gives the worker kill five seconds, and `stop_unsandboxed`
now runs ahead of it with a `kill_group` grace of 5 s + 1 s. Those two cannot contend, because a batch
Editor and a worker for the same item are never alive at the same time: the Editor runs inside
`SlotPool._hand_over`, which calls `run_batch` *before* `ledger.resume` puts the item back in the queue,
and the scheduler only spawns the worker after that resume. In every other case — interactive slots, fix
workers, anything with no batch run in flight — `stop_unsandboxed` returns `False` immediately after one
dict lookup under a lock. The measured fact that `SIGTERM` closes an Editor in about one second means the
batch case is about a second too. I wrote this reasoning into the code comment rather than leaving the
brief's unsupported "well inside the 5-second budget".

---

## 3. Tests added

`tests/test_scheduler.py` (class `SchedulerTests`), placed after `test_stop_kills_and_cancels`:

- `test_stop_cancels_the_reservation_before_it_kills_the_worker`
- `test_stop_on_an_item_that_is_only_waiting_kills_its_queued_request`
- `test_stop_reaches_the_batch_editor_the_worker_no_longer_owns`

`tests/test_slots.py` (class `PoolTests`), placed after
`test_two_requests_serialize_on_the_one_slot_batch_first_then_interactive`:

- `test_the_pool_settles_a_cancel_requested_reservation_as_cancelled_and_parks`

No test starts Unity, touches `/Applications`, reaches the network or opens the real ledger. The slots
test uses the existing `SlotFixture` (real temp git repos, real temp SQLite, `FakeMcp`); the scheduler
tests use the existing in-module doubles. No server and no thread was added, so nothing new to close or
join. `.local/editors/slot-1` was never referenced.

---

## 4. Commands and output

### Baseline before any change

```
$ python3 -B -W error -m unittest discover -s tests
Ran 269 tests in 58.355s

OK
```

### Failing-first (brief Step 2)

```
$ python3 -B -W error -m unittest discover -s tests -v -k stop -k settles
...
FAIL: test_stop_cancels_the_reservation_before_it_kills_the_worker
    self.assertEqual(seen, ["cancel_requested"])
AssertionError: Lists differ: ['active'] != ['cancel_requested']

FAIL: test_stop_on_an_item_that_is_only_waiting_kills_its_queued_request
    self.assertEqual(seen, [["cancelled"]])
AssertionError: Lists differ: [['queued']] != [['cancelled']]

FAIL: test_stop_reaches_the_batch_editor_the_worker_no_longer_owns
    self.assertEqual(self.launcher.unsandboxed_stopped, [item])
AssertionError: Lists differ: [] != ['f15935a8-4732-4d25-8455-5191227a472e']

Ran 17 tests in 3.250s

FAILED (failures=3)
```

Each failure is for the right reason: the reservation was still `active` / still `queued` at the moment
of the kill, and nothing had reached the batch Editor.

### Selection after the change (brief Step 4)

```
$ python3 -B -W error -m unittest discover -s tests -v -k stop -k settles
Ran 17 tests in 3.750s

OK
```

### Whole suite (brief Step 5)

```
$ python3 -B -W error -m unittest discover -s tests
Ran 273 tests in 66.893s

OK
```

**269 -> 273, +4, warning-free.** The brief predicted "213 tests (+4)"; the +4 is right, the absolute
number was stale, as in every previous task.

---

## 5. Brief defects found, and how I resolved them

**D1 — the brief's second test was not coverage. It passed before the change.**
The brief's `test_stop_on_an_item_that_is_only_waiting_kills_its_queued_request` asserts only the end
state: the reservation is `cancelled` and the item is `cancelled`. But `Ledger.cancel` already runs the
identical `UPDATE ... CASE WHEN state='queued' THEN 'cancelled' ELSE 'cancel_requested' END`
(`agent/ledger.py:955`, landed in 99c94e5, Task 2), and `Scheduler.stop` has always called
`ledger.cancel`. So both of the brief's assertions were green at 63b4bcb, and the test would have gone
into the suite as decoration. This is the exact shape the task instructions warned about.

The brief's own *rationale* is nonetheless sound, but it is about *timing*, not end state: `stop`
defers `ledger.cancel` until it owns the scheduler lock, which an in-flight tick can hold for as long
as a launch takes, and during that window the pool is free to `acquire` the queued request and start a
multi-minute slot switch for a worker that is already dead. I kept the brief's two assertions and added
the one that actually tests that: the same `on_stop` sampling hook, asserting the queued request is
already `cancelled` at the instant of the kill. With that, the test fails before the change
(`[['queued']] != [['cancelled']]`) and is caught by mutation A. I recorded the reason in its docstring
so a later reader does not delete the sampling as redundant.

**D2 — the brief's commit message describes a bug that did not exist.**
"A stop on a waiting item left its queued request alive, so the pool would have paid for a slot switch
for a worker that no longer existed." Untrue as written, for the same reason as D1: the request died,
just later, under the lock. I rewrote the commit message to say what is actually true — the queued
request died only once Stop owned the lock, and the window is the defect — and gave the batch Editor
the lead paragraph it deserves, since that is the orphan this task's title is about.

**D3 — the brief's `tests/test_slots.py` test is characterisation, not failing-first.**
`test_the_pool_settles_a_cancel_requested_reservation_as_cancelled_and_parks` passed at 63b4bcb, before
any production change. That is correct and expected — `Ledger.reservations_to_settle` already selects
`cancel_requested` (Task 2) and `Ledger.release` already resolves it to `cancelled` (`agent/ledger.py:823`),
which is precisely the brief's own point that "every other path needs no new code at all". But it means
brief Step 2's "Expected: FAIL" covers only the three scheduler tests. I kept the test — it pins the
contract between the two halves of Stop, which now live in different files and on different threads —
and said so in its docstring instead of letting it look like it proved something new.

**D4 — the brief's comment claims `stop_unsandboxed` is "well inside the 5-second budget" without a reason.**
A `kill_group` at the default grace is up to 5 s of `SIGTERM` wait plus 1 s of `SIGKILL` wait, which on
its face is the whole budget and then some, spent *before* the worker kill. The claim is true, but for a
reason the brief did not give: a batch Editor and a worker for the same item cannot be alive at once
(§2 above). I put that reason in the comment. I did **not** lower the grace — a shorter one would
`SIGKILL` an Editor mid-write to the slot folder, which is the corruption slots exist to prevent.

---

## 6. Self-review findings

1. **Is the `try/except LedgerError` around `cancel_reservations` dead code?** Nearly.
   `cancel_reservations` has no existence check and raises only from `_text(reason, ...)` on a bad
   reason — in which case `ledger.cancel` below would raise identically and is already guarded. I kept
   it: the two guards are then symmetric, and an unguarded first statement would make `stop` able to
   fail *before* the kill, which is the one thing this method must never do.

2. **Should `stop_unsandboxed` be guarded too?** No. It is a dict lookup under a lock plus `kill_group`,
   which swallows `ProcessLookupError` and `PermissionError` internally and cannot raise for a missing
   or dead process. Wrapping it in a bare `except` would hide a genuine launcher bug behind a silent
   Stop that does not stop anything.

3. **The `killed is False` retry does not re-run `stop_unsandboxed`, and should not.** That retry exists
   for the in-flight-launch race: a worker registered by `spawn` after the first kill, under the lock
   (`test_stop_during_an_in_flight_launch_still_kills_the_worker`). The batch Editor is registered by the
   *pool* thread, not by `spawn`, so that particular race does not apply to it.

4. **Residual race, out of scope, reported not fixed.** A Stop landing in the narrow window between
   `SlotPool.grant`'s `acquire` and `run_unsandboxed`'s registration of the Editor will miss it:
   `stop_unsandboxed` finds nothing, and the batch run then continues for up to `batch_timeout` on an
   item that is already cancelled. The **slot is not orphaned** — `_hand_over`'s `resume` raises
   `LedgerError`, the existing "item cancelled mid-switch" arm calls `_give_the_slot_back`, and
   `park_idle` returns the slot on the same tick, which is what
   `test_a_stop_between_the_grant_and_the_switch_does_not_kill_the_pool_thread` already proves. What is
   wasted is up to 30 minutes of Editor time. Closing it means `run_batch` re-checking the reservation
   state, which is a change to `agent/slots.py` that this brief does not scope.

5. **`recover-slot` cannot reach the batch Editor, by construction.** `agent/__main__.py:201` runs
   `ledger.recover_slot` in the operator's own process; the `_unsandboxed` registry lives in the `serve`
   process's `Launcher` instance. Task 7's `stop_unsandboxed` docstring lists `recover-slot` among its
   callers, which is aspirational — its two real callers are `Scheduler.stop` (this task) and
   `Components.shutdown` via `stop_all_unsandboxed` (`agent/service.py:175`, Task 7). This is not a gap
   in practice: by the time an operator runs `recover-slot`, the Editor has been killed by Stop, by the
   batch timeout, or by service shutdown. Noted so the docstring is not read as a promise.

6. **`self.on_stop and self.on_stop(item_id)`** is an expression statement, which a linter would flag.
   The brief specified that exact line and the repository has no linter configured; I left it.

7. **Every collaborator is still injected, and the doubles still match the real objects.** `FakeLauncher`
   now carries `stop_unsandboxed` with the real `Launcher`'s signature (`owner`, returns bool). I
   checked for other launcher doubles that `Scheduler.stop` could reach: there are none —
   `grep -rn "FakeLauncher\|class .*Launcher" tests/` outside `test_scheduler.py` finds only
   `LauncherTests`, which exercises the real class.

8. **No new file, no new dependency.** `agent/` remains standard-library only.

---

# Fix round 1 — appended after review

Commit **d0eeb37**.
Files: `agent/slots.py` (+17), `agent/scheduler.py` (comment only, +9/-6), `tests/test_slots.py` (+62/-3).

## F1 (Important) — `run_batch` now refuses to start an Editor for a reservation that is no longer active

I accept the ruling and the correction to my analysis. I had filed this beside Task 7's
`Popen` → `_unsandboxed[owner] = process` race, which is microseconds. It is not that race. The window is
`SlotPool.grant`'s `acquire` → that same registration, and it **contains the whole of `switch()`**: a
detached checkout of a 3.7 GB repository, `git lfs checkout`, `pointers_remain`, and on an open slot a
graceful `close_editor`. Minutes, on the normal path of every batch grant. My report called it narrow and
that was wrong.

**The change**, in `agent/slots.py::run_batch`, immediately before the `self.run_unsandboxed(...)` call —
the last moment at which not starting is free:

```python
current = self.ledger.reservation(reservation["reservation_id"])
if current is None or current["state"] != "active":
    return None
```

`!= "active"` rather than a list of bad states, so both `cancel_requested` (what `Scheduler.stop` leaves)
and `cancelled` (what the pool's own give-back leaves) are caught, and so does any state added later.

**Why it returns instead of raising**, which is the one design decision here: a `SlotError` would route
through `_switch_failed`, and every arm of it is wrong for a Stop. `stage="probe"` would **hold** the
slot until an operator ran `recover-slot` — the exact orphan this task is named after. `stage="compile"`
and the `attempts >= 1` arm call `fail_queued` on an item that is already terminal. The remaining arm
calls `requeue_reservation`, which would put a *new* queued reservation on the board for a dead item and
buy the pool a second multi-minute switch. Returning instead lets `_hand_over` fall through to
`ledger.resume`, which raises `LedgerError`, which is caught by the pre-existing "item cancelled
mid-switch" arm: `_give_the_slot_back(..., fail_item=False)` releases the reservation, fails nothing, and
`park_idle` returns the slot to main on the same tick. No restructuring; the pool is untouched apart from
those three lines.

**Covering test** — `tests/test_slots.py::PoolTests::test_a_stop_during_the_switch_means_the_batch_editor_is_never_started`,
plus the new double `CancellingCheckout`.

`CancellingMcp` could not be reused: the batch branch of `switch()` returns at `set_slot_state` before it
ever touches the MCP client, so that double never fires on a batch grant. `CancellingCheckout` wraps the
real `Worktrees` and cancels from inside `checkout_commit` — the minutes-long git stage, which is the
honest place for a Stop to land — doing exactly what `Scheduler.stop` does, in its order
(`cancel_reservations` then `cancel`). It fires once, because `park_idle` checks the slot back out to
main through the same object and a second cancel would raise `LedgerError` on an already-terminal item.

The test asserts `unity.argv == []` and `unity.owners == []` — no Editor started, and therefore nothing
`stop_unsandboxed` could have been asked to find — and then that the slot still comes back by itself:
`(granted, parked) == (0, 1)` on the one tick, item `cancelled`, reservation `cancelled`, slot
`idle_closed`, token file gone, and a second tick that is a no-op.

**Failing-first, by removing the three lines from `agent/slots.py` (copied aside and copied back — no
`git checkout`):**

```
$ python3 -B -W error -m unittest discover -s tests -v -k a_stop_during_the_switch
AssertionError: Lists differ: [] != [['.../unity-binary', '-batchmode', '-silent-crashes',
  '-projectPath', '.../editors/slot-1', '-runTests', '-testPlatform', 'EditMode',
  '-testResults', '.../unity-tests.xml', '-logFile', '.../unity-editor.log',
  '-assemblyNames', 'HotUpdate.Tests']]

Ran 1 test in 0.788s

FAILED (failures=1)
```

That is the bug, printed: a full `Unity -batchmode -runTests` argv handed to the launcher for an item
that was cancelled during the switch.

**Mutation check that the re-check is load-bearing, not decorative.** Deleting it fails the test (above).
Weakening only the *predicate* — `current["state"] == "cancelled"`, which still returns early but misses
the `cancel_requested` that `Scheduler.stop` actually leaves — also fails it:

```
$ python3 -B -W error -m unittest discover -s tests -k a_stop_during_the_switch
Ran 1 test in 0.967s

FAILED (failures=1)
```

So the test is sensitive to the predicate and not merely to the presence of an early return.

## F2 (Minor, promoted) — the budget comment no longer overstates

`agent/scheduler.py`'s comment said `stop_unsandboxed` "cannot eat the kill's 5-second budget". The
non-contention argument behind it is sound, but the sentence was wrong about the cost: `kill_group` polls
for up to 5 s after `SIGTERM` and 1 s more after `SIGKILL`, so **Stop itself can take about six seconds on
the batch path**, and a wedged Editor is precisely Task 0's measured 25-minutes-at-0.0%-CPU case. The
comment now says that plainly, then says what is actually protected: done-criterion 2's budget is five
seconds to kill the *worker*, and the Editor and a worker for the same item are never alive at once
because `run_batch` precedes `resume`. It also notes that in every non-batch case the call is one dict
lookup returning `False`, and points at `run_batch` as the other half of the fix.

## F3 (deferred item, taken because it cost nothing) — docstring of the characterisation test

`test_the_pool_settles_a_cancel_requested_reservation_as_cancelled_and_parks` claimed to reproduce "the
state `Scheduler.stop` hands over" and only half did. Its docstring now says which half — a Stop landing
*after* the hand-over — states outright that it passed before Task 9's change and why, and records that
the `cancel_reservations` setup line is inert because `Ledger.cancel` on the next line marks the
reservation `cancel_requested` on its own. No assertion changed.

## Whole suite

```
$ python3 -B -W error -m unittest discover -s tests
Ran 274 tests in 65.170s

OK
```

**273 -> 274, +1, warning-free.** Nothing started Unity, touched `/Applications`, reached the network or
opened the real ledger; `.local/editors/slot-1` was never referenced. No server or thread was added.
