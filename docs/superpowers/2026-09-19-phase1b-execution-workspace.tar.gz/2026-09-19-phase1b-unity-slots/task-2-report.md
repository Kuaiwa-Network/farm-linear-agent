# Task 2 report: the ledger holds slots and reservations

Branch `phase1b-unity-slots`, on top of b9fb2b1.

## What I implemented

`agent/ledger.py`

- **Schema**, inside the existing `executescript`, after `inbox` and before `audit`, exactly as the brief
  specifies: `slots`, `reservations`, `identity_observations`, the two partial unique indexes
  (`one_active_owner_per_resource`, `one_open_reservation_per_item`), `reservations_queue` and
  `identity_by_item`. `CREATE TABLE IF NOT EXISTS` means an existing ledger file gains the tables on the
  next open; `SchemaTests` already covers the reopen path.
- **Slot methods**, after `set_worker`: `SLOT_STATES`, `FREE_SLOT_STATES`, `_slot_row`, `_slot_view`,
  `ensure_slot`, `slot`, `slots`, `_UNSET`, `set_slot_state`.
- **Reservation lifecycle**, replacing `await_resource` and added after it: `RESERVATION_OPEN`,
  `_reservation_view`, `await_resource`, `acquire`, `reservation`, `reservations`, `active_reservation`,
  `reservations_to_settle`, `_reservation_owned`, `release`, `hold`, `recover_slot`,
  `cancel_reservations`, `record_identity`, `identity_observations`.
- **`cancel`**: the reservation sweep added inside the existing transaction, immediately before
  `_set_state`, so the operator CLI path cannot orphan a slot.

`tests/test_ledger.py`

- `import sqlite3`, `import threading` added; `Path` and `Ledger`/`LedgerError` were already imported.
- New module constant `PIN` (the pinned target every fixture item now carries).
- `LedgerBase.new_item` gained `target=PIN` — see "the ruling" below.
- New `ReservationTests` class at the end of the file.

`tests/test_scheduler.py`

- `SchedulerTests.item` now creates its item with `target=PIN`, imported from `test_ledger`.

## Test names

`tests/test_ledger.py`, class `ReservationTests` (14):

1. `test_two_requests_are_granted_in_arrival_order_not_priority_order`
2. `test_the_unique_index_refuses_a_second_active_owner_of_one_slot`
3. `test_a_worker_may_not_stack_a_second_request_while_it_holds_one`
4. `test_an_item_without_a_pinned_commit_cannot_request_a_slot`
5. `test_a_wrong_token_can_neither_read_nor_release_a_reservation`
6. `test_stop_cancels_a_queued_reservation_and_only_marks_an_active_one`
7. `test_cancelling_a_work_item_cancels_its_reservations_in_the_same_transaction`
8. `test_a_failing_probe_holds_the_slot_until_the_operator_recovers_it`
9. `test_a_reservation_is_listed_for_settlement_once_its_item_is_no_longer_running`
10. `test_a_held_slot_is_not_offered_for_settlement_on_every_tick` *(added, see below)*
11. `test_an_identity_observation_is_appended_per_item`
12. `test_one_hosts_active_reservation_does_not_starve_another_host`
13. `test_ensure_slot_never_clears_a_discovered_instance` *(added, see below)*
14. `test_two_connections_acquiring_at_once_produce_exactly_one_grant`

No test names were changed in any other file.

## Commands and output

Baseline, before any change:

```
$ python3 -W error -m unittest discover -s tests
Ran 150 tests in 11.028s
OK
```

Step 2 — the failing-first run, after writing the tests and before touching `agent/ledger.py`:

```
$ python3 -W error -m unittest discover -s tests -v -k Reservation
...
Traceback (most recent call last):
  File ".../tests/test_ledger.py", line 435, in setUp
    self.ledger.ensure_slot("unity_slot:1", kind="unity_slot", host="mac", folder="/e/slot-1")
    ^^^^^^^^^^^^^^^^^^^^^^^
AttributeError: 'Ledger' object has no attribute 'ensure_slot'

Ran 14 tests in 0.022s
FAILED (errors=14)
```

All 14 failed on the missing attribute, not on an import error, and `-k Reservation` really matched 14
(the class name is the only `Reservation` substring in the suite).

Step 6 — the same selection after implementing:

```
$ python3 -W error -m unittest discover -s tests -v -k Reservation
... 14 x ok
Ran 14 tests in 0.045s
OK
```

Step 7 — the whole suite. The first run caught exactly the one predicted caller breakage:

```
$ python3 -W error -m unittest discover -s tests
ERROR: test_awaiting_resource_stays_parked_in_phase_1a (test_scheduler.SchedulerTests....)
  File ".../agent/ledger.py", line 683, in await_resource
    raise LedgerError("a resource request needs a pinned commit; this item has none")
Ran 164 tests in 11.135s
FAILED (errors=1)
```

After giving `SchedulerTests.item` a pin:

```
$ python3 -W error -m unittest discover -s tests
Ran 164 tests in 11.087s
OK
```

**Real final count: 164 tests, green and warning-free.** The brief predicted 159; it was written against a
147-test baseline, and the baseline is 150 after Task 1. 150 + 14 = 164.

The threaded test was run eight times on its own to check for flakiness; `OK` every time.

## The ruling on the three existing `await_resource` callers

- `tests/test_ledger.py:241 test_await_resource_records_the_request` — **fixed via the shared fixture**, as
  preferred. `LedgerBase.new_item` now passes `target=PIN`. The fixture shape allowed it: no existing
  assertion depends on an item's target being `None`, and `status()`'s compact view does not carry the
  target at all. The test itself is unchanged.
- `tests/test_scheduler.py:225` — **fixed via the shared fixture**. `SchedulerTests.item` now passes
  `target=PIN`. Nothing there asserts on the whole dispatch payload, only on individual keys, so the extra
  `target` key in the payload changes nothing.
- `tests/test_cli.py:191 test_await_resource_is_refused_without_slots_and_errors_are_clean` — **no change
  needed, and I confirmed why before touching anything.** `agent/__main__.py:176-183` refuses with "no unity
  slots configured on this host" *before* calling `ledger.await_resource`, and that test configures no slots.
  It never reaches the ledger, so the new refusal cannot break it. This matches the brief's expectation that
  Task 8 replaces that test later.

## Where the brief was wrong, and how I resolved it

**1. `test_two_requests_are_granted_in_arrival_order_not_priority_order` could not pass as written.**
`release` sets the slot to `'switching'`, not to a free state — deliberately, and the brief says so twice
(`recover_slot`'s docstring explains that `park_idle` corrects a `'switching'` slot). So after the release,
the slot is not in `FREE_SLOT_STATES`, the next `acquire` returns `None`, and the brief's
`...acquire(...)["item_id"]` would raise `TypeError: 'NoneType' object is not subscriptable`.
Resolution: I kept `release`'s behaviour (it is the design) and added a two-line `park()` helper to the test
class that calls `set_slot_state(slot_id, "idle_closed")`, standing in for Task 3's `park_idle`. The
FIFO-not-priority assertion the test exists for is untouched, and the intermediate
`assertIsNone(acquire(...))` still proves a busy slot is not free.

**2. `test_the_unique_index_refuses_a_second_active_owner_of_one_slot` did not test the index it is named
after.** The brief's INSERT reuses `granted["item_id"]`, so the row violates `one_open_reservation_per_item`
*as well as* `one_active_owner_per_resource`. Either index raises `sqlite3.IntegrityError`, so the assertion
could not tell which fence fired — the test would still pass with the resource index deleted.
Resolution: the rival row now belongs to a second item that has no reservation of its own, so only
`one_active_owner_per_resource` can fire, and the test asserts the message names `reservations.resource`.
(SQLite reports the column, not the index name — verified.)

**3. `test_two_connections_acquiring_at_once_produce_exactly_one_grant` had two defects.**
(a) It built both `Ledger` objects in the main thread and used them in worker threads. `Ledger.__init__`
defaults to `check_same_thread=True`, so both threads would have died with
`sqlite3.ProgrammingError`. Resolution: each thread now opens its own `Ledger(..., check_same_thread=False)`
inside `run()` and closes it there — one connection per thread, which is also how
`tests/test_scheduler.py:269,293` already does it.
(b) It queued only **one** request, so the loser returned `None` at the `row is None` branch and never
reached the slot check the test's own docstring claims to exercise. Resolution: two queued requests, so the
loser really does read a slot already moved to `'switching'`.

**4. The predicted test count (159) is wrong** — it assumed a 147-test baseline. Reported honestly above; I
did not bend anything to reach it.

## Two tests added beyond the brief's twelve

Both cover behaviour the brief itself specifies at length but leaves with zero coverage, so I judged them
inside the task rather than new scope. Flagging them explicitly for review:

- `test_a_held_slot_is_not_offered_for_settlement_on_every_tick`. The brief devotes a five-line docstring to
  why `reservations_to_settle` must exclude a `held` slot, but no brief test calls
  `reservations_to_settle()` while a slot is held — the `COALESCE(s.state,'') <> 'held'` clause could be
  deleted and the suite would stay green.
- `test_ensure_slot_never_clears_a_discovered_instance`. `ensure_slot`'s stated contract ("discovered values
  are never cleared by a later `None`") is the whole reason for the three `COALESCE`s in its upsert, and
  nothing else exercised it, `slots(kind=, host=)`'s filters, `slot()` returning `None`, or
  `set_slot_state`'s state validation.

## Self-review findings

Things I found reviewing my own diff, and what I did:

1. **I had added `attempts=attempts+1` to `acquire`'s UPDATE. Removed.** The brief's `acquire` does not
   increment it, and `FarmTestAgent/tools/farmqa_controller.py` has no `attempts` column at all, so its
   semantics are undefined here. Guessing now (grant attempts? switch attempts?) risked locking in the wrong
   meaning for Task 3. The column stays at its `DEFAULT 0` as the brief's schema specifies. **Open
   observation for the reviewer: as landed, nothing ever writes `attempts`.**
2. **I had added an `isinstance(result, dict)` guard to `record_identity`. Removed** for fidelity to the
   brief. A non-dict now raises `AttributeError` from `result.get`, not `LedgerError`. The method is not
   CLI-exposed in this task, so no "errors are clean" constraint applies to it yet.
3. **Verified the two SQL fences fire independently of the Python pre-checks**, by INSERTing directly on the
   connection in a scratch script:
   - `one_open_reservation_per_item` → `UNIQUE constraint failed: reservations.item_id`
   - the CHECK that makes the resource index binding → `CHECK constraint failed: state NOT IN
     ('active','cancel_requested') OR (token_hash IS NOT NULL AND resource IS NOT NULL)`, i.e. a `queued`
     row genuinely cannot reach `active` with a NULL `resource` and slip past the partial index.
4. **`ensure_slot`'s `str(folder)` is dead code.** `_text(folder, "folder")` runs first and rejects anything
   that is not already a `str`, so a caller holding a `pathlib.Path` — which Task 3 reading host config
   plausibly will — gets `LedgerError`, not a coerced string. I left the brief's signature and validation
   alone rather than widening it unasked. Flagging it for Task 3.
5. `LedgerBase.new_item(target=PIN)` uses a shared dict as a default argument. It is never mutated
   (`create_work_item` only `json.dumps`es it), so this is safe as written.
6. `cancel_reservations` writes an audit row even when its UPDATE matched nothing. Brief's behaviour; left
   as is.
7. Checked that the raw reservation token exists exactly once, at `acquire`, is never returned by
   `reservation()`/`reservations()` (the view omits `token_hash` and `owner`), is stored only as a SHA-256
   digest, and never travels as a command-line argument — no CLI surface was added in this task.

---

# Fix round 1

One finding, accepted in full and fixed.

## FINDING 1 (Important) — the mode-preference sort in `acquire` was untested

Agreed, and the reviewer is right that I applied my own "deletable with the suite green" criterion
inconsistently. `test_one_hosts_active_reservation_does_not_starve_another_host` puts its two slots on
*different* hosts, so `acquire`'s `free` list never held more than one element and
`free.sort(key=lambda s: (order.index(s["state"]), s["slot_id"]))` was a no-op in every one of the 14 tests.

**Changed:** `tests/test_ledger.py` only. No production code was touched — the diff for this round is
`tests/test_ledger.py | 18 ++++++`.

**Covering test:** `ReservationTests.test_interactive_prefers_an_open_editor_and_batch_prefers_a_closed_one`.
It puts two free slots on **one** host and runs both halves of spec §7:

- interactive, with `unity_slot:1` `idle_closed` and `unity_slot:2` `idle_open` → expects `unity_slot:2`;
- batch, with the states swapped → expects `unity_slot:2`.

Both halves expect `unity_slot:2`, the alphabetically **later** slot id. That is deliberate: the secondary
sort key is `s["slot_id"]`, so if the state preference were ignored or reversed the tiebreak would hand back
`unity_slot:1`, and neither half can pass by accident.

## Commands and output

```
$ python3 -W error -m unittest discover -s tests -k prefers_an_open_editor
Ran 1 test in 0.005s
OK
```

Mutation check — `order` reversed in `agent/ledger.py` (interactive and batch preferences swapped):

```
$ python3 -W error -m unittest discover -s tests -k prefers_an_open_editor
Ran 1 test in 0.004s
FAILED (failures=1)
AssertionError: 'unity_slot:1' != 'unity_slot:2'

$ python3 -W error -m unittest discover -s tests -k Reservation
Ran 15 tests in 0.045s
FAILED (failures=1)
```

The mutation fails the new test and **only** the new test — 1 failure out of 15 — which independently
confirms the finding that nothing else covered the sort. `agent/ledger.py` was then restored with
`git checkout` and the test passes again.

Whole suite, warning-free:

```
$ python3 -W error -m unittest discover -s tests
Ran 165 tests in 11.122s
OK
```

164 -> 165; `ReservationTests` is now 15 tests.

## One process note worth recording

My first mutation check produced a false result: after `git checkout agent/ledger.py` restored the correct
source, the test still failed. The cause was stale bytecode, not stale source. The mutation swaps two tuples
of identical length, so the mutated and restored files have **the same size**, and the checkout landed in the
same wall-clock second as the mutation write. CPython validates a `.pyc` on (source mtime, source size), so
both matched and the restored run silently executed the mutated bytecode.

I caught it because "identical source, different result" is not a thing, re-ran with `__pycache__` removed,
and got `OK`. Every step of the mutation check above was then redone with the cache cleared between steps.
Flagging it because any future same-size source mutation in this repo can produce the same false pass or
false fail, and a false *pass* would be the dangerous direction.

## Deferred findings — not acted on

Per the coordinator, the four Minor findings are left for the final review: the raw `sqlite3.IntegrityError`
surfacing (Task 3's), the duplicated cancel CASE UPDATE shared by `cancel` and `cancel_reservations`, the
`assertTrue(token)` in `test_a_reservation_is_listed_for_settlement_once_its_item_is_no_longer_running` that
asserts nothing, and `reservations.attempts` being schema-only.
