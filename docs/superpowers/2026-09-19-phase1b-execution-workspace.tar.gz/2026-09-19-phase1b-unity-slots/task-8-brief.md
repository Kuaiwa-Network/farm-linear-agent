### Task 8: The worker asks for a slot, gives it back, and the operator can see the pool

`agent/__main__.py:176-183` currently makes `await-resource` raise `no unity slots configured on this host`, and `skills/fix/SKILL.md` tells the worker that rungs 4 and 5 return an error. This task turns the refusal into a real request, adds the verbs that give a slot back and show its state, and rewrites the two documents in the same commit, as spec §11 requires.

**Why:** without a webhook, the operator's only way to create work is the ledger, and the only way to watch a slot is the CLI. This task is also what makes the live rehearsal in Task 11 runnable at all.

**Decision this task encodes:** two.

First, an interactive worker releases its own slot through `release-resource` after its own quiescence check, and the pool is the backstop rather than the primary path (spec §7). The worker's outcome is data: `--outcome quiescent` asks for a release, `--outcome unclean` asks for a hold, and either way the pool re-checks before acting on a slot the worker may have wedged. `cancel` stays an operator verb and is now safe, because `Ledger.cancel` cancels the item's reservations in the same transaction (Task 2).

Second, **`enqueue` does not manufacture authority and does not pretend to have a Linear session.** Spec §4's rule of authority says write-capable skills start only from delegation, "so every code change traces back to an explicit human act on the issue". Calling `ensure_session(..., delegation=True)` unconditionally would assert delegation that no one performed. So `enqueue` fetches the issue and refuses a write-capable skill unless that issue's `delegate_id` is this app user; the operator's own invocation is the explicit human act and is written to `audit`. And because the synthetic session id names no Linear agent session, every `create_activity` for such an item would fail against the real API: `enqueue` records that on the item, the worker falls back to an issue comment, and the operating contract says an enqueued item posts no session activities. Otherwise §9's reporting surface would be silently dead for exactly the items Task 11 rehearses.

**Files:**
- Modify: `agent/__main__.py` (`parser`, `run`)
- Modify: `agent/service.py` (`enqueue` and `slots` subcommands)
- Modify: `agent/scheduler.py` (a `local-` session id posts an issue comment instead of a session activity)
- Modify: `skills/fix/SKILL.md` (the verification ladder, rungs 4 and 5)
- Modify: `docs/operating-contract.md` (authority table, limits, the resource paragraph)
- Test: `tests/test_cli.py`, `tests/test_service.py`

**Interfaces:**
- Consumes: the ledger methods from Tasks 2 and 6; `resolve_token(args)` in `agent/__main__.py`, which already reads `--token-file`.
- Produces:
  - `await-resource --item --resource --mode {interactive,batch}` now returns the item view with `state` `awaiting_resource`, or fails with the ledger's message when the item has no pin or already holds a slot.
  - `release-resource --item --token-file --outcome {quiescent,unclean}` — records the worker's own verdict and, for `quiescent`, releases; for `unclean`, holds. Returns the reservation view.
  - `reservations`, `slots` — operator readers, token-free.
  - `recover-slot --slot --reason` — operator verb, the only way out of `held`.
  - `python3 -m agent.service enqueue --issue <uuid> --skill fix [--commit <sha>] [--session <id>]` — creates an issue snapshot from a fetched issue, a session and a queued work item with a pinned target, so the whole flow runs with no webhook. Returns the work item id.
  - `python3 -m agent.service slots` — the pool's view: slot states, parked commits, queue depth.

- [ ] **Step 1: Write the failing tests**

In `tests/test_cli.py`, replace `test_await_resource_is_refused_without_slots_and_errors_are_clean` (lines 191-195) with:

```python
    def test_a_worker_requests_a_slot_and_the_request_is_queued(self):
        item = self.seeded_item(target={"repository": "Farm-Client", "requested_ref": "main",
                                        "commit_sha": "a" * 40, "server_environment": "公共测试服",
                                        "selected_at": SELECTED_AT})
        token = self.run_cli("claim", "--item", item, "--worker-id", "w")["token"]
        view = self.run_cli("await-resource", "--item", item, "--token", token,
                            "--resource", "unity_slot", "--mode", "batch")
        self.assertEqual((view["state"], view["needs_resource"]), ("awaiting_resource", "unity_slot:batch"))
        self.assertEqual(self.run_cli("reservations")[0]["mode"], "batch")

    def test_an_unpinned_item_is_told_why_it_cannot_have_a_slot(self):
        item = self.seeded_item()
        token = self.run_cli("claim", "--item", item, "--worker-id", "w")["token"]
        process = self.run_cli("await-resource", "--item", item, "--token", token,
                              "--resource", "unity_slot", "--mode", "batch", success=False)
        self.assertIn("pinned commit", process.stderr)
        self.assertEqual(process.stdout, "")

    def test_a_worker_releases_its_own_slot_and_an_unclean_one_is_held(self):
        item, token_file = self.granted_item(mode="interactive")
        view = self.run_cli("release-resource", "--item", item, "--token-file", str(token_file),
                            "--outcome", "quiescent")
        self.assertEqual(view["state"], "released")
        self.assertEqual(self.run_cli("slots")[0]["state"], "switching")
        # granted_item parks the slot first, because no pool thread runs in this file and Ledger.acquire
        # only grants a slot in FREE_SLOT_STATES — release() left it 'switching'.
        other, other_token = self.granted_item(mode="interactive", issue_id=OTHER)
        self.run_cli("release-resource", "--item", other, "--token-file", str(other_token), "--outcome", "unclean")
        self.assertEqual(self.run_cli("slots")[0]["state"], "held")
        self.run_cli("recover-slot", "--slot", "unity_slot:1", "--reason", "operator closed Unity")
        self.assertEqual(self.run_cli("slots")[0]["state"], "idle_closed")
```

`seeded_item` gains an optional `target=None` and `SELECTED_AT` is imported from `test_ledger`, the same ISO-8601 constant every other fixture in this plan uses. `granted_item(mode=..., issue_id=ISSUE)` is a new helper on `CliTests` that seeds a pinned item, claims it, calls `await-resource`, registers `unity_slot:1` through the ledger, **sets the slot to `idle_closed` if it is not already free**, acquires the reservation, sets the slot to the mode's busy state, and writes the raw token to `<state_dir>/reservation.token` at mode 0600, returning `(item_id, token_path)` — the state the pool leaves behind for a worker. Those two `set_slot_state` calls stand in for the pool: `SlotPool.park_idle` is what returns a `switching` slot to the pool in production and `SlotPool.switch` is what writes the busy state, and no pool thread runs in `tests/test_cli.py`. Without the first, `Ledger.acquire` returns `None` on the second call — `release` left the slot `switching`, which is not in `FREE_SLOT_STATES` — and the `--outcome unclean` assertion is unreachable.

In `tests/test_service.py`:

```python
    def test_enqueue_creates_a_pinned_work_item_without_any_webhook(self):
        item_id = enqueue(self.config, issue_ref=ISSUE, skill="fix", commit="a" * 40)["id"]
        ledger = Ledger(Paths(self.config).ledger)
        self.addCleanup(ledger.close)
        item = ledger.item(item_id)
        self.assertEqual((item["state"], item["skill"]), ("queued", "fix"))
        self.assertEqual(item["target"]["commit_sha"], "a" * 40)

    def test_enqueue_refuses_a_write_capable_skill_on_an_issue_nobody_delegated(self):
        """spec §4: fix, fgui and feature start only from delegation, so that every code change traces back
        to an explicit human act on the issue. enqueue is an operator shortcut past the webhook, not past
        the rule of authority."""
        (self.stub / "issue.json").write_text(json.dumps(issue(labels=["Bug"], delegate_id=None)),
                                              encoding="utf-8")
        with self.assertRaises(RuntimeError) as caught:
            enqueue(self.config, issue_ref=ISSUE, skill="fix", commit="a" * 40)
        self.assertIn("delegate", str(caught.exception).lower())
```

Both run under `FARMBOT_LINEAR_STUB_DIR`, so `fetch_issue` reads the stub's `issue.json` and nothing touches the network. The stub's fixture issue carries `delegate_id=APP`, which is what makes the first test's enqueue legitimate.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k slot -k resource -k enqueue`
Expected: FAIL. `await-resource` raises `no unity slots configured on this host`, and there is no `release-resource`, `slots`, `reservations`, `recover-slot` or `enqueue`.

- [ ] **Step 3: Add the verbs**

In `agent/__main__.py`, inside `parser()`, after the existing `await-resource` block:

```python
    release = cmd("release-resource", "--item", token=True)
    release.add_argument("--outcome", required=True, choices=["quiescent", "unclean"])
    cmd("reservations"); cmd("slots")
    cmd("recover-slot", "--slot", "--reason")
```

and in `run()`, replace the whole `await-resource` branch with:

```python
    if c == "await-resource":
        return ledger.await_resource(args.item, resolve_token(args), args.resource, args.mode)
    if c == "release-resource":
        reservation = ledger.active_reservation(args.item)
        if reservation is None:
            raise LedgerError("this item holds no resource")
        if args.outcome == "unclean":
            # The worker says it left the Editor in a state it could not settle; the slot waits for an operator.
            return ledger.hold(reservation["reservation_id"], "worker reported an unclean release")
        ledger.release(reservation["reservation_id"], resolve_token(args), "worker reported quiescent")
        return ledger.reservation(reservation["reservation_id"])
    if c == "reservations":
        return ledger.reservations()
    if c == "slots":
        return ledger.slots()
    if c == "recover-slot":
        return ledger.recover_slot(args.slot, args.reason)
```

The `load_config()` lookup that produced the old refusal goes away with it, and with it the only place in `agent/__main__.py` that read the host configuration.

- [ ] **Step 4: Add the operator's way in without a webhook**

In `agent/service.py`:

```python
def enqueue(config, *, issue_ref, skill, commit=None, session=None):
    """Create a work item directly, for a host whose webhook cannot be delivered.

    Two honesties. The delegation flag is read from the issue, never asserted: spec §4 says a write-capable
    skill starts only from delegation, and the operator's invocation of this command is recorded in `audit`
    as the human act rather than being disguised as one in Linear. And the session id is synthetic — no
    Linear agent session exists for it — so `activities_supported` is False on it and the worker reports
    through an issue comment instead of calling create_activity once per step and failing every time.
    """
    paths = Paths(config)
    paths.config_dir.mkdir(parents=True, exist_ok=True)
    api = linear_api(config)
    ledger = Ledger(paths.ledger)
    try:
        issue = api.fetch_issue(issue_ref)
        observed = ledger.observe_issue(issue)
        delegated = issue.get("delegate_id") == api.app_user_id
        if skill in WRITE_SKILLS and not delegated:
            raise RuntimeError(f"{skill} is write-capable and this issue is not delegated to FarmBot; "
                               f"delegate it in Linear first (spec §4)")
        session = session or f"local-{observed['id']}"
        ledger.ensure_session(session, observed["id"], delegated)
        trees = Worktrees(paths.repos, paths.worktrees, config.repos)
        target = {"repository": "Farm-Client", "requested_ref": "default",
                  "commit_sha": commit or trees.resolve_commit("Farm-Client"),
                  "server_environment": config.default_server_environment,
                  "selected_at": datetime.now(timezone.utc).isoformat()}
        ledger.set_session_target(session, target)
        item = ledger.create_work_item(issue_id=observed["id"], session_id=session, skill=skill, target=target)
        ledger.note(item["id"], "enqueue", f"operator enqueued {skill} for {observed['identifier']}")
        return item
    finally:
        ledger.close()
```

`WRITE_SKILLS` is the set `agent/receiver.py` already defines; import it rather than writing a second copy. `Ledger.note(item_id, kind, reason)` is a three-line public wrapper around the existing private `_audit`, so an operator action leaves the same trail a webhook would. `agent/scheduler.py:76`'s `create_activity` call gains one guard: a session id that begins `local-` gets `api.create_comment(issue_id, body)` instead, because Linear has no session to attach an activity to.

and extend `main`:

```python
    parser.add_argument("command", choices=["configure", "serve", "status", "seed-clones", "install-launchd",
                                            "enqueue", "slots"])
    parser.add_argument("--issue"); parser.add_argument("--skill", default="fix"); parser.add_argument("--commit")
```

```python
    if args.command == "enqueue":
        config = load_config(args.config)
        print(json.dumps(enqueue(config, issue_ref=args.issue, skill=args.skill, commit=args.commit),
                         ensure_ascii=False, indent=2))
        return 0
    if args.command == "slots":
        config = load_config(args.config)
        ledger = Ledger(Paths(config).ledger)
        try:
            print(json.dumps({"slots": ledger.slots(), "reservations": ledger.reservations(
                ("queued", "active", "cancel_requested"))}, ensure_ascii=False, indent=2))
        finally:
            ledger.close()
        return 0
```

- [ ] **Step 5: Rewrite the skill's verification ladder**

In `skills/fix/SKILL.md`, replace rungs 4 and 5 and the sentence beginning `Until slots exist` with:

```markdown
4. EditMode or PlayMode fixtures need a Unity slot in batch mode. Checkpoint your handoff, then
   `await-resource --resource unity_slot --mode batch` and exit. **You are asking for a run, not for
   permission to perform one.** While you are gone the pool switches the slot to your pinned commit and
   FarmBot runs the Editor itself, outside your sandbox, because Unity cannot run inside it: measured on
   2026-09-19, `Unity -batchmode -runTests` under the worker seatbelt hung for 25 minutes at 0.0% CPU and
   wrote nothing, dying on a denied Mach service lookup that no sandbox setting can grant. **Never start a
   Unity process yourself, in any mode, by any route.** A fresh worker resumes with a `resource` block
   carrying the slot folder, the pinned commit, a results directory and `resource.batch_result` — the
   outcome of the run that already happened: `state`, `exit_code`, `seconds`, `results_file`, `log_file`,
   and `total` / `passed` / `failed` parsed from the XML. **The exit code is advisory only and is actively
   misleading: exit 0 means *nothing ran* and exit 2 means *tests failed***. Your evidence is
   `resource.batch_result.results_file`: read it for the failing tests, and treat `total` greater than zero
   as the precondition for claiming anything at all. `state` says which case you are in — `"ran"` is
   evidence, `"gap"` (missing, unparseable or `total="0"`, usually a wrong `-assemblyNames`) and
   `"timeout"` are **verification gaps**, neither a pass nor a failure, and you report them as gaps.
   **`main` is known-red at 26 failures of 4388**, almost all configuration-table contract tests; they are
   in the spike record by class, they will appear in your run, and they are not caused by your change — say
   so rather than treating them as a regression. If you need another run, `release-resource --outcome
   quiescent` and request a fresh batch reservation: one grant is one run. Otherwise release and move on.
5. Behaviour no test covers needs an interactive slot: `await-resource --resource unity_slot --mode
   interactive`. The fresh worker gets one MCP server named `unity`; call `set_active_instance` with the
   `resource.instance` from your launch message before anything else, because the server is shared per user
   and the selection is per MCP session. **`resource.batch_result` is `null` here and there is no argv and
   no Editor path anywhere in your `resource` block — never start a Unity process of your own.** An Editor
   is already running on that folder, and a second `Unity -batchmode` on a folder a live Editor holds
   corrupts it. To run tests from an interactive slot, use the MCP server's own `run_tests` tool: it is
   asynchronous, returns a `job_id`, is polled with `get_test_job` (which takes a `wait_timeout`, so poll
   with one rather than in a busy loop), and exposes `clear_stuck` for a job a domain reload orphaned. It
   runs inside the Editor that is already open, which is why an interactive slot needs no second process at
   all. Leave the Editor in Edit Mode with nothing compiling, then
   `release-resource --outcome quiescent`; if you cannot, `--outcome unclean`, which holds the slot for an
   operator instead of handing a wedged Editor to the next worker.

You hold at most one slot at a time: release before requesting a different mode. **Never start a Unity
process — not on a slot, not on a task worktree, not in batch mode, not through a script, a build tool or a
helper that would do it for you.** Unity does not work inside your sandbox and FarmBot runs it for you,
outside, before you are started. You never edit the slot folder either, and no slot ever runs a player
build — slots budget an import-only `Library/` and a player build triples it.

If your work item was created by an operator with `enqueue` rather than by a Linear delegation, its session
is local and Linear has no agent session for it: report through an issue comment and do not expect session
activities to appear.
```

- [ ] **Step 6: Rewrite the operating contract**

In `docs/operating-contract.md`: in the authority table, change `fix`'s Resources cell from `Unity slot (not yet available)` to `Unity slot (one, batch or interactive, two-phase)`. In the work-item states paragraph, replace `A waiting item has no process and holds no resource.` with `A waiting item has no process. An item in awaiting_resource holds a queued reservation; only the pool's grant turns it back into queued work.` And replace the first bullet under `## Limits in this phase` with:

```markdown
- One host at a time (the Mac since 2026-09-18; Windows follows in its own plan) and one Unity slot. Two
  items that both need Unity serialize on it in arrival order; a worker holds at most one slot and releases
  it after its own quiescence check. **A worker never starts a Unity process**: the Editor does not work
  inside a worker's sandbox, so FarmBot performs a batch run itself, outside that sandbox, between the
  request and the worker that reads its results — one grant is one run. A failing probe holds the slot
  until an operator runs `recover-slot`. No slot is ever released on a timer. A slot runs Edit Mode and PlayMode fixtures and never
  a player build: the budget is an import-only `Library/`, and a player build adds several GB of `Bee` and
  `BuildCache` to it. The receiver and the tunnel run as launchd agents and restart at login; while the host
  config names no named tunnel, the public hostname changes whenever the tunnel restarts and must be
  re-entered in Linear, and until it is, work is created with `python3 -m agent.service enqueue`. An
  enqueued item has a local session that Linear does not know about, so it reports through issue comments
  and posts no session activities; `enqueue` still refuses a write-capable skill on an issue that was never
  delegated to FarmBot, because the rule of authority is not what the missing webhook excuses.
```

- [ ] **Step 7: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k slot -k resource -k enqueue`
Expected: PASS. The three CLI tests and the two service tests are green, and the `PoolTests` and `SwitchTests` cases still pass. One pre-existing test disappears here: `test_await_resource_is_refused_without_slots_and_errors_are_clean` is replaced, not added to.

- [ ] **Step 8: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 209 tests (+5 new, −1 replaced).

```bash
git add agent/__main__.py agent/service.py agent/scheduler.py skills/fix/SKILL.md \
        docs/operating-contract.md tests/test_cli.py tests/test_service.py
git commit -m "feat(cli): request, release and recover a Unity slot

await-resource stops being a refusal. A worker gives the slot back with
release-resource and its own verdict, an operator reads slots and reservations and
clears a held slot with recover-slot, and enqueue creates a pinned work item on a
host whose webhook cannot be delivered. The skill and the operating contract say so.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

