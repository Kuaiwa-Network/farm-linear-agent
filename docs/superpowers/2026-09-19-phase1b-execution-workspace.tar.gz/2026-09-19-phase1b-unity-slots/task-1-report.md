# Task 1 report: every work item pins a commit

Branch `phase1b-unity-slots`, parent `7c88e0c`. Status: **DONE_WITH_CONCERNS** (implementation matches the
brief; the concerns below are observations, not deviations).

## What I implemented

`sessions.target_json` was read by the receiver and written by nothing, so every dispatch payload shipped
`"target": null`. Now a brand-new session resolves Farm-Client's remote default head to a full 40-hex commit
on the receiver's synchronous acknowledgment path, validates and reprojects it, stores it on the session, and
echoes it in the one activity that event produces. The work item snapshots that target at creation.

- `agent/worktrees.py`
  - `_git` gained a `timeout=600` keyword (the 600 was a literal inside the `subprocess.run` call). No existing
    call site changed.
  - `Worktrees.__init__` gained `self._head_cache = {}`.
  - New class attribute `COMMIT = re.compile(r"^[0-9a-f]{40}$")`, placed after `default_branch` as the brief
    directs.
  - New `resolve_commit(repo, ref=None)` — the pool's slow path: `ensure_clone` + `fetch` +
    `rev-parse --verify --end-of-options <ref>^{commit}`.
  - New `remote_head(repo, timeout=8)` — the receiver's fast path: one `git ls-remote --exit-code -- <url> HEAD`
    against the configured remote URL from `repos_root` as cwd, no clone and no fetch, with a 60-second
    per-repo cache keyed on `time.monotonic()`. Only successes are cached.
  - `import time` added.
- `agent/ledger.py`
  - Module-level `COMMIT_SHA`, `TARGET_KEYS` and `checked_target(raw)` beside the other validators (after
    `_timestamp`, before `_normalize`). It validates then reprojects to exactly the five target keys, so a key
    that arrives in an event cannot ride along into the dispatch payload.
  - `Ledger.set_session_target(session_id, target)` next to `ensure_session`; returns the session view.
- `agent/receiver.py`
  - Module-level `TARGET_REPO = "Farm-Client"` and `PIN_TIMEOUT = 8`; `from datetime import datetime, timezone`.
  - `Receiver.__init__` gained `worktrees=None` and `default_server_environment="公共测试服"`.
  - In `_decide_and_act`, the `ensure_session(...)` call now rebinds `session` from its own return value, and
    the pin block runs immediately after it. The three preceding lines (`def`, the issue fetch, `observe_issue`)
    and the `session = self.ledger.session(...)` / `is_delegation = ...` pair are unchanged.
  - `pin` is appended to the two ACK bodies the `work` and `chat` branches already send. No second `_send`.
- `agent/service.py`
  - `build` passes `worktrees=worktrees, default_server_environment=config.default_server_environment` to the
    `Receiver`. `config.default_server_environment` already existed with the value `"公共测试服"`.

## Tests added

`tests/test_worktrees.py`, in `WorktreeTests`:
- `test_resolve_commit_returns_the_remote_default_head_as_forty_hex`
- `test_resolve_commit_refuses_a_ref_that_does_not_exist`
- `test_remote_head_resolves_without_cloning_or_fetching`

`tests/test_ledger.py`, in `WorkItemTests` (the class that already exercises sessions), plus a module-level
`SELECTED_AT = "2026-09-19T00:00:00+00:00"`:
- `test_a_session_target_is_validated_reprojected_and_snapshotted_onto_the_item`
- `test_a_target_whose_commit_or_timestamp_is_malformed_is_refused`

`tests/test_receiver.py`, in `ReceiverTests`, plus `from types import SimpleNamespace`,
`from agent.worktrees import WorktreeError` and the module-level `_raise` helper:
- `test_a_new_session_pins_the_client_head_and_says_so_in_the_one_acknowledgment`
- `test_a_session_whose_client_head_cannot_be_resolved_still_starts_without_a_pin`
- `test_the_receiver_never_clones_or_fetches_to_resolve_a_pin`

## Commands run and their output

### Baseline, before any change

```
$ python3 -W error -m unittest discover -s tests
Ran 139 tests in 10.730s

OK
```

### Step 2 — the failing-first run (tests written, no implementation)

```
$ python3 -W error -m unittest discover -s tests -v -k target -k resolve_commit -k remote_head \
      -k pins -k without_a_pin -k acknowledgment -k clones
...
AttributeError: 'Worktrees' object has no attribute 'resolve_commit'
AttributeError: 'Worktrees' object has no attribute 'remote_head'
AttributeError: 'Ledger' object has no attribute 'set_session_target'
TypeError: 'NoneType' object is not subscriptable      (receiver: session target still None, twice)
----------------------------------------------------------------------
Ran 11 tests in 0.577s

FAILED (errors=7)
```

Eleven selected, as the brief predicts (eight new plus `test_cli`'s `..._pr_targets_...` from `-k target` and
the two `SeedCloneTests` cases from `-k clones`). Seven of the eight new tests failed for the right reason —
missing attributes and a NULL target, not import errors or typos. The eighth,
`test_a_session_whose_client_head_cannot_be_resolved_still_starts_without_a_pin`, passed vacuously at this
point: with no implementation the target is already `None` and exactly one activity is sent. It is a real test
only after Step 5, where it drives the `except` branch. Worth knowing, because that gate alone cannot catch a
regression in the unpinned path.

### Step 6 — the same selection after implementation

```
$ python3 -W error -m unittest discover -s tests -v -k target -k resolve_commit -k remote_head \
      -k pins -k without_a_pin -k acknowledgment -k clones
test_pr_targets_accept_ssh_remotes_ignore_case_and_refuse_a_config_without_github ... ok
test_a_session_target_is_validated_reprojected_and_snapshotted_onto_the_item ... ok
test_a_target_whose_commit_or_timestamp_is_malformed_is_refused ... ok
test_a_new_session_pins_the_client_head_and_says_so_in_the_one_acknowledgment ... ok
test_a_session_whose_client_head_cannot_be_resolved_still_starts_without_a_pin ... ok
test_the_receiver_never_clones_or_fetches_to_resolve_a_pin ... ok
test_seed_clones_reports_the_checkout_it_seeded_from ... ok
test_seed_clones_reports_what_it_created_and_then_reuses_it ... ok
test_remote_head_resolves_without_cloning_or_fetching ... ok
test_resolve_commit_refuses_a_ref_that_does_not_exist ... ok
test_resolve_commit_returns_the_remote_default_head_as_forty_hex ... ok
----------------------------------------------------------------------
Ran 11 tests in 0.821s

OK
```

### Step 7 — the whole suite

```
$ python3 -W error -m unittest discover -s tests
Ran 147 tests in 11.125s

OK
```

139 + 8 = 147, green and warning-free, exactly the count the brief predicts.

### Extra verification (ad-hoc, not committed)

The suite covers `remote_head` against a real local origin and covers the receiver against a `SimpleNamespace`
double, but nothing asserts that the *real* `Worktrees` reaches the *real* `Receiver` through `service.build`
— `test_service.ServeTests` accepts the webhook without deterministically asserting it was processed. I ran a
throwaway script in the scratchpad that reproduces that fixture and calls `process_one()` directly:

```
(200, 'accepted')
True
session target: {"commit_sha": "5f73633211efdf16e4d70948d70f398985497ac0", "repository": "Farm-Client",
                 "requested_ref": "default", "selected_at": "2026-09-19T22:50:03.632513+00:00",
                 "server_environment": "公共测试服"}
item target:    {"commit_sha": "5f73633211efdf16e4d70948d70f398985497ac0", ...}
origin HEAD:    5f73633211efdf16e4d70948d70f398985497ac0
clone exists:   False
```

The pin equals the real origin HEAD, the item snapshots it, and no bare clone was created on the ack path.

## What in the brief was wrong or ambiguous, and how I resolved it

1. **The receiver test snippets use a fixture that does not exist.** The brief writes
   `self.deliver(self.created_event())`, `self.api.activities` and `self.api.activities[0]["content"]["body"]`.
   `tests/test_receiver.py` has no `deliver` or `created_event`; `ReceiverBase` offers `self.receive()` (which
   already defaults to a `created` event) and `self.activities()`, and `self.api` is a `Mock`, not a fake with
   an `activities` list. `activities()` returns `call.args[1]`, which *is* the content dict, so there is no
   `["content"]` level. I kept the test names, comments and assertions verbatim and rewrote only those three
   harness expressions: `self.receive()`, `len(self.activities())`, `self.activities()[0]["body"]`. The
   assertions are semantically identical.
2. **`created_event` does exist — in `tests/test_service.py`, not `tests/test_receiver.py`.** That is the
   likely source of the mix-up. I did not import it; it builds a `session-serve` event, and these tests assert
   on `session-1`.
3. **The line numbers in the anchor paragraph were right this time.** `_decide_and_act` is at
   `agent/receiver.py:167`, the four-line block was 170–173, and `session = self.ledger.session(...)` is read
   before `ensure_session`. I anchored on the text as instructed.
4. **Interfaces vs. Step 3 disagree on how `remote_head` reads the remote.** The Interfaces bullet says
   `ls-remote`; the prose in the "Decision this task encodes" section says `ls-remote --symref`; the Step 3
   code says `ls-remote --exit-code -- <url> HEAD`. I implemented the Step 3 code. `--symref` would add a
   `ref: refs/heads/main\tHEAD` line before the sha line, which `out.split()[0]` would then read as `ref:` and
   reject — so the code as written is the correct reading and the prose is loose.
5. **The brief's `-k` list is load-bearing and I verified it rather than trusting it.** Both gate runs selected
   exactly 11 tests; I counted the named tests in the `-v` output rather than relying on the exit code, since a
   zero-match run exits 5 and would silently satisfy an "expected: FAIL" gate.

## Self-review findings

- **A pin is stored but never echoed on the `elicit`, `steer`, `resume`, `retry` and "active elsewhere"
  branches.** The pin block runs before `route(...)`, so a brand-new delegated session on an issue with no Bug
  label gets its target written to `sessions.target_json` and receives only an elicitation — no pin sentence.
  Spec §6's "so a human can correct it before work starts" is therefore satisfied for `work` and `chat` but not
  for `elicit`. The brief says explicitly to append `pin` to "the two ACK bodies the `work` and `chat` branches
  already send", so I did exactly that and did not invent scope. Flagging it because the later branches are the
  ones where a human has the most time to correct the pin. If you want it covered, it is a one-line change per
  branch.
- **`except Exception` also swallows `LedgerError`.** If `set_session_target` fails for a reason that is not
  "origin unreachable" — a genuine ledger bug, a schema drift — the session silently continues unpinned and
  the human sees "暂时无法锁定客户端提交". That is the brief's intent (a pin must never stop a session) and it
  is a recorded gap rather than a wrong-commit run, but the message will mislead in that case. Nothing in the
  ledger or the audit table records *why* the pin failed; Task 2's `await_resource` will refuse the item, which
  is the intended backstop.
- **`subprocess.TimeoutExpired` from `remote_head` is not a `WorktreeError`.** `_git` deliberately does not
  catch it. On the receiver path the bare `except Exception` catches it, which is the design. But
  `resolve_commit` has no such guard, so a future pool caller of `resolve_commit` will see a
  `TimeoutExpired`, not a `WorktreeError`. Task 4 should know that.
- **`remote_head` creates `repos_root` as a side effect** even though it never clones — `subprocess.run` needs
  an existing cwd. Harmless (the directory is created on first launch anyway) and the new test asserts that no
  `Farm-Client.git/HEAD` appears.
- **`COMMIT = re.compile(...)` sits between two methods** rather than at the top of the class body. Valid
  Python and exactly where the brief puts it; noting it only because a reviewer may read it as a stray.
- **`target=(session or {}).get("target")` is now redundant.** `session` is rebound from `ensure_session`,
  which never returns `None`, so the `or {}` guard can no longer fire. I left it: it is outside this task's
  diff and harmless.
- **`create_work_item` stores its `target` with `json.dumps`, not through `checked_target`.** So the *item's*
  target is only as validated as its caller. The receiver always passes the session view, which was validated
  on the way in, so today there is no hole. Task 2 may want `create_work_item` to validate too.
- Blank-line spacing before `class LeaseTests` and `class HardeningTests` stayed at two; the new tests are the
  last members of their classes.
- No new third-party imports; `time`, `types.SimpleNamespace` and `datetime.timezone` are all stdlib. No test
  starts Unity, touches `/Applications`, reaches the network or opens the real ledger: `remote_head`'s only
  real-origin exercise is a local path in a temp directory.

## Commit

```
feat(receiver): pin every session to a resolved client commit
```

Files: `agent/worktrees.py`, `agent/ledger.py`, `agent/receiver.py`, `agent/service.py`,
`tests/test_worktrees.py`, `tests/test_ledger.py`, `tests/test_receiver.py`.

---

# Fix report — review round 1 of 5

Four findings, all four fixed. I agree with all four; findings 1 and 2 are my own concerns 3 and 4 confirmed,
and finding 1 is indeed worse than I described. Nothing to adjudicate.

## Finding 1 (Important) — the pin echo was permanently suppressed, not merely delayed

**Agreed, and the controller's ruling over the brief is right.** The pin is resolved before `route(...)` and
the echo was guarded on `target is None`. A session whose first event routed to `elicit`, `steer` or the
"active elsewhere" branch wrote `sessions.target_json` and said nothing; every later event in that session,
including the one that finally created work, saw a non-None target, so `pin` was `""` and the pin was never
announced at all. Spec §6's "so a human can correct it before work starts" was unreachable for those sessions.

**What I changed** (`agent/receiver.py`): rather than one `+ pin` per branch, I gave `_decide_and_act` a local
`acknowledge(kind, body)` that appends `pin` to whatever the single activity for this event turns out to be,
and routed all eight `_send` call sites in the method through it — the two "active elsewhere" early returns
and the `work`, `chat`, `steer`, `resume`, `retry` and `elicit` branches. That makes the invariant structural:
a branch cannot be added that forgets the pin, because there is no longer a `_send` in the method to forget it
with.

I checked that this is safe to do exhaustively. `route()` produces exactly seven kinds, and `stop` is
unreachable from `_decide_and_act` (stop events are diverted in `receive` to `_receive_stop`/`_process_stop`,
and `prepared["action"]` is only `created` or `prompted`). Every reachable kind sends exactly one activity, so
appending to all of them still means one event, one activity — the property `create_activity`'s `activity_id`
identity requires.

The re-pin-on-failure behaviour is unchanged and still correct: when resolution fails the target stays NULL,
so the next event retries and echoes again.

**Covering tests:** `test_a_first_event_that_only_elicits_still_announces_the_pin` (new — a delegated issue
without a Bug label elicits, and the elicitation body must carry the pin), plus the existing
`test_a_new_session_pins_the_client_head_and_says_so_in_the_one_acknowledgment` for the work branch.

## Finding 2 (Important) — `except Exception` swallowed `LedgerError`

**Agreed; this was my own concern 4.** Narrowed to `except (WorktreeError, subprocess.TimeoutExpired,
OSError)` in `agent/receiver.py`, with `import subprocess` and `from .worktrees import WorktreeError` added
(`agent/worktrees.py` imports only stdlib, so there is no import cycle). A `LedgerError` from
`set_session_target` now propagates to `process_one`, which already lists `LedgerError` in its catch tuple,
marks the event `uncertain` and sends an error activity to the session. The comment now says why only the
unreachable-origin case is absorbed.

`subprocess.TimeoutExpired` is listed explicitly because it descends from `SubprocessError`, not `OSError`.

**Covering test:** `test_a_ledger_fault_while_pinning_is_not_disguised_as_an_unreachable_origin` (new — a
`remote_head` double returning `"not-a-commit"` makes `checked_target` raise; the event must end `uncertain`
with error `LedgerError`, the activity must be an `error`, and its body must *not* say 暂时无法锁定).

## Finding 3 (Important) — `remote_head` cached successes only

**Agreed.** `remote_head` now caches failures for the same 60 seconds as successes, so a backlog draining
through the serial `process_one` pays one `ls-remote` rather than one per event.

One judgement call inside the fix: I cache the failure's *message* and raise a fresh `WorktreeError` from the
cache, rather than storing and re-raising the exception object. Re-raising one instance across many calls
accumulates traceback frames on `__traceback__`, and a cached `TimeoutExpired` would keep re-raising a stale
traceback. The cost is that a cached timeout surfaces as `WorktreeError` where the first call raised
`TimeoutExpired`. No caller distinguishes them — both call sites catch both — so I took the cleaner shape.
Flagging it in case Task 4 wants the distinction preserved.

**Covering test:** `test_remote_head_caches_a_failure_so_a_burst_of_events_pays_one_timeout` (new — an
unreachable remote, `remote_head` called three times, all three raise, and `_git` was invoked once).

## Finding 4 (Minor) — the unpinned-path test asserted nothing about what the human is told

**Agreed.** Added the two assertions the review asked for to
`test_a_session_whose_client_head_cannot_be_resolved_still_starts_without_a_pin`: the activity body contains
暂时无法锁定, and `results()[-1]["status"]` is `done`. That test now fails if the failure sentence is dropped
or if the unpinned path stops being a success.

## Commands run and their output

The selection covering the amended code (`-k` repeated, which ORs; I counted the named tests in the `-v`
output rather than trusting the exit code):

```
$ python3 -W error -m unittest discover -s tests -v -k pins -k without_a_pin -k announces_the_pin \
      -k disguised -k caches_a_failure -k remote_head -k resolve_commit -k target -k clones
test_pr_targets_accept_ssh_remotes_ignore_case_and_refuse_a_config_without_github ... ok
test_a_session_target_is_validated_reprojected_and_snapshotted_onto_the_item ... ok
test_a_target_whose_commit_or_timestamp_is_malformed_is_refused ... ok
test_a_first_event_that_only_elicits_still_announces_the_pin ... ok
test_a_ledger_fault_while_pinning_is_not_disguised_as_an_unreachable_origin ... ok
test_a_new_session_pins_the_client_head_and_says_so_in_the_one_acknowledgment ... ok
test_a_session_whose_client_head_cannot_be_resolved_still_starts_without_a_pin ... ok
test_the_receiver_never_clones_or_fetches_to_resolve_a_pin ... ok
test_seed_clones_reports_the_checkout_it_seeded_from ... ok
test_seed_clones_reports_what_it_created_and_then_reuses_it ... ok
test_remote_head_caches_a_failure_so_a_burst_of_events_pays_one_timeout ... ok
test_remote_head_resolves_without_cloning_or_fetching ... ok
test_resolve_commit_refuses_a_ref_that_does_not_exist ... ok
test_resolve_commit_returns_the_remote_default_head_as_forty_hex ... ok
----------------------------------------------------------------------
Ran 14 tests in 0.865s

OK
```

The whole suite:

```
$ python3 -W error -m unittest discover -s tests
Ran 150 tests in 11.142s

OK
```

147 + 3 new = 150, green and warning-free.

### Mutation check — each fix's test must fail without its fix

Because three of the four fixes are "this case is now handled differently" rather than new surface, I reverted
each fix in turn and ran only its covering test:

```
M1 (finding 1) acknowledge drops the pin:            Ran 1 test  FAILED (failures=1)
M2 (finding 2) except widened back to Exception:     Ran 1 test  FAILED (failures=1)
M3 (finding 3) failure no longer cached:             Ran 1 test  FAILED (failures=1)
M4 (finding 4) unpinned path tells the human nothing: Ran 1 test  FAILED (failures=1)
=== restored ===
Ran 150 tests in 11.266s

OK
```

Process note, recorded because it affects how much the first pass of this check was worth: my first attempt
reverted each mutation with `git checkout -- agent/<file>`, which restores from HEAD — and HEAD was the
task-1 commit, *before* this round's fixes. So each revert silently discarded the fix it was meant to restore.
The four FAILED results were still valid evidence (each ran against code lacking that fix), but the tree was
left unfixed. I caught it with `git status`, re-applied all four fixes, and re-ran the mutation check above
using file backups in the scratchpad instead of `git checkout`. The numbers quoted above are from the clean
re-run, against a tree that is green at 150 before and after.

### End-to-end re-probe

I re-ran the scratchpad probe from the first pass (real `Worktrees` through `service.build`, not a double):

```
(200, 'accepted')
True
session target: {"commit_sha": "165fd4b67c1361f9f198a1587bc1c9fd0834a752", "repository": "Farm-Client",
                 "requested_ref": "default", ..., "server_environment": "公共测试服"}
item target:    {"commit_sha": "165fd4b67c1361f9f198a1587bc1c9fd0834a752", ...}
origin HEAD:    165fd4b67c1361f9f198a1587bc1c9fd0834a752
clone exists:   False
```

## Residual notes for the next round

- Of my original self-review list, these remain open and untouched because they are outside this round's four
  findings: `create_work_item` still stores its `target` with `json.dumps` rather than through
  `checked_target`, so an item's target is only as validated as its caller (no hole today — the receiver
  always passes a session view that was validated on the way in); `resolve_commit` still lets
  `subprocess.TimeoutExpired` escape as itself, which Task 4 should expect; and `target=(session or {})
  .get("target")` is still redundant now that `session` is rebound from `ensure_session`.
