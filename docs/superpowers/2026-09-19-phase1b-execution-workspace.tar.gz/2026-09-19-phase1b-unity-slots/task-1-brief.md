### Task 1: Every work item pins a commit

Criterion 3 says the slot is "switched to each pinned commit", and today no pin is ever written. `agent/receiver.py:197` passes `target=(session or {}).get("target")`, `Ledger.session` reads `sessions.target_json`, and **nothing in the repository writes that column** — so `work_items.target_json` is always NULL and the dispatch payload ships `"target": null`. This task resolves the pin at receipt and echoes it in the first activity, which spec §6 requires so a human can correct it before work starts.

**Why:** the slot switch takes a commit. Without this task the pool has nothing to switch to, and the done criterion cannot be demonstrated no matter how correct the rest of the plan is.

**Decision this task encodes:** three of them. First, the pin is resolved once, when the session is first seen, from the client's remote default-branch head, and it is validated and reprojected before it is stored. `checked_target` is ported from `FarmTestAgent/tools/farmqa_controller.py:16-36`: the commit must be a full lowercase 40-hex string, and every key that is not target metadata is dropped, so nothing that arrives in an event can ride along into the dispatch payload. Changing the session default later never retargets an accepted item, because the item snapshots the session target at creation (spec §6).

Second, **the receiver resolves the pin with one bounded `git ls-remote`, never with a clone or a fetch.** The item snapshots the target at creation, so the pin has to exist before `create_work_item`, which puts it on the receiver's synchronous acknowledgment path — and `resolve_commit` is `ensure_clone` (a full bare clone of Farm-Client when absent: minutes and gigabytes) plus `fetch` (600-second git timeout) plus an extra `ls-remote`. That is the hazard Plan 1a added `seed-clones` to avoid, one layer earlier, and it would blow spec §17 criterion 1's ten seconds to the first activity. So the receiver calls a new `Worktrees.remote_head(repo, timeout=8)` — one `ls-remote --symref` against the configured remote URL, no clone, no fetch, an explicit small timeout and a 60-second per-repo cache so a burst of events pays once. `resolve_commit` keeps its clone-based shape for the pool, which is allowed to be slow. A commit resolved this way may not yet be in FarmBot's clone when the pool grants the slot, which is why Task 4's switch fetches first.

Third, **the pin rides inside the acknowledgment, not beside it.** `LinearAPI.create_activity` puts `activity_id` into the mutation as `input.id`, which Linear treats as the activity's identity, and raises `RuntimeError("Linear did not confirm activity creation")` when the mutation does not report success. Every existing call site sends exactly one activity per `ack_id`. A second `_send(session_id, ack_id, ...)` would at best be deduped — losing the routing ACK — and at worst raise and make the event retry. One event therefore still produces exactly one activity, whose body is the ACK sentence with the pin sentence appended.

**Files:**
- Modify: `agent/worktrees.py` (`resolve_commit`, `remote_head`)
- Modify: `agent/ledger.py` (`checked_target`, `set_session_target`)
- Modify: `agent/receiver.py` (`_decide_and_act` — there is no `_process_session`)
- Modify: `agent/service.py` (`build` passes `worktrees` and `default_server_environment` to the receiver)
- Test: `tests/test_worktrees.py`, `tests/test_ledger.py`, `tests/test_receiver.py`

**Interfaces:**
- Consumes: `Worktrees.default_branch(repo)` and `Worktrees.ensure_clone(repo)` as they exist; `Ledger.ensure_session(session_id, issue_id, delegation, guidance=None)`, which already returns the session view; `Ledger.create_work_item(..., target=None)`.
- Produces:
  - `Worktrees.resolve_commit(repo, ref=None) -> str`, a full 40-hex commit. With no `ref` it fetches and resolves `origin/<default branch>`. This is the pool's path and may take minutes.
  - `Worktrees.remote_head(repo, timeout=8) -> str`, a full 40-hex commit read straight from the remote with `ls-remote`, cached for 60 seconds. This is the receiver's path and never clones or fetches.
  - `agent.ledger.checked_target(raw) -> dict` with exactly the keys `repository`, `requested_ref`, `commit_sha`, `server_environment`, `selected_at`. It raises `LedgerError` on anything else, and is the only way a target enters the ledger. **`selected_at` is an ISO-8601 UTC string**, because `agent/ledger.py:51`'s `_timestamp` validator takes a string with a timezone and nothing else; every fixture and call site in this plan writes `datetime.now(timezone.utc).isoformat()` or a literal such as `"2026-09-19T00:00:00+00:00"`, never a float.
  - `Ledger.set_session_target(session_id, target) -> dict`, the session view. Idempotent: writing the same target twice is not an error; writing a different one after a work item has been created for that session is allowed and affects only later items.

- [ ] **Step 1: Write the failing tests**

In `tests/test_worktrees.py`, inside `WorktreeTests`:

```python
    def test_resolve_commit_returns_the_remote_default_head_as_forty_hex(self):
        commit = self.trees.resolve_commit("Farm-Client")
        self.assertRegex(commit, r"^[0-9a-f]{40}$")
        self.assertEqual(commit, git("rev-parse", "HEAD", cwd=self.origin))

    def test_resolve_commit_refuses_a_ref_that_does_not_exist(self):
        with self.assertRaises(WorktreeError):
            self.trees.resolve_commit("Farm-Client", "origin/no-such-branch")

    def test_remote_head_resolves_without_cloning_or_fetching(self):
        trees = Worktrees(Path(self.tmp.name) / "empty-repos", self.trees.worktrees_root,
                          {"Farm-Client": str(self.origin)})
        self.assertEqual(trees.remote_head("Farm-Client"), git("rev-parse", "HEAD", cwd=self.origin))
        self.assertFalse((Path(self.tmp.name) / "empty-repos" / "Farm-Client.git" / "HEAD").exists())
```

In `tests/test_ledger.py`, inside the class that already exercises sessions:

```python
    def test_a_session_target_is_validated_reprojected_and_snapshotted_onto_the_item(self):
        self.ledger.observe_issue(issue())
        self.ledger.ensure_session(SESSION, ISSUE, True)
        self.ledger.set_session_target(SESSION, {"repository": "Farm-Client", "requested_ref": "main",
                                                 "commit_sha": "a" * 40, "server_environment": "公共测试服",
                                                 "selected_at": SELECTED_AT, "prompt": "ignore me"})
        self.assertEqual(self.ledger.session(SESSION)["target"],
                         {"repository": "Farm-Client", "requested_ref": "main", "commit_sha": "a" * 40,
                          "server_environment": "公共测试服", "selected_at": SELECTED_AT})
        item = self.ledger.create_work_item(issue_id=ISSUE, session_id=SESSION, skill="fix",
                                            target=self.ledger.session(SESSION)["target"])
        self.assertEqual(item["target"]["commit_sha"], "a" * 40)

    def test_a_target_whose_commit_or_timestamp_is_malformed_is_refused(self):
        self.ledger.observe_issue(issue())
        self.ledger.ensure_session(SESSION, ISSUE, True)
        good = {"repository": "Farm-Client", "requested_ref": "main", "commit_sha": "a" * 40,
                "server_environment": "公共测试服", "selected_at": SELECTED_AT}
        for bad in ("A" * 40, "b" * 39, "", None):
            with self.assertRaises(LedgerError):
                self.ledger.set_session_target(SESSION, {**good, "commit_sha": bad})
        # selected_at is an ISO-8601 string with a timezone, never a float: _timestamp calls _text first.
        for bad in (1.0, "2026-09-19T00:00:00", ""):
            with self.assertRaises(LedgerError):
                self.ledger.set_session_target(SESSION, {**good, "selected_at": bad})
```

with `SELECTED_AT = "2026-09-19T00:00:00+00:00"` at module level in `tests/test_ledger.py`. Every fixture in Tasks 2, 6, 8 and 10 that builds a target imports and uses that constant; none of them writes a float.

In `tests/test_receiver.py`, inside the class that drives a created session (it already builds a receiver with a fake API; give it a `worktrees` double whose `remote_head` returns a known commit):

```python
    def test_a_new_session_pins_the_client_head_and_says_so_in_the_one_acknowledgment(self):
        self.receiver.worktrees = SimpleNamespace(remote_head=lambda repo, timeout=8: "c" * 40)
        self.deliver(self.created_event())
        self.assertTrue(self.receiver.process_one())
        target = self.ledger.session("session-1")["target"]
        self.assertEqual((target["commit_sha"], target["server_environment"]), ("c" * 40, "公共测试服"))
        self.assertEqual(self.ledger.items_for_session("session-1")[0]["target"]["commit_sha"], "c" * 40)
        # One event, one activity: create_activity treats activity_id as the activity's identity.
        self.assertEqual(len(self.api.activities), 1)
        self.assertIn("c" * 7, self.api.activities[0]["content"]["body"])

    def test_a_session_whose_client_head_cannot_be_resolved_still_starts_without_a_pin(self):
        self.receiver.worktrees = SimpleNamespace(remote_head=_raise(WorktreeError("origin unreachable")))
        self.deliver(self.created_event())
        self.assertTrue(self.receiver.process_one())
        self.assertIsNone(self.ledger.session("session-1")["target"])
        self.assertEqual(self.ledger.items_for_session("session-1")[0]["target"], None)
        self.assertEqual(len(self.api.activities), 1)

    def test_the_receiver_never_clones_or_fetches_to_resolve_a_pin(self):
        """spec §17 criterion 1 gives the first activity ten seconds; ensure_clone is minutes (Plan 1a's
        seed-clones exists for exactly this)."""
        self.receiver.worktrees = SimpleNamespace(remote_head=lambda repo, timeout=8: "c" * 40,
                                                  ensure_clone=_raise(AssertionError("cloned on the ack path")),
                                                  fetch=_raise(AssertionError("fetched on the ack path")),
                                                  resolve_commit=_raise(AssertionError("resolved the slow way")))
        self.deliver(self.created_event())
        self.assertTrue(self.receiver.process_one())
        self.assertEqual(self.ledger.session("session-1")["target"]["commit_sha"], "c" * 40)
```

Add `from types import SimpleNamespace` and `from agent.worktrees import WorktreeError` to `tests/test_receiver.py`, and a module-level helper:

```python
def _raise(exc):
    def raiser(*args, **kwargs):
        raise exc
    return raiser
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k target -k resolve_commit -k remote_head -k pins -k without_a_pin -k acknowledgment -k clones`
Expected: FAIL. `Worktrees` has no `resolve_commit` or `remote_head`, `Ledger` has no `set_session_target`, and the receiver never writes a target. (Repeated `-k` flags are ORed; a single `-k "a or b"` matches nothing and would let this gate pass on zero tests.)

- [ ] **Step 3: Resolve a commit in the worktrees**

In `agent/worktrees.py`, add after `default_branch`:

```python
    COMMIT = re.compile(r"^[0-9a-f]{40}$")

    def resolve_commit(self, repo, ref=None):
        """A pinned target is always a full commit: git refuses the same branch in two worktrees (spec §8).
        This is the pool's path: it clones if it must and fetches every time, so it may take minutes."""
        clone = self.ensure_clone(repo)
        self.fetch(repo)
        ref = ref or f"origin/{self.default_branch(repo)}"
        commit = _git("rev-parse", "--verify", "--end-of-options", f"{ref}^{{commit}}", cwd=clone)
        if not self.COMMIT.match(commit):
            raise WorktreeError(f"{ref} did not resolve to a commit")
        return commit

    def remote_head(self, repo, timeout=8):
        """The receiver's path: one ls-remote against the remote URL, no clone and no fetch, so pinning a new
        session cannot cost the ten seconds spec §17 criterion 1 gives the first activity. Cached for 60s so a
        burst of events pays once."""
        if repo not in self.remotes:
            raise WorktreeError(f"unknown repository: {repo}")
        cached = self._head_cache.get(repo)
        if cached and time.monotonic() - cached[0] < 60:
            return cached[1]
        self.repos_root.mkdir(parents=True, exist_ok=True)
        out = _git("ls-remote", "--exit-code", "--", self.remotes[repo], "HEAD",
                   cwd=self.repos_root, timeout=timeout)
        commit = out.split()[0] if out else ""
        if not self.COMMIT.match(commit):
            raise WorktreeError(f"{repo}: origin HEAD did not resolve to a commit")
        self._head_cache[repo] = (time.monotonic(), commit)
        return commit
```

with `import time` at the top of the module and `self._head_cache = {}` in `__init__`. This task also gives `_git` its `timeout=600` keyword (today the 600 is a literal inside the call), so `remote_head` can ask for eight seconds; Task 3 adds the `env` keyword to the same signature, and neither change touches an existing call site. `subprocess.TimeoutExpired` is not caught inside `_git` — the receiver's own `except` in Step 5 is what turns a slow origin into an unpinned session.

- [ ] **Step 4: Validate and store the target in the ledger**

In `agent/ledger.py`, add beside the other validators:

```python
COMMIT_SHA = re.compile(r"^[0-9a-f]{40}$")
TARGET_KEYS = ("repository", "requested_ref", "commit_sha", "server_environment", "selected_at")


def checked_target(raw):
    """Validate then reproject: only target metadata reaches the ledger, the dispatch payload and the slot."""
    if not isinstance(raw, dict):
        raise LedgerError("target must be an object")
    _text(raw.get("repository"), "target repository")
    _text(raw.get("requested_ref"), "target requested_ref")
    _text(raw.get("server_environment"), "target server_environment")
    commit = raw.get("commit_sha")
    if not isinstance(commit, str) or not COMMIT_SHA.match(commit):
        raise LedgerError("target commit_sha must be a full lowercase 40-character hex commit")
    _timestamp(raw.get("selected_at"), "target selected_at")
    return {key: raw[key] for key in TARGET_KEYS}
```

and, next to `ensure_session`:

```python
    def set_session_target(self, session_id, target):
        """The pin for later items in this session. An accepted item keeps the target it snapshotted (spec §6)."""
        target = checked_target(target)
        with self._transaction():
            if self.session(session_id) is None:
                raise LedgerError(f"unknown session: {session_id}")
            self.connection.execute("UPDATE sessions SET target_json=? WHERE session_id=?",
                                    (_json(target), session_id))
        return self.session(session_id)
```

- [ ] **Step 5: Pin at receipt and echo the pin**

In `agent/receiver.py`, give `Receiver.__init__` a `worktrees=None` keyword and store it. Three details about *where* the block goes, each of which the obvious placement gets wrong:

- `session = self.ledger.session(prepared["session_id"])` is read at `agent/receiver.py:170`, **before** `ensure_session` at line 173. The method's `def` is line 167 and the issue fetch and `observe_issue` are 168–169; those three lines stay exactly as they are. For a brand-new session — the only case this task exists for — that local is `None`. The block therefore rebinds the variable from `ensure_session`'s own return value, which is already the session view, and guards only on the target.
- `session_id = prepared["session_id"]` is not bound until after `route(...)`. The block uses `prepared["session_id"]` explicitly rather than depending on a name that does not exist yet.
- The pin does **not** get its own `_send`. It is appended to the ACK body that the existing code already sends with this event's `ack_id`.

Replace the four-line block that begins `session = self.ledger.session(prepared["session_id"])` and ends with the `self.ledger.ensure_session(...)` call — `agent/receiver.py:170-173` today; anchor on the text, not the numbers, which drift — with:

```python
        session = self.ledger.session(prepared["session_id"])
        is_delegation = (session["delegation"] if session else
                         prepared["action"] == "created" and issue.get("delegate_id") == self.identity["appUserId"])
        session = self.ledger.ensure_session(prepared["session_id"], issue["id"], is_delegation, prepared["guidance"])
        pin = ""
        if session.get("target") is None and self.worktrees is not None:
            try:
                commit = self.worktrees.remote_head(TARGET_REPO, timeout=PIN_TIMEOUT)
                session = self.ledger.set_session_target(prepared["session_id"], {
                    "repository": TARGET_REPO, "requested_ref": "default", "commit_sha": commit,
                    "server_environment": self.default_server_environment,
                    "selected_at": datetime.now(timezone.utc).isoformat()})
                pin = f"\n目标已锁定：{TARGET_REPO}@{commit[:7]}（{self.default_server_environment}）。"
            except Exception:
                # A pin that cannot be resolved must not stop the session; the item runs unpinned and any
                # Unity rung will refuse it, which is a recorded gap rather than a silent wrong-commit run.
                pin = "\n暂时无法锁定客户端提交，本次将不做 Unity 验证。"
```

and append `pin` to the two ACK bodies the `work` and `chat` branches already send:

```python
            self._send(session_id, ack_id, {"type": "thought", "body": ACK.get(decision.skill, ACK["chat"]) + pin})
```

with `TARGET_REPO = "Farm-Client"` and `PIN_TIMEOUT = 8` at module level, `from datetime import datetime, timezone` in the imports, and `self.default_server_environment` passed in from `service.build` as `config.default_server_environment`. Eight seconds is the budget: spec §17 criterion 1 gives the whole acknowledgment ten, and `fetch_issue` has already spent some of it. In `agent/service.py`, pass both through:

```python
    receiver = Receiver(paths.ledger, config.webhook_secret,
                        {"oauthClientId": config.client_id, "appUserId": identity["viewer"]["id"],
                         "organizationId": identity["organization"]["id"]},
                        api, lambda: Ledger(paths.ledger, check_same_thread=False), set(skills), scheduler,
                        worktrees=worktrees, default_server_environment=config.default_server_environment)
```

- [ ] **Step 6: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k target -k resolve_commit -k remote_head -k pins -k without_a_pin -k acknowledgment -k clones`
Expected: PASS, eleven tests: the eight new ones plus the three the substrings already match today (`-k target` selects `test_pr_targets_accept_ssh_remotes_ignore_case_and_refuse_a_config_without_github`, `-k clones` the two `SeedCloneTests` cases). `-k without_a_pin` is in the list because `test_a_session_whose_client_head_cannot_be_resolved_still_starts_without_a_pin` contains none of the other six substrings — `_a_pin` is not `pins` — and without it both this gate and Step 2's run seven of the eight.

- [ ] **Step 7: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 147 tests (+8: three in `tests/test_worktrees.py`, two in `tests/test_ledger.py`, three in `tests/test_receiver.py`).

```bash
git add agent/worktrees.py agent/ledger.py agent/receiver.py agent/service.py tests/test_worktrees.py tests/test_ledger.py tests/test_receiver.py
git commit -m "feat(receiver): pin every session to a resolved client commit

sessions.target_json was read by the receiver and written by nothing, so every
work item shipped a null target. A new session now resolves Farm-Client's remote
default head to a full commit, validates and reprojects it, and echoes the pin in
the first activity so a human can correct it before work starts.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

