# Task 7 report — tool injection, and the batch run moved out of the worker

Commit: `bae5210` (branch `phase1b-tasks-5-11`, on top of `0d8e882`).

## Task 6's debt: DISCHARGED

`serve()`'s `finally` in `agent/service.py` now calls `components.launcher.stop_all_unsandboxed()`.
**Explicit confirmation: the call is present.** It is placed **before** the thread joins, not after them:

```
    finally:
        components.server.server_close()
        stop.set()
        components.launcher.stop_all_unsandboxed()
        for thread in threads:
            thread.join(timeout=20)
        components.receiver.close()
        ...
```

The brief's shape implied "somewhere in the finally". After the joins is wrong: the pool thread may be
blocked in `run_batch`'s `wait(timeout=batch_timeout)` for up to half an hour, so joining first would burn
the 20-second join timeout and only then kill the Editor, leaving that thread alive while `pool.close()`
shuts its ledger connection underneath it. Killing first lets the pool thread actually finish its tick.

It is guarded by a real end-to-end test, not by an assertion on a double:
`tests/test_service.py::test_shutdown_kills_an_unsandboxed_run_instead_of_orphaning_it_on_the_slot`
starts a real long-lived process through the production `Launcher.run_unsandboxed` while `serve()` is
running, shuts the server down, and asserts the pid is gone afterwards. Mutation M1 (delete the call)
fails it.

## What was implemented

### `agent/launcher.py`
- `Unsandboxed = namedtuple("Unsandboxed", "returncode timed_out seconds")` beside `Handle`/`Finished`.
- `Launcher.run_unsandboxed(argv, *, cwd, timeout, log=None, env=None, owner=None)` — the only process in
  FarmBot started outside the worker seatbelt. No isolated home, no `CODEX_HOME`, no sandbox table.
- `Launcher.kill_group(pid, grace=5.0, reap=None)` — SIGTERM then SIGKILL the **process group**.
- `Launcher.stop_unsandboxed(owner) -> bool`, `Launcher.stop_all_unsandboxed() -> list`.
- `__init__` gains `self._unsandboxed` and `self._unsandboxed_lock`; module gains `import threading`.

### `agent/slots.py`
- `DEFAULTS` gains `"batch_timeout": 1800`.
- `SlotPool.__init__` gains `run_unsandboxed=None`.
- `SlotPool.run_batch(slot, reservation)` composes the argv from the slot entry and the item's state
  directory, runs it, parses the XML, writes `<state_dir>/unity-batch.json` with
  `{state, exit_code, seconds, results_file, log_file, total, passed, failed, result}` and raises
  `SlotError(stage="probe")` only when a timed-out Editor still holds the folder.
- `_hand_over` calls it after a successful batch switch.

### `agent/scheduler.py`
- `__init__` gains `slot_entries=None`; `launch` builds `servers` and the `resource` block from the
  **reservation**, and passes `servers` (not `{}`) to `spawn`. `_batch_result(state_dir)` reads the pool's
  summary and represents a missing one as `{"state": "gap", ...}`.
- `writable` is unchanged: no slot folder reaches any worker's roots, in either mode.

### `agent/dispatch.py`
- `dispatch_message(..., resource=None)`; `"resource": resource` in the payload; `AUTHORITY` extended with
  the never-start-Unity / exit-code-is-advisory / main-is-known-red sentences.

### `agent/service.py`
- One `entries` list shared by the scheduler (`slot_entries=`) and the pool; pool gets
  `run_unsandboxed=launcher.run_unsandboxed`; `serve`'s finally gets the kill (above).

### `agent/deploy.py`
- `"ProcessType": "Standard"`.

## Tests added (19 new; 241 → 260)

`tests/test_launcher.py` (3)
- `test_an_unsandboxed_run_is_the_only_way_out_of_the_seatbelt_and_carries_no_sandbox_config`
- `test_an_owned_unsandboxed_run_can_be_killed_by_item_and_takes_its_children_with_it`
- `test_an_injected_http_server_is_written_in_each_runtime_s_own_shape`

`tests/test_slots.py` (5)
- `test_the_pool_runs_the_batch_itself_and_hands_the_worker_the_results`
- `test_a_batch_run_with_no_results_is_a_verification_gap_and_not_a_slot_failure`
- `test_a_previous_runs_results_are_never_read_as_this_runs_evidence`
- `test_a_pool_with_no_unsandboxed_runner_refuses_a_batch_grant_rather_than_faking_it`
- `test_a_batch_editor_that_outlives_its_timeout_and_still_holds_the_folder_holds_the_slot`
- plus the `FakeUnity` double and a `run_unsandboxed` default on `SlotFixture.pool`.

`tests/test_scheduler.py` (6)
- `test_a_batch_reservation_gives_the_worker_results_and_neither_an_argv_nor_the_slot`
- `test_a_batch_worker_whose_run_left_no_summary_is_told_it_has_no_evidence`
- `test_an_interactive_reservation_injects_the_slot_address_and_not_its_folder`
- `test_the_injected_server_takes_the_shape_the_claude_runtime_needs`
- `test_an_item_with_no_reservation_is_launched_with_no_tools_and_no_resource_block`
- `test_a_skill_whose_manifest_claims_no_slot_is_given_none_even_holding_one`
- plus `granted_item(mode=...)` and `waiting_item(mode=...)` helpers.

`tests/test_dispatch.py` (2)
- `test_a_resource_block_names_the_slot_and_the_token_file_but_never_the_token`
- `test_a_worker_with_no_reservation_carries_a_null_resource`

`tests/test_deploy.py` (1)
- `test_the_serve_agent_runs_in_the_standard_band_so_unity_is_not_throttled`

`tests/test_service.py` (2)
- `test_build_hands_the_pool_the_launchers_runner_and_the_scheduler_the_same_slot_entries`
- `test_shutdown_kills_an_unsandboxed_run_instead_of_orphaning_it_on_the_slot`

## Commands and output

Baseline before any change:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -W error -m unittest discover -s tests
Ran 241 tests in 52.646s
OK
```

Failing-first (Step 2). The brief's `-k` set does not match every new name, so it is extended:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -W error -m unittest discover -s tests -v \
    -k unsandboxed -k batch -k reservation -k resource_block -k runtime_s_own_shape \
    -k standard_band -k previous_runs_results -k claude_runtime_needs -k launchers_runner
Ran 24 tests in 0.942s
FAILED (failures=1, errors=12)
```

Every failure was for the right reason: `ImportError: cannot import name 'Unsandboxed'`,
`'SlotPool' object has no attribute 'run_unsandboxed'`, `'Launcher' object has no attribute
'stop_unsandboxed'`, `Scheduler.__init__() got an unexpected keyword argument 'slot_entries'`,
`dispatch_message() got an unexpected keyword argument 'resource'`, and
`AssertionError: 'Background' != 'Standard'`. The `test_slots` ImportError masked that module's four
cases until `Unsandboxed` existed. `test_an_injected_http_server_is_written_in_each_runtime_s_own_shape`
passed from the start, as the brief predicted — it is a regression guard on `write_mcp_config`.

Selection after implementation:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -W error -m unittest discover -s tests -v -k unsandboxed -k batch \
    -k reservation -k resource_block -k runtime_s_own_shape -k standard_band -k previous_runs_results \
    -k claude_runtime_needs -k launchers_runner
Ran 34 tests in 10.023s
OK
```

Whole suite, warning-free:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 260 tests in 58.745s
OK
```

`.local/editors/slot-1` is untouched: still detached at `7d886c72ea3f49fce98b20d7ef19636bd7eabf50`,
working tree clean.

## Dependencies checked rather than trusted

- **Codex TOML shape.** Ran `codex mcp add unity --url http://127.0.0.1:8080/mcp` against a scratch
  `CODEX_HOME` (codex-cli 0.154.0) and read the file back: it writes `[mcp_servers.unity]` with a bare
  `url = "..."`. The brief's codex shape is right.
- **`--approve-for-me`.** `codex exec --help` states verbatim that it routes approvals "using the
  workspace-write sandbox", so the addendum's hang applies to every worker FarmBot spawns. Confirmed.
- **`ProcessType`.** `Standard` is a valid launchd value; asserted through `plistlib.loads` on both the
  rendered string and the installed file.
- **`os.killpg` semantics.** `start_new_session=True` makes the child its own group leader, so
  `os.getpgid(pid) == pid` and the group is the right unit. Verified by the grandchild test.

## Brief defects found and how they were resolved

1. **`FakeUnity.__call__` has no `owner` parameter** while `run_batch` passes `owner=`. As written the
   double raises `TypeError` on every call. Added `owner=None` and recorded it in `self.owners`, which is
   now asserted — that assertion is what makes the registration real (mutation M13).
2. **`editor_path` would reach `/Applications` in `tests/test_slots.py`.** The brief's pool tests use the
   fixture's slot entry, which has `unity: None`, and the slot folder is a git worktree of a README with
   no `ProjectSettings/ProjectVersion.txt`. `run_batch` would therefore raise `UnityError` and every batch
   grant in `PoolTests` would fail — or, on a host that has the Editor installed, silently probe
   `/Applications`, violating a global constraint. `SlotFixture` now touches a fake binary and sets it as
   the entry's `unity` override.
3. **`tests/test_dispatch.py`'s budget dict is wrong.** The brief passes `{"max_hours": 2, "max_usd": 5}`;
   `dispatch_message` reads `budget["lease_seconds"]` and `budget["renew_minutes"]`, so it would `KeyError`.
   Matched the module's existing shape, as the brief's own closing sentence instructs.
4. **`assertNotIn("token_file", json.dumps(payload).replace('"token_file"', ""))` is a tautology** — the
   value `/runs/i/reservation.token` does not contain the string `token_file`, so it cannot fail. Replaced
   with a positive assertion on the path. The real "no token in the prompt" guard is
   `assertNotIn("res_", message)` in the scheduler test, which is where a raw token could actually appear.
5. **`run_unsandboxed`'s timeout path leaks a zombie and spins.** The brief's `kill_group` polls
   `self.alive(pid)`, but an unreaped child is a zombie and `os.kill(zombie, 0)` **succeeds**, so the loop
   would run its full 5 s + 1 s on every timeout and then return without reaping — a `ResourceWarning`
   risk under `-W error` and a corpse per timed-out batch run. `kill_group` gained `reap=<Popen>`, used
   only from the thread that owns the wait; `stop_unsandboxed` deliberately passes `reap=None` so it does
   not race the run thread for the same `waitpid`.
6. **`FakeLauncher` has no `runtime`**, which the scheduler now reads for `mcp_format`. Added
   `runtime = RUNTIMES["fake"]` (mcp_format `toml`), matching the brief's expected `{"url": ...}` shape.
7. **`FakeLauncher.state_dir` returns `/fake/runs/<id>`**, which nothing can write, so the brief's
   `granted_item` could not leave a `unity-batch.json` for the scheduler to read. `FakeLauncher` now takes
   a runs root and `SchedulerTests` passes a real temporary one; the one existing assertion on that literal
   was rewritten as `str(self.launcher.state_dir(item["id"]))`, which keeps its meaning.
8. **`test_the_pool_grants_from_its_own_thread_while_another_connection_reads` (Task 6) constructs
   `SlotPool` by hand**, so it had no runner and its batch grant started failing. Given the fixture's
   `FakeUnity`; the test is about connection isolation and is unweakened.
9. **The brief never says what happens when `run_batch` raises something that is not a `SlotError`.**
   Left uncaught it escapes into `serve()`'s guarded loop inside the hand-over window — the exact
   unrecoverable state `_hand_over`'s docstring is about, and it would have broken Task 6's
   `test_a_hand_over_that_fails_after_the_switch_gives_the_slot_back_instead_of_wedging_it`, whose two
   subtests (`state_dir=None`, unwritable `state_dir`) now hit `run_batch` first. `_hand_over` routes a
   non-`SlotError` from `run_batch` through `_give_the_slot_back` with the same reason string, so the slot
   returns to the pool rather than being held against an operator who cannot fix it there.
10. **The brief's `-k` selection would have under-run the gate.** `-k batch` alone does not match
    `previous_runs_results`, `claude_runtime_needs` or `launchers_runner`; `unittest -k` is a plain
    substring with no boolean operators, so the extended set above is what was actually run.
11. **The brief's Files list omits `tests/test_service.py` entirely**, which is where Task 6's headline
    defect lived — unguarded production wiring. Both of this task's `build()` injections and the
    `stop_all_unsandboxed` call are now asserted there.
12. **Predicted counts were stale again**: the brief says "nine new tests" and "205 tests (+10)". Real
    figures: 19 new tests, 241 → 260.

## Self-review: mutation checks

Run with `python3 -B -W error` after a working-tree backup (not `git checkout`).

| # | Mutation | Selection | Result |
|---|---|---|---|
| M1 | delete `stop_all_unsandboxed()` from `serve`'s finally | `-k orphaning` | FAILED |
| M2 | `spawn(..., servers, ...)` → `{}` | `-k injects_the_slot_address -k claude_runtime_needs` | FAILED |
| M3 | `os.killpg(group, sig)` → `os.kill(pid, sig)` | `-k takes_its_children` | FAILED |
| M4 | drop `results.unlink(missing_ok=True)` | `-k previous_runs_results` | FAILED |
| M5 | `if summary["total"] == 0` → `if False` | `-k no_results_is_a_verification_gap` | FAILED |
| M6 | `if self.editor_pid(...) is not None` → `if False` | `-k outlives_its_timeout` | FAILED |
| M7 | `"batch_result": None` always | `-k gives_the_worker_results -k no_summary` | FAILED |
| M8 | `if self.launcher.runtime.mcp_format == "toml"` → `if True` | `-k claude_runtime_needs` | FAILED |
| M9b | drop `reservation["kind"] in skill.resources` | `-k manifest_claims_no_slot` | FAILED |
| M10 | `servers, resource = {"unity": ...}, None` | `-k no_reservation_is_launched` | FAILED |
| M11b | `if self.run_unsandboxed is None` → `if False` | `-k unsandboxed_runner` | FAILED |
| M12b | drop `kill_group(process.pid, reap=process)` on timeout | `-k only_way_out_of_the_seatbelt` | FAILED |
| M13 | `owner=reservation["item_id"]` → `owner=None` | `-k runs_the_batch_itself` | FAILED |

Three of these found tests that looked like coverage and were not, and all three were fixed **before**
the commit:

- **M9** (first run) passed: the manifest gate `reservation["kind"] in skill.resources` was unobservable,
  because only `fix` requests slots and only `fix` declares them. Added
  `test_a_skill_whose_manifest_claims_no_slot_is_given_none_even_holding_one`, which moves a granted item
  onto `chat` (`resources: []`) and asserts it gets neither the server nor a resource block. Re-run as M9b.
- **M11** (first run) passed with all 42 slot tests green: the brief's promise that "a pool built without
  one refuses a batch grant" was asserted nowhere, because every pool in the suite has a runner. Added
  `test_a_pool_with_no_unsandboxed_runner_refuses_a_batch_grant_rather_than_faking_it`. Re-run as M11b.
- **M12** (first run) passed: my own first draft of the timeout assertion checked only
  `slow.timed_out is True` and the elapsed seconds, so a `run_unsandboxed` that gave up waiting and walked
  away — leaving a real Editor on the slot for ever, the precise failure this task exists to prevent —
  was green. The child now writes its pid to a marker and the test asserts the pid is gone after the
  deadline. Re-run as M12b.

## Known gap, handed forward (the same shape Task 6 handed me)

**`Scheduler.stop` does not call `launcher.stop_unsandboxed(item_id)`.** `Launcher.stop` resolves
`self._handles`, which only `spawn` populates, so a Linear Stop landing during a batch run cancels the
item and leaves the Editor running until `batch_timeout`. The three Launcher methods that close this
exist and are tested; the wiring is not done here because the brief's Files list scopes
`agent/scheduler.py` to `launch` and `__init__` only, and its own comments place the Stop ordering in
Task 9 ("the exact outcome Task 9 is named after preventing", "Task 9's ordering test"). Service
shutdown — the half this task owns — is wired and tested.

The change, when Task 9 takes it, is one line in `Scheduler.stop`:

```python
    def stop(self, item_id, reason):
        killed = self.launcher.stop(item_id)
        self.launcher.stop_unsandboxed(item_id)   # <- the batch Editor never went through spawn()
```

plus `stop_unsandboxed` on `FakeLauncher` in `tests/test_scheduler.py` (a hand-rolled double, so it
raises `AttributeError` without it) and a test that a Stop during a batch run kills the Editor.

## One process incident worth recording

Partway through the self-review my mutation helper restored files with `git checkout -- <file>` instead of
from a working-tree backup, which reverted `agent/launcher.py`, `agent/slots.py`, `agent/scheduler.py` and
`agent/service.py` to `0d8e882` and destroyed their Task 7 changes. They were re-applied verbatim and the
whole suite re-run green (260) before the commit; mutations M4 and M9-M13 were then re-run against a
backup-based helper. M4's first result was invalid for the same reason (an `ImportError`, not the
mutation) and was re-run. No production behaviour differs from what was reviewed above, but the
intermediate `git status` in this session's history reflects that detour.
