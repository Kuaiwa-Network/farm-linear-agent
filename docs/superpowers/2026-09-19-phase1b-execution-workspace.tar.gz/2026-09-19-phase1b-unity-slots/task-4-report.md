# Task 4 report — the slot switch, the Editor life cycle and the park back to main

Branch `phase1b-unity-slots`, on top of 2875ca9.

## What I implemented

**Created `agent/unity.py`** — the only module in `agent/` that names an operating system or an install
path. `project_version`, `candidates`, `editor_path` (with injectable `exists` and `environ`),
`batch_test_command` (no `-quit`, no `-nographics`, no `-accept-apiupdate`), `read_results`, and the two
halves of one process listing, `_editor_processes` / `other_editor_project` / `editor_holds_project`, with
an injectable `run` so nothing in the suite shells out to `pgrep`.
`writable_roots()` was not removed because it never existed — nothing in the tree ever defined it. (The
`writable_roots` in `agent/launcher.py` is the Codex sandbox config key, a different thing, untouched.)

**Modified `agent/slots.py`** — `SlotError` grew `STAGES` and a `stage` attribute defaulting to `"git"`;
`DEFAULTS` grew `quiet_timeout: 300` and `close_timeout: 60`; `SlotPool.__init__` grew `sleep`,
`editor_scan` and `editor_pid` (plus `self.last_observation = None`, which the brief's `switch` assigns but
never initialises); and the pool grew `switch`, `editor_is_open`, `open_editor`, `close_editor`,
`wait_for_quiet`, `another_editor_running`, `park` and the static `clear_stale_lock`.

**Modified `agent/worktrees.py`** — `checkout_commit` now classifies a failed checkout through the existing
`_transfer_kind`, exactly as `add_slot` does (carried finding, below).

**Modified `tests/test_slots.py`** — `SlotFixture.pool` now passes `sleep`, `editor_scan` and `editor_pid`;
added `INSTANCE`, `FakeMcp` and `SwitchTests`.

**Created `tests/test_unity.py`** — `UnityTests`.

## Test names per file

`tests/test_unity.py` — `UnityTests` (5):
- `test_the_editor_is_found_per_host_from_the_project_version`
- `test_an_absent_editor_names_every_path_it_tried`
- `test_the_batch_command_never_quits_never_drops_graphics_and_never_rewrites_sources`
- `test_the_results_file_is_the_evidence_and_a_zero_total_is_a_verification_gap`
- `test_another_editor_on_a_different_project_is_seen_and_our_own_is_not`

`tests/test_slots.py` — `SwitchTests` (13):
- `test_a_batch_switch_moves_the_slot_to_the_commit_and_marks_it_busy`
- `test_an_interactive_switch_on_a_closed_slot_starts_the_editor_before_it_probes`
- `test_an_interactive_switch_on_an_open_slot_does_not_restart_the_editor`
- `test_a_stale_lock_file_never_makes_a_dead_editor_look_open` *(added — see Defect 2)*
- `test_a_batch_switch_on_an_open_slot_closes_the_editor_gracefully_first`
- `test_a_dirty_slot_refuses_to_switch_and_says_which_stage_failed`
- `test_a_failing_identity_probe_fails_at_the_probe_stage_not_the_git_stage`
- `test_a_refresh_that_never_goes_quiet_fails_at_the_probe_stage_before_any_probe`
- `test_an_editor_that_is_still_compiling_is_waited_for_rather_than_failed` *(added — see Defect 3)*
- `test_a_compile_error_fails_the_item_at_its_own_stage_and_leaves_the_slot_usable`
- `test_a_stale_lockfile_is_cleared_and_a_live_one_is_kept`
- `test_another_editor_on_the_host_holds_the_slot_before_any_git_runs` *(added — see Defect 4)*
- `test_park_returns_a_batch_slot_to_main_closed_and_an_interactive_slot_to_main_open`

`tests/test_worktrees.py` — `WorktreeTests` (1 added):
- `test_a_slot_that_cannot_be_moved_tells_credentials_from_reachability_too`

## Commands and output

Baseline before any change:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 173 tests in 14.635s
OK
```

Failing-first (Step 2), before `agent/unity.py` existed and before `SlotPool.__init__` grew its arguments:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k UnityTests -k SwitchTests
...
TypeError: SlotPool.__init__() got an unexpected keyword argument 'sleep'
...
ModuleNotFoundError: No module named 'agent.unity'
Ran 12 tests in 0.460s
FAILED (errors=12)
```

Both of the brief's predicted reasons, and no others. (11 `SwitchTests` at that moment plus one
`unittest.loader._FailedTest` standing in for the whole unimportable `test_unity` module.)

Failing-first for the `checkout_commit` classification, before the `worktrees.py` change:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k test_a_slot_that_cannot_be_moved
AssertionError: '(credentials)' not found in 'git checkout failed: HTTP 401 Authorization required'
AssertionError: '(reachability)' not found in 'git checkout failed: Failed to connect to git.kuaiwa.com port 443: Connection refused'
Ran 1 test in 0.271s
FAILED (failures=2)
```

Selection after implementation:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k UnityTests -k SwitchTests -k test_a_slot_that_cannot_be_moved
Ran 19 tests in 8.172s
OK
```

Whole suite, final:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 192 tests in 24.307s
OK
```

**192, not the brief's 179.** The brief's "+15" was computed against a 164-test baseline; the real baseline
was 173. 173 + 19 = 192: 5 in `test_unity.py`, 13 in `SwitchTests` (10 from the brief plus 3 added), 1 in
`test_worktrees.py`. Every `__pycache__` was deleted before each measurement and every run used `-B` with
`PYTHONDONTWRITEBYTECODE=1`.

The real slot was verified untouched afterwards: `.local/editors/slot-1` is still detached at
`7d886c72ea3f49fce98b20d7ef19636bd7eabf50`, `git status --porcelain --untracked-files=no` is empty, and the
folder's mtime is still Sep 19 22:49.

## Brief defects found and how I resolved them

**Defect 1 — `read_results`'s third failure mode was specified but not tested.** The brief's `Produces`
entry says `read_results` raises "when the file is missing, unparseable **or carries no `total`**", and its
own test covers only the first two. The brief's loop is also an expression statement
(`broken.write_text(...) if ... else None`). *Resolved:* rewrote the loop as a plain `if`, added a
`headless.xml` with `result` but no `total`, and wrapped each case in `subTest`. The no-`total` branch of
`read_results` is now the reason a test passes rather than untested prose.

**Defect 2 — `editor_is_open`'s central claim had no test that could fail.** The brief argues at length
that liveness must be a process question and never `Temp/UnityLockfile`, and `FakeMcp`'s docstring says the
two are "kept apart on purpose". They are not: in every brief test the pool removes the lock itself, so the
file and `open_folders` agree everywhere. I confirmed this by mutation — replacing the body of
`editor_is_open` with `(folder / "Temp" / "UnityLockfile").exists()` left all 17 tests green. *Resolved:*
added `test_a_stale_lock_file_never_makes_a_dead_editor_look_open`, which plants a lock file with no process
behind it and asserts the interactive switch still calls `start` first. That mutant now fails.

**Defect 3 — `wait_for_quiet`'s retry loop had no test that could fail.** The only quiescence test uses an
Editor that never goes quiet, so a one-shot `wait_for_quiet` that gives up on its first `TimeoutError`
behaves identically. Mutation confirmed: collapsing `if self.clock() >= deadline:` to `if True:` left all 17
tests green. That mutant is the exact bug Task 0 Step 5's 5.7–9.6 s recompiles predict — every genuine
recompile would become a probe-stage hold on the only slot. *Resolved:* added
`test_an_editor_that_is_still_compiling_is_waited_for_rather_than_failed`, an MCP that times out twice and
settles on the third sample; it asserts the switch succeeds, that three samples were taken, and that the
*injected* sleep advanced the clock (so the test cannot start waiting on a real one).

**Defect 4 — the contention preflight was specified, argued for, and untested.** Nothing in the brief
exercises `another_editor_running` returning a path. *Resolved:* added
`test_another_editor_on_the_host_holds_the_slot_before_any_git_runs`, which uses a `Worktrees` spy whose
`fetch` raises `AssertionError` — so it pins both halves of the contract: the refusal is at the `probe`
stage (a hold, not a retryable `git`), and it happens *before* any git runs.

**Defect 5 — `self.last_observation` was assigned but never initialised.** Reading `pool.last_observation`
before the first successful interactive switch would raise `AttributeError`. *Resolved:* initialised to
`None` in `__init__`.

**Defect 6 — a comment in `close_editor` contradicted the code beneath it.** The brief's comment reads "A
surviving server is not worth failing the close over" and is immediately followed by a `raise`. *Resolved:*
rewrote the comment to match the specified behaviour (failing is correct — the next `open_editor` would
attach to a server whose Editor is gone). No behaviour change.

**Defect 7 — the brief's predicted counts are wrong.** Step 5 says "fifteen tests", Step 6 says "179 (+15)".
The real figures are above. Reported, not chased.

## Carried findings

**`checkout_commit` was dead and untested; Task 4 is its first caller.** It is now called from both
`switch` and `park`, and is covered by `test_a_batch_switch_moves_the_slot_to_the_commit_and_marks_it_busy`
(asserting the folder's head), `test_park_returns_...` (both directions) and the new worktrees test.
Mutation-checked: replacing the `switch` call with `pass` fails the suite.

**A 401 or unreachable origin surfaced unlabelled on `checkout_commit`.** I judged this **in scope and
fixed it**, although `agent/worktrees.py` is not in the brief's Files list. The reasoning: `checkout_commit`
is smudge-on exactly as `add_slot` is, so the LFS download for the incoming commit happens inside it — it is
where a credential or reachability failure surfaces on *every switch after the first*, which is the path
this task creates. `switch` wraps it as `SlotError(stage="git")`, so the operator reads "git stage failed:
git checkout failed: …" with no indication of which of their two problems it is, and the retry rule then
re-queues it once and fails the item as a verification gap. The fix is four lines reusing the existing
`_transfer_kind`, and the new test mirrors the existing `add_slot` classification test exactly, including
the third case (a bad reference stays unlabelled).

**`park_idle` freeing a slot that still holds an active reservation raises a raw `sqlite3.IntegrityError`.**
Not actionable here: `park_idle` does not exist yet — it is Task 6's, and `park` in this task takes an
explicit `slot_id` and never touches reservations. The finding stands for Task 6, where `park_idle` is
written; nothing in `agent/ledger.py` was changed.

**An `idle_open` slot keeps a possibly stale `parked_commit`.** Task 4 closes the normal path: `park` now
writes `parked_commit` on *both* the `idle_open` and the `idle_closed` branch, and it writes the commit it
actually checked the folder out to, so an `idle_open` row is accurate at park time and nothing moves the
folder afterwards. What remains is Task 3's restart case — `ensure()` still reconciles only when
`fresh or state == "idle_closed"` — so a service restart while a slot is `idle_open` keeps whatever was last
recorded. That value is now correct by construction rather than by luck, so I left `ensure()` alone rather
than expanding into Task 3.

## Mutation checks

Every one with `__pycache__` deleted first and `python3 -B` with `PYTHONDONTWRITEBYTECODE=1`. All thirteen
are killed by the final suite; the two marked ⚠ survived the brief's tests and are what motivated Defects 2
and 3.

| # | Mutation | Result |
|---|---|---|
| M1 | `switch` drops the `fetch` | killed (3 failures, 5 errors) |
| M2 ⚠ | `editor_is_open` reads `Temp/UnityLockfile` | survived → killed after Defect 2's test |
| M3 | `close_editor` stops removing the lock file | killed |
| M4 | `was_open` forced `False` | killed |
| M5 | contention preflight dropped | killed |
| M6 | `park` stops recording `parked_commit` | killed |
| M7 | batch branch never closes an open Editor | killed |
| M8 | `clear_stale_lock` ignores `alive()` | killed |
| M9 ⚠ | `wait_for_quiet` gives up on the first timeout | survived → killed after Defect 3's test |
| M10 | compile errors ignored | killed |
| M11 | `instance` never recorded | killed |
| M12 | `slot_clean` check dropped | killed |
| M13 | `switch` never calls `checkout_commit` | killed |

## Self-review findings

These are things I noticed in the diff and deliberately did **not** change, because changing them would
diverge from behaviour the brief argues for explicitly. They are for the reviewer to rule on.

1. **`park`'s `idle_closed` branch removes the lock file with `lambda: False`, without asking whether an
   Editor is alive.** `clear_stale_lock`'s entire contract is "only when `alive()` says the process is
   gone", and this call site asserts "gone" rather than checking. In the intended flow it is safe (a batch
   switch has already closed any Editor, and the interactive branch only reaches `idle_closed` when
   `editor_is_open` was False). But `park(slot_id, "batch")` on a slot whose Editor is genuinely open would
   both mislabel the state *and* delete a live Editor's lock. The one-word fix is
   `self.clear_stale_lock(folder, lambda: self.editor_is_open(slot))`; I left the brief's version.
2. **Two process listings per switch.** `editor_is_open` and `another_editor_running` each call
   `_editor_processes` through separate injection points, so a real switch runs `pgrep` twice where one
   listing answers both questions. Harmless, but Task 6's pool thread will do this every tick.
3. **`except Exception` is broad in three places in `switch`** (`refresh`/`wait_for_quiet`, `open_editor`,
   `probe`). A programming error — an `AttributeError` on a `None` mcp, say — is relabelled "the Editor
   never went quiet" and routed to `probe`, which **holds the only slot** for an operator. Brief-specified,
   but it is the failure mode with the worst blast radius in this file.
4. **`SlotError.STAGES` is declared and never read.** Nothing validates `stage` against it. It is
   documentation for Task 6's caller; either that caller uses it or it should go.
5. **Uncovered branches I did not add tests for**, to keep the addition tied strictly to "the brief claims
   something no test can disprove": the `pointers_remain` guard in `switch`, `open_editor`'s failure path,
   both of `close_editor`'s failure paths, `park`'s `WorktreeError` path, `switch`'s and `park`'s
   `unknown slot` guards, and `editor_path`'s `override` argument.
6. **`SlotPool.unity` is still unused** (inherited from Task 3). Task 7 is its first reader, via
   `agent.unity.editor_path`.

---

# Fix round 1 — three review findings

All three are fixed, each with a covering test proven by reverting the fix. Suite went 192 → 195.

## Finding 1 (Critical) — `clear_stale_lock` must never be handed an assertion

**What changed.** Every production call site now passes `lambda: self.editor_is_open(slot)` instead of
`lambda: False`. Four sites, not the two the ruling named:

1. `park`'s `idle_closed` branch (`agent/slots.py`) — the ruling's first site. A departing mode of `batch`
   says nothing about the host, so `park(slot_id, "batch")` against a live Editor was deleting the file that
   enforces Unity's one-Editor-per-folder guarantee.
2. `switch`'s batch branch — the ruling's second site, reached because `was_open` is guarded by
   `self.mcp is not None`, so a pool built with `mcp=None` never asked the process question at all.
3. `switch`'s start path, before `open_editor` — Finding 3, below; the same one-line guard closes it.
4. `close_editor`, after its SIGTERM — **not in the ruling**, found while making the invariant uniform. It
   treated its own `terminate()` as proof the process was gone. A `terminate` that returns without killing
   anything (a signal to a pid that has been recycled, a fake that lies) would have the pool delete a live
   Editor's lock and then hand the folder to `Unity -batchmode`. Asking the process listing again means the
   lock survives and the close fails loudly at the `editor` stage instead. I also reworded that failure,
   which previously said only "could not be removed", to name both possible causes.

`clear_stale_lock`'s docstring claimed callers "pass `lambda: False` rather than guessing a second time";
it now states the opposite invariant and lists the five call sites (four here plus Task 6's `settle`).
`lambda: False` survives in the file only inside comments explaining why it is wrong, and in the unit test
of `clear_stale_lock` itself, which must exercise both branches of its own guard.

**Covering tests.** `SwitchTests.test_a_live_editors_lock_is_never_deleted_by_a_park_or_a_batch_switch`
(both ruled sites: an interactive switch opens the Editor, then `park(..., "batch")` must leave the lock,
then a second pool with no MCP client at all and a live `editor_pid` runs a batch switch and must leave it
too) and `SwitchTests.test_a_terminate_that_kills_nothing_fails_the_close_instead_of_freeing_the_lock`
(site 4). `test_a_stale_lockfile_is_cleared_and_a_live_one_is_kept` still pins the primitive itself.

## Finding 2 (Critical) — a FarmBot bug must not read as a Unity fault

**What changed.** The hold is unchanged — every stage is exactly what it was, because releasing a slot in an
unknown state risks a second Editor on the folder. What changed is the blame. `SlotError` grew a `fault`
attribute (`"external"` by default: git, Unity, the host or the operator) and a `FARMBOT_FAULTS` tuple
(`AttributeError, TypeError, NameError, KeyError, IndexError, ImportError`). A new
`SlotPool._collaborator_error` classifies the caught exception, sets `fault`, and words the message
accordingly — a FarmBot bug says so and adds "this is not a Unity fault and recover-slot will not fix it".
It repr's the exception rather than str'ing it, because the exception *type* is the diagnostic that
separates the two cases. All five collaborator handlers now go through it: `switch`'s
`refresh`/`wait_for_quiet` (`probe`) and identity probe (`probe`), `open_editor` (`editor`), and both of
`close_editor`'s (`editor`). `wait_for_quiet`'s own deadline `SlotError` is untouched and stays `external`,
which is right: that one is a genuine Unity timeout.

**Covering test.** `SwitchTests.test_a_farmbot_bug_still_holds_the_slot_but_is_not_blamed_on_unity` — an
`AttributeError` from `refresh` must still give `stage == "probe"` (held) but `fault == "farmbot"` and name
the type, while a `ConnectionRefusedError` from the same call must stay `("probe", "external")`. The second
half is what stops the distinction being vacuous.

## Finding 3 (Important) — the interactive start path never cleared a stale lock

**What changed.** `switch` now calls `clear_stale_lock` immediately before `open_editor`, under the same
guard as everywhere else. Without it, a lock surviving a crash or an unreaped close reaches the GUI start,
and a start that the lock blocks is a probe-stage hold on the single slot after any crash.

**Covering test.** `test_a_stale_lock_file_never_makes_a_dead_editor_look_open` gained the missing
assertion. Asserting on the file *after* the switch proves nothing, because `FakeMcp.start` writes a fresh
lock exactly as Unity does; so the fake now records whether the lock existed **at the moment start was
called** (`lock_at_start`), which is the only point where a survivor would matter, and the test asserts it
was `False`.

## Commands and output

Fix-verification by reverting each fix in place, `__pycache__` purged, `python3 -B` with
`PYTHONDONTWRITEBYTECODE=1`, selection `-k SwitchTests`:

| Reverted fix | Result |
|---|---|
| `park` back to `lambda: False` | FAILED (failures=1) |
| `switch` batch branch back to `lambda: False` | FAILED (failures=1) |
| `close_editor` back to `lambda: False` | FAILED (failures=1) |
| `_collaborator_error` always `fault="external"` | FAILED (failures=1) |
| `clear_stale_lock` before `open_editor` deleted | FAILED (failures=1) |
| none (baseline) | OK |

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k SwitchTests
Ran 16 tests in 10.380s
OK
```

Whole suite, final:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests
Ran 195 tests in 26.863s
OK
```

Green and warning-free. `SwitchTests` is now 16; the suite is 195 (192 + 3). The real slot at
`.local/editors/slot-1` is still detached at `7d886c72ea3f49fce98b20d7ef19636bd7eabf50` and clean.

Deferred items were left alone as instructed: the `-projectPath` regex and quoted paths with spaces,
`BUSY_FOR[mode]`'s bare `KeyError`, `SlotError.STAGES` and `FakeMcp.quiescent` being unread until Task 6,
and the two `pgrep` listings per switch. Note that `KeyError` is now in `FARMBOT_FAULTS`, so if a bad mode
ever does reach `BUSY_FOR` inside a guarded handler it would at least be labelled a FarmBot bug — the raw
`KeyError` at the two unguarded `set_slot_state` calls is unchanged and still Task 6's to fix.
