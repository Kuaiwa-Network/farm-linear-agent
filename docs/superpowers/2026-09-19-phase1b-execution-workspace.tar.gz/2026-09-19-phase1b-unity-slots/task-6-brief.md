### Task 6: The pool grants a slot on its own thread and settles it afterwards

Two-phase acquisition becomes real. An `awaiting_resource` item has been inert since Plan 1a because `Scheduler.tick` drains only `ledger.queue()`, which selects `state='queued' AND worker_pid IS NULL`. The pool now grants the oldest request, performs the switch, writes the reservation token where the worker can read it, and calls `ledger.resume`, after which the *existing* launch loop picks the item up on the next tick with no change to the queue query. (Task 7 adds one more step between the switch and the token for a batch grant — the batch Editor itself, run outside the worker's sandbox — in `_hand_over`, which is written here. Nothing in this task anticipates it beyond leaving that method the obvious place for it.)

**Why:** a slot switch is `git checkout --detach` plus `git lfs checkout` on a repository whose `.git` is 3.7 GB, plus an Editor refresh and a compile wait — minutes, not milliseconds. `Scheduler.tick()` holds `self.lock` for its whole body and `agent/service.py` runs it every second. Running the switch inside a tick would freeze reaping, recovery and the 5-second Stop budget of done-criterion 2.

**Decision this task encodes:** two.

First, the pool gets its own thread, beside the receiver and scheduler threads that `serve` already starts, and the scheduler never probes Unity and never blocks on one. **It also gets its own `sqlite3.Connection`.** The two threads meet in SQLite, where `BEGIN IMMEDIATE` and the partial unique indexes serialize them — but only if they are two connections. `agent/service.py:30` builds one `Ledger(paths.ledger, check_same_thread=False)` and hands it to the scheduler; handing the same object to the pool would give two threads one connection whose `_transaction()` is a bare `BEGIN IMMEDIATE`/`COMMIT`, so one thread's `BEGIN` can land inside the other's open transaction and either thread's `COMMIT` or `ROLLBACK` would apply to the other's half-written work. WAL and `busy_timeout` do nothing about that. The receiver already takes a factory (`lambda: Ledger(...)`) for this exact reason, and the pool follows it.

Second, the settlement rule is a query, not a flag: the pool settles any reservation that is `cancel_requested`, or whose item is no longer `queued`, `running` or `awaiting_resource` — those three states are exactly the window in which a granted slot is still on its way to a worker or being used by one — **and whose slot is not `held`**, because a held slot is waiting for a human, not for another probe.

**Files:**
- Modify: `agent/ledger.py` (`fail_queued` accepts an `awaiting_resource` item; `requeue_reservation`)
- Modify: `agent/slots.py` (`SlotPool.tick`, `grant`, `settle`, `park_idle`, the token file, the ledger factory)
- Modify: `agent/service.py` (`build` constructs the pool with its own ledger; `serve` starts its thread)
- Modify: `tests/test_scheduler.py` (delete `test_awaiting_resource_stays_parked_in_phase_1a`, line 221)
- Test: `tests/test_slots.py`, `tests/test_service.py`

**Interfaces:**
- Consumes: `Ledger.acquire`, `release`, `hold`, `reservations_to_settle`, `resume`, `fail_queued`, `cancel_reservations`, `record_identity`; `SlotPool.switch`, `park`, `clear_stale_lock` from Task 4.
- Produces:
  - `Ledger.requeue_reservation(reservation_id, reason) -> str`, the new reservation id: one more `queued` row at the tail of the queue with `attempts` incremented, for the same item, generation and commit.
  - `Ledger.fail_queued(item_id, reason)` accepts an item in `queued` **or** `awaiting_resource`. Its two existing callers in `agent/scheduler.py` pass queued items and are unaffected.
  - `SlotPool(ledger, ...)` where `ledger` may be a `Ledger` **or** a zero-argument factory. When it is a factory the pool calls it once, on the thread that will use it, and closes it in `SlotPool.close()`. Tests pass an object, `service.build` passes a factory.
  - `SlotPool(..., state_dir=None, owner="pool")`. `state_dir` is a callable taking an item id and returning that item's private directory — `Launcher.state_dir` in production.
  - `SlotPool.tick() -> dict` with `settled`, `granted` and `parked` counts. Safe to call from one thread only; it is the pool thread's whole loop body.
  - `SlotPool.token_path(item_id) -> Path`, `<state_dir>/reservation.token`, mode 0600.

- [ ] **Step 1: Write the failing tests**

In `tests/test_slots.py`, add a class that reuses `SlotFixture` and seeds work items the way `ReservationTests` does. Import `ISSUE`, `OTHER`, `SESSION` and `issue` from `test_ledger`, as `tests/test_scheduler.py` already does.

```python
class PoolTests(SlotFixture):
    def waiting(self, issue_id, commit, mode):
        # issue(id=...), not issue(issue_id=...): the helper's keyword is `id` and the wrong one leaves the
        # row on ISSUE, after which create_work_item raises "unknown issue".
        self.ledger.observe_issue(issue(id=issue_id))
        session = f"session-{issue_id}"
        self.ledger.ensure_session(session, issue_id, True)
        target = {"repository": "Farm-Client", "requested_ref": "main", "commit_sha": commit,
                  "server_environment": "公共测试服", "selected_at": SELECTED_AT}
        item = self.ledger.create_work_item(issue_id=issue_id, session_id=session, skill="fix", target=target)
        token = self.ledger.claim(item["id"], worker_id="w")["token"]
        self.ledger.await_resource(item["id"], token, "unity_slot", mode)
        return item["id"]

    def finish_worker(self, item_id, reason="worker finished"):
        """A granted item is 'queued' again, and Ledger.fail refuses anything that is not 'running'. The
        worker's own path is claim-then-terminal, so the fixture takes it rather than inventing one."""
        self.ledger.claim(item_id, worker_id="w2")
        return self.ledger.fail(item_id, reason)

    def pool(self, **kwargs):
        kwargs.setdefault("state_dir", lambda item_id: self.root / "runs" / item_id)
        return super().pool(**kwargs)

    def test_a_queued_request_is_granted_switched_and_resumed_for_a_fresh_worker(self):
        self.pool().ensure()
        commit = self.commit("fix")
        item = self.waiting(ISSUE, commit, "batch")
        pool = self.pool(mcp=FakeMcp())
        self.assertEqual(pool.tick()["granted"], 1)
        self.assertEqual(self.ledger.item(item)["state"], "queued")
        self.assertEqual(self.ledger.item(item)["needs_resource"], None)
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "batch_busy")
        self.assertEqual(self.trees.head(self.root / "editors" / "slot-1"), commit)
        token = pool.token_path(item)
        self.assertTrue(token.is_file())
        self.assertEqual(token.stat().st_mode & 0o077, 0)

    def test_two_requests_serialize_on_the_one_slot_batch_first_then_interactive(self):
        self.pool().ensure()
        first_commit = self.commit("first")
        first = self.waiting(ISSUE, first_commit, "batch")
        second_commit = self.commit("second")
        second = self.waiting(OTHER, second_commit, "interactive")
        pool = self.pool(mcp=FakeMcp())
        pool.tick()
        self.assertEqual(self.ledger.item(second)["state"], "awaiting_resource")
        self.assertEqual(pool.tick()["granted"], 0)
        self.finish_worker(first, "batch worker finished")   # any terminal state hands the slot back
        self.assertEqual(pool.tick()["settled"], 1)
        self.assertEqual(pool.tick()["granted"], 1)
        self.assertEqual(self.ledger.item(second)["state"], "queued")
        self.assertEqual(self.trees.head(self.root / "editors" / "slot-1"), second_commit)
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "interactive_busy")

    def test_two_requests_serialize_in_the_other_order_interactive_first_then_batch(self):
        """The steady state once spec §7's 'after an interactive run the Editor stays open' is real. The
        batch-first ordering never exercises the graceful close, so on its own it would sign off a system
        that is broken for every subsequent pair of items."""
        self.pool().ensure()
        first = self.waiting(ISSUE, self.commit("first"), "interactive")
        second_commit = self.commit("second")
        second = self.waiting(OTHER, second_commit, "batch")
        pool = self.pool(mcp=FakeMcp())
        pool.tick()
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "interactive_busy")
        self.finish_worker(first)
        pool.tick()
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "idle_open")
        self.assertEqual(pool.tick()["granted"], 1)
        # The close is SIGTERM then a reap of the uvx MCP server; the pool removes the lock file itself.
        self.assertEqual([("terminate", "unity_slot:1"), ("reap_server", "unity_slot:1")], pool.mcp.calls[-2:])
        self.assertFalse((self.root / "editors" / "slot-1" / "Temp" / "UnityLockfile").exists())
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "batch_busy")
        self.assertEqual(self.trees.head(self.root / "editors" / "slot-1"), second_commit)

    def test_a_failing_probe_holds_the_slot_and_fails_the_item_without_retrying(self):
        self.pool().ensure()
        item = self.waiting(ISSUE, self.commit("fix"), "interactive")
        pool = self.pool(mcp=FakeMcp(ready=False))
        pool.tick()
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "held")
        self.assertEqual(self.ledger.item(item)["state"], "failed")
        self.assertEqual([r["state"] for r in self.ledger.reservations()], ["active"])

    def test_a_held_slot_is_not_probed_again_on_the_next_tick(self):
        """hold() leaves the reservation active and only changes the slot, so without the 'held' exclusion in
        reservations_to_settle the pool would re-probe every two seconds a slot the operator was told to
        recover, and might eventually release one spec §7 says must wait."""
        self.pool().ensure()
        self.waiting(ISSUE, self.commit("fix"), "interactive")
        pool = self.pool(mcp=FakeMcp(ready=False))
        pool.tick()
        count = lambda: self.ledger.connection.execute("SELECT count(*) FROM audit").fetchone()[0]
        before = count()
        self.assertEqual(pool.tick(), {"settled": 0, "granted": 0, "parked": 0})
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "held")
        self.assertEqual([r["state"] for r in self.ledger.reservations()], ["active"])
        self.assertEqual(count(), before)

    def test_a_slot_is_held_when_the_release_gate_does_not_pass(self):
        """Global constraint: no slot is ever released on a timer. These are the three ways the gate fails."""
        for label, build, break_it in (
            ("not quiescent", lambda: FakeMcp(ready=False), None),
            ("probe raised", lambda: RaisingQuiescence(), None),
            ("token file gone", lambda: FakeMcp(), "token"),
        ):
            with self.subTest(label):
                self.setUp()
                self.pool().ensure()
                item = self.waiting(ISSUE, self.commit("fix"), "batch")
                pool = self.pool(mcp=build())
                pool.tick()
                if break_it == "token":
                    pool.token_path(item).unlink()
                self.finish_worker(item)
                self.assertEqual(pool.tick()["settled"], 0)
                self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "held")
                self.assertEqual([r["state"] for r in self.ledger.reservations()], ["active"])

    def test_a_stop_between_the_grant_and_the_switch_does_not_kill_the_pool_thread(self):
        """resume() raises unless the item is awaiting; a Stop during the multi-minute switch cancels it, and
        an uncaught LedgerError there would take grant(), tick() and the pool thread down with the slot busy
        and the reservation open."""
        self.pool().ensure()
        item = self.waiting(ISSUE, self.commit("fix"), "interactive")
        pool = self.pool(mcp=CancellingMcp(self.ledger, item))
        self.assertEqual(pool.tick()["granted"], 0)
        self.assertEqual(self.ledger.item(item)["state"], "cancelled")
        self.assertEqual([r["state"] for r in self.ledger.reservations()], ["cancelled"])
        self.assertIn(self.ledger.slot("unity_slot:1")["state"], ("switching", "idle_closed"))
        self.assertEqual(pool.tick()["parked"], 1)   # and the slot comes back to the pool by itself

    def test_a_git_stage_failure_is_requeued_once_at_the_tail_and_fails_the_item_the_second_time(self):
        self.pool().ensure()
        first = self.waiting(ISSUE, self.commit("first"), "batch")
        pool = self.pool(mcp=FakeMcp(), worktrees=BrokenCheckout(self.trees))
        pool.tick()
        requeued = [r for r in self.ledger.reservations() if r["state"] == "queued"]
        self.assertEqual([(r["item_id"], r["attempts"]) for r in requeued], [(first, 1)])
        self.assertEqual(self.ledger.item(first)["state"], "awaiting_resource")
        second = self.waiting(OTHER, self.commit("second"), "batch")
        self.assertEqual([r["item_id"] for r in self.ledger.reservations() if r["state"] == "queued"],
                         [first, second])   # re-queued at the tail, but still ahead of a later arrival
        pool.tick()
        self.assertEqual(self.ledger.item(first)["state"], "failed")
        reasons = [row["reason"] for row in self.ledger.connection.execute(
            "SELECT reason FROM audit WHERE item_id=?", (first,))]
        self.assertTrue(any("verification gap" in r for r in reasons), reasons)
        self.assertEqual(len([r for r in self.ledger.reservations() if r["item_id"] == first]), 2)

    def test_a_released_slot_is_parked_back_on_main_when_nothing_is_waiting(self):
        self.pool().ensure()
        item = self.waiting(ISSUE, self.commit("fix"), "batch")
        pool = self.pool(mcp=FakeMcp())
        pool.tick()
        main = self.trees.resolve_commit("Farm-Client")
        self.finish_worker(item, "done")
        # One tick settles, releases and parks: tick() computes all three counts in one call, so asserting
        # parked on a *later* tick would see 0 and the slot already idle.
        self.assertEqual(pool.tick(), {"settled": 1, "granted": 0, "parked": 1})
        slot = self.ledger.slot("unity_slot:1")
        self.assertEqual((slot["state"], slot["parked_commit"]), ("idle_closed", main))
        self.assertEqual(self.trees.head(self.root / "editors" / "slot-1"), main)
```

Three small doubles go beside `FakeMcp` in the same file:

```python
class RaisingQuiescence(FakeMcp):
    def quiescent(self, slot, mode):
        raise RuntimeError("the endpoint did not answer")


class CancellingMcp(FakeMcp):
    """Cancels the item from inside the switch, which is where a Linear Stop lands in production."""
    def __init__(self, ledger, item_id):
        super().__init__()
        self.ledger, self.item_id = ledger, item_id

    def refresh(self, slot):
        super().refresh(slot)
        self.ledger.cancel_reservations(self.item_id, "Linear stop")
        self.ledger.cancel(self.item_id, "Linear stop")


class BrokenCheckout:
    """Everything the real Worktrees does, except that moving the slot always fails at the git stage."""
    def __init__(self, trees):
        self._trees = trees

    def __getattr__(self, name):
        return getattr(self._trees, name)

    def checkout_commit(self, path, commit):
        raise WorktreeError("reference is not a tree")
```

In `tests/test_scheduler.py`, delete `test_awaiting_resource_stays_parked_in_phase_1a` (line 221). Its comment says the behaviour is Phase 1a's on purpose; this task is where it stops being true, and `PoolTests` above replaces it.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k Pool`
Expected: FAIL with `AttributeError: 'SlotPool' object has no attribute 'tick'`.

- [ ] **Step 3: Let a waiting item fail, and let a request be re-queued**

In `agent/ledger.py`, widen the `fail_queued` guard and add the re-queue:

```python
            if row["state"] not in ("queued", "awaiting_resource"):
                raise LedgerError("only a queued or waiting work item can fail before claim")
```

```python
    def requeue_reservation(self, reservation_id, reason):
        """One more chance at the tail of the queue after a retryable failure, never a third."""
        _text(reason, "reason")
        with self._transaction():
            row = self.connection.execute("SELECT * FROM reservations WHERE reservation_id=?",
                                          (reservation_id,)).fetchone()
            if row is None or row["state"] not in ("released", "cancelled"):
                raise LedgerError("only a closed reservation can be re-queued")
            fresh = str(uuid4())
            self.connection.execute(
                """INSERT INTO reservations(reservation_id,item_id,generation,kind,mode,commit_sha,state,
                   attempts,created_at) VALUES(?,?,?,?,?,?,'queued',?,?)""",
                (fresh, row["item_id"], row["generation"], row["kind"], row["mode"], row["commit_sha"],
                 row["attempts"] + 1, self.clock()))
            self._audit(row["item_id"], "reservation", "requeued", details={"reservation_id": fresh,
                                                                            "reason": reason[:200]})
            return fresh
```

- [ ] **Step 4: Write the pool's loop**

In `agent/slots.py`, extend `__init__` with `state_dir=None, owner="pool"` and add:

```python
    def token_path(self, item_id):
        return Path(self.state_dir(item_id)) / "reservation.token"

    def _write_token(self, item_id, reservation):
        """The token goes to a file, never onto a command line: the prompt is written to disk and arguments are
        visible to every process on the host (spec §15)."""
        path = self.token_path(item_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        with os.fdopen(os.open(path, os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600), "w", encoding="utf-8") as handle:
            handle.write(reservation["token"])
        return path

    def _read_token(self, item_id):
        try:
            return self.token_path(item_id).read_text(encoding="utf-8").strip()
        except OSError:
            return None

    def tick(self):
        """The pool thread's whole loop body. Everything slow lives here and nothing here holds a ledger
        transaction across a git command, a subprocess or an MCP call."""
        return {"settled": self.settle(), "granted": self.grant(), "parked": self.park_idle()}

    def grant(self):
        """`granted` counts hand-overs that reached a worker, not acquisitions that were attempted. A
        switch that failed and a Stop that landed mid-switch both give the slot back, so counting them
        would make tick()'s own report disagree with the ledger — and the Stop test asserts zero."""
        granted = 0
        for kind in sorted({entry["kind"] for entry in self.entries.values()}):
            reservation = self.ledger.acquire(kind, owner=self.owner, host=self.host)
            if reservation is None:
                continue
            granted += 1 if self._hand_over(reservation) else 0
        return granted

    def _hand_over(self, reservation):
        """True when the item really has the slot: the switch succeeded, the token is on disk and resume()
        put the item back in the queue. False on every path that gave the slot back."""
        item_id, slot_id = reservation["item_id"], reservation["resource"]
        self.last_observation = None
        try:
            self.switch(slot_id, reservation["commit_sha"], reservation["mode"])
        except SlotError as exc:
            self._switch_failed(reservation, exc)
            return False
        if self.last_observation is not None:
            self.ledger.record_identity(item_id, reservation["reservation_id"], slot_id, self.last_observation)
        self._write_token(item_id, reservation)
        try:
            self.ledger.resume(item_id, f"{slot_id} acquired ({reservation['mode']})")
        except LedgerError:
            # A Stop landed during the multi-minute switch, so the item is already cancelled and resume()
            # refuses it. Uncaught, that LedgerError would come out of grant(), out of tick() and take the
            # pool thread down with the slot busy and the reservation open. Give the slot back instead;
            # park_idle returns it to main on the next pass.
            self.token_path(item_id).unlink(missing_ok=True)
            self.ledger.release(reservation["reservation_id"], reservation["token"], "item cancelled mid-switch")
            return False
        return True

    def _switch_failed(self, reservation, exc):
        reason = str(exc)[:400]
        if exc.stage == "probe":
            # Spec §7: a failing probe holds the slot for the operator's recover command. With one slot there
            # is nowhere to retry, so the item records the gap instead of waiting for a human.
            self.ledger.hold(reservation["reservation_id"], reason)
            self.ledger.fail_queued(reservation["item_id"], f"slot held after a failed probe: {reason}")
            return
        self.ledger.release(reservation["reservation_id"], reservation["token"], reason)
        self.ledger.set_slot_state(reservation["resource"], "idle_closed")
        if exc.stage == "compile":
            # The slot is fine; this commit does not build. Fail the item and leave the slot in the pool.
            self.ledger.fail_queued(reservation["item_id"], f"compile errors at the pinned commit: {reason}")
        elif reservation["attempts"] >= 1:
            self.ledger.fail_queued(reservation["item_id"], f"verification gap: {reason}")
        else:
            self.ledger.requeue_reservation(reservation["reservation_id"], reason)

    def settle(self):
        """A slot is only useful to a running worker. Anything else is probed and then released or held.

        Nothing here is on a timer (global constraint). Three things make the gate fail and all three hold the
        slot: the quiescence check says no, the quiescence check raises, or the token file is gone. A batch
        reservation's quiescence is not a constant — it is the confirmation that no Unity process holds the
        folder — and only once that passes may the stale lock be cleared and the slot checked out, because
        `git checkout --force` plus `git lfs checkout` over a live Editor's Library/ is the corruption slots
        exist to prevent.
        """
        settled = 0
        for reservation in self.ledger.reservations_to_settle():
            slot = self.ledger.slot(reservation["resource"])
            token = self._read_token(reservation["item_id"])
            if token is None:
                self.ledger.hold(reservation["reservation_id"], "reservation token file is missing")
                continue
            try:
                quiet = self.mcp.quiescent(slot, reservation["mode"]) if self.mcp is not None else True
            except Exception as exc:
                quiet = False
                reason = f"quiescence probe raised {type(exc).__name__}"
            else:
                reason = "quiescent" if quiet else "not quiescent"
            if not quiet:
                self.ledger.hold(reservation["reservation_id"], reason)
                continue
            if reservation["mode"] == "batch":
                # The process is confirmed gone by the quiescence check above, so the lock is stale by
                # definition; clear_stale_lock takes the same liveness answer rather than a second guess.
                self.clear_stale_lock(slot["folder"], lambda: False)
            self.ledger.release(reservation["reservation_id"], token, reason)
            self.token_path(reservation["item_id"]).unlink(missing_ok=True)
            self._departing[reservation["resource"]] = reservation["mode"]
            settled += 1
        return settled

    def park_idle(self):
        """After the last release, the slot goes back to main so Library/ tracks main in small steps (spec §7).

        The departing mode comes from `_departing`, which settle() wrote a moment ago, because Ledger.release
        has already overwritten the slot's state to 'switching' and the state that decides idle_open from
        idle_closed is no longer readable from the row.
        """
        parked = 0
        for slot in self.ledger.slots(host=self.host):
            if slot["state"] != "switching" or self.ledger.active_reservation_on(slot["slot_id"]):
                continue
            mode = self._departing.pop(slot["slot_id"], "batch")
            try:
                self.park(slot["slot_id"], mode)
            except SlotError:
                self.ledger.set_slot_state(slot["slot_id"], "held")
                continue
            parked += 1
        return parked

    def close(self):
        if self._owns_ledger:
            self.ledger.close()
```

`self._departing = {}` goes in `__init__` beside the rest. The ledger argument is resolved there too, once, on the thread that will use it:

```python
        self._owns_ledger = callable(ledger) and not isinstance(ledger, Ledger)
        self.ledger = ledger() if self._owns_ledger else ledger
```

Add `import os` and `from .ledger import Ledger, LedgerError` to the module. `Ledger.active_reservation_on(slot_id)` is one more small reader beside `active_reservation`:

```python
    def active_reservation_on(self, slot_id):
        row = self.connection.execute(
            "SELECT * FROM reservations WHERE resource=? AND state IN ('active','cancel_requested')",
            (slot_id,)).fetchone()
        return self._reservation_view(row) if row else None
```

- [ ] **Step 5: Start the pool thread**

In `agent/service.py`, extend `Components` with `pool`, build it in `build`, and give `serve` a third loop:

```python
Components = namedtuple("Components", "config paths api ledger skills worktrees launcher scheduler receiver server pool")
```

```python
    # A factory, not the scheduler's connection: the pool runs on its own thread and two threads on one
    # sqlite3.Connection interleave their BEGIN IMMEDIATE blocks. The receiver already takes one of these.
    pool = SlotPool(lambda: Ledger(paths.ledger, check_same_thread=False),
                    worktrees, [slot_entry(raw) for raw in config.slots], host=config.host,
                    editors_root=paths.editors, state_dir=launcher.state_dir,
                    mcp=UnityIdentity(ROOT / "agent" / "probes" / "editor-readiness.cs.txt"))
```

```python
    def pool_once():
        components.pool.tick()
        stop.wait(2.0)
```

```python
    threads = [threading.Thread(target=guarded("receive", receive_once), daemon=True),
               threading.Thread(target=guarded("schedule", schedule_once), daemon=True),
               threading.Thread(target=guarded("pool", pool_once), daemon=True)]
```

and call `pool.ensure()` once, immediately before the threads start, inside a `try/except SlotError` that prints the failure and leaves the pool empty rather than refusing to serve — a host without a usable slot must still answer Linear. Add `components.pool.close()` to `serve`'s `finally` block beside `components.ledger.close()`, and `from .slots import SlotPool, SlotError, UnityIdentity, slot_entry` to the imports.

`serve`'s `finally` block also gains, **before** `components.pool.close()`:

```python
        for owner in components.launcher.stop_all_unsandboxed():
            print(json.dumps({"event": "batch_killed_on_shutdown", "item": owner}), flush=True)
```

All three threads are daemons, so a shutdown does not wait for the pool thread — and the pool thread is
exactly where a batch Editor is being waited on, for up to `batch_timeout`. Without this line the Editor
survives the service that started it, keeps `Temp/UnityLockfile` and the slot folder open, and the next
`ensure()` after a restart finds a slot that some other Editor appears to hold. It is logged rather than
silent because an operator restarting the service deserves to know a Unity run died with it.

That last behaviour is a one-line guard in front of the whole service's availability, so it gets a test. In `tests/test_service.py`:

```python
    def test_serve_still_starts_when_the_slot_pool_cannot_be_prepared(self):
        components = build(self.config)
        self.addCleanup(components.server.server_close)
        components.pool = SimpleNamespace(ensure=_raise(SlotError("slot-1: still holds git-lfs pointers")),
                                          tick=lambda: {}, close=lambda: None)
        thread = threading.Thread(target=serve, kwargs={"components": components}, daemon=True)
        thread.start()
        self.addCleanup(components.server.shutdown)
        self.assertTrue(self.wait_for_ready(components))
```

- [ ] **Step 6: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k PoolTests -k slot_pool`
Expected: PASS, nine `PoolTests` cases plus the one service case.

- [ ] **Step 7: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 195 tests (nine new in `tests/test_slots.py`, one in `tests/test_service.py`, one Phase 1a test deleted).

```bash
git add agent/ledger.py agent/slots.py agent/service.py tests/test_slots.py tests/test_scheduler.py tests/test_service.py
git commit -m "feat(slots): grant, switch and settle reservations on the pool thread

awaiting_resource items were inert: the scheduler drains only the queued items and
never looked at reservations. The pool now runs beside the receiver and scheduler
threads, because a switch takes minutes while tick() holds its lock and runs every
second. Nothing in the pool holds a ledger transaction across git, a subprocess or
an MCP call.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

