### Task 5: The identity probe proves the Editor loaded the pinned commit

Port `FarmTestAgent/tools/farmqa_unity_identity.py` and `farmqa_identity.py`. Copy the files first, then replace the pieces shown here. Everything not mentioned — the redirect-refusing opener, the empty `ProxyHandler`, the 1 MiB response bound, the `initialize` handshake with `protocolVersion` pinned to `2024-11-05`, the single-matching-id SSE parse, the `_payload` unwrapping — stays verbatim, because it is small, adversarial and already proven against exactly this plugin version.

**Why:** the slot switch moves a folder; only the probe proves that the Editor in front of a worker is that folder, at that commit, in Edit Mode, with the HotUpdate module actually loaded. Without it an interactive run can produce confident evidence about the wrong build, which is worse than no evidence.

**Design:** four changes to the ported code, each because FarmBot is not FarmQA. The endpoint is a constructor argument instead of a hardcoded `9090`, because this Mac's plugin defaults to `8080`. The "exactly one connected instance" rule at `farmqa_identity.py:88-90` becomes "the expected instance id is present", followed by `set_active_instance` and a re-read of `project/info` after selection — the strict rule is baked into four FarmQA call sites and would make a second slot impossible, and would also fail if any other Editor under this user connected to the same server. The expected assembly set stays `{HotUpdate, AOTScripts, Nova.Runtime, MCPForUnity.Editor}` but moves into the probe's arguments **and out of the C# probe**. The copied `editor-readiness.cs.txt` hardcodes the filter (`if (name != "HotUpdate" && name != "AOTScripts" && name != "Nova.Runtime" && name != "MCPForUnity.Editor") continue;`), so passing the set from Python alone would be theatre: the Python side can only compare against what the C# chose to return, and a different project would still need a code change — in the `.cs.txt`. So Step 3 also deletes that `continue` and lets the probe return every loaded assembly, and `collect` does the filtering. That is a two-line change to the copied file and it is what makes the Windows or Android slot genuinely configuration-only. All four assemblies exist in this project today, in `Library/ScriptAssemblies`. `verdict` is no longer the constant `BLOCKED`: the aggregate is `match` only when every check is `match`, and `unknown` is never `match` (`farmqa_request_session.py:138-139`).

**Files:**
- Create: `agent/unity_mcp.py` (from `FarmTestAgent/tools/farmqa_unity_identity.py`)
- Create: `agent/identity.py` (from `FarmTestAgent/tools/farmqa_identity.py`)
- Create: `agent/probes/editor-readiness.cs.txt` (copied from `FarmTestAgent/tests/probes/editor-readiness.cs.txt`)
- Modify: `agent/slots.py` (`UnityIdentity`, the real collaborator the pool's `mcp` argument takes)
- Test: `tests/test_identity.py`

**Interfaces:**
- Consumes: nothing in `agent/`; standard library only.
- Produces:
  - `agent.unity_mcp.UnityMcp(endpoint, timeout=30)` with `read_resource(uri)`, `call_tool(name, arguments)` and `select_instance(instance)`. The constructor raises `ValueError` unless the endpoint is `http`, host exactly `127.0.0.1`, an explicit port, path exactly `/mcp`, and no userinfo, query or fragment.
  - `agent.identity.source_snapshot(repository) -> dict` with `repository`, `commit_sha`, `dirty`, `index_sha256`.
  - `agent.identity.ready(state, instance) -> bool`, the Editor-state gate, unchanged clause for clause.
  - `agent.identity.collect(client, *, repository, instance, expected, probe_source) -> dict` with `checks`, `aggregate`, `observed_at` and the raw samples.
  - `agent.slots.UnityIdentity(probe_path, timeout=120, start_timeout=120, clock=time.time, sleep=time.sleep)`, the pool's `mcp` collaborator in production. The endpoint is **not** a constructor argument: it is read per call from the slot row's `mcp_address`, so one instance serves every slot. It implements the whole surface `SlotPool` and `FakeMcp` share — the probe half (`refresh`, `wait_quiet`, `console_errors_since`, `probe`, `quiescent`) and the Editor life cycle `switch` and `close_editor` drive (`discover_instance`, `start`, `terminate`, `reap_server`).

- [ ] **Step 1: Write the failing tests**

Create `tests/test_identity.py`. The MCP client is tested against a real loopback `http.server` in a thread, which is the house discipline: real sockets, no mocks of the transport.

```python
import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from agent.identity import aggregate, ready
from agent.unity_mcp import UnityMcp


class Handler(BaseHTTPRequestHandler):
    replies = {}
    sse = False

    def log_message(self, *args):
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        method = body.get("method")
        if method == "initialize":
            result = {"protocolVersion": "2024-11-05", "capabilities": {}, "serverInfo": {"name": "u", "version": "1"}}
        elif method == "notifications/initialized":
            self.send_response(202); self.end_headers(); return
        elif method == "resources/read":
            uri = body["params"]["uri"]
            result = {"contents": [{"type": "text", "text": json.dumps(self.replies[uri])}]}
        else:
            result = {"content": [{"type": "text", "text": json.dumps(self.replies.get(method, {}))}]}
        payload = json.dumps({"jsonrpc": "2.0", "id": body["id"], "result": result})
        if self.sse:
            data = f"event: message\ndata: {payload}\n\n".encode()
            self.send_response(200); self.send_header("Content-Type", "text/event-stream")
        else:
            data = payload.encode()
            self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Mcp-Session-Id", "session-1")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


class McpTests(unittest.TestCase):
    def setUp(self):
        Handler.replies = {"mcpforunity://instances": {"instances": [{"id": "slot-1@0123456789abcdef"}]},
                           "mcpforunity://project/info": {"projectRoot": "/e/slot-1", "platform": "StandaloneOSX"}}
        Handler.sse = False
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.addCleanup(self.server.shutdown)
        self.addCleanup(self.server.server_close)  # -W error turns the unclosed socket into a failure
        self.endpoint = f"http://127.0.0.1:{self.server.server_address[1]}/mcp"

    def test_only_a_loopback_mcp_endpoint_is_accepted(self):
        for bad in ("https://127.0.0.1:8080/mcp", "http://10.0.0.5:8080/mcp", "http://127.0.0.1:8080/",
                    "http://user@127.0.0.1:8080/mcp", "http://127.0.0.1:8080/mcp?a=1"):
            with self.assertRaises(ValueError, msg=bad):
                UnityMcp(bad)
        self.assertIsNotNone(UnityMcp(self.endpoint))

    def test_a_resource_reads_the_same_through_json_and_through_one_sse_message(self):
        client = UnityMcp(self.endpoint)
        self.assertEqual(client.read_resource("mcpforunity://instances")["instances"][0]["id"],
                         "slot-1@0123456789abcdef")
        Handler.sse = True
        other = UnityMcp(self.endpoint)
        self.assertEqual(other.read_resource("mcpforunity://project/info")["platform"], "StandaloneOSX")

    def test_an_unlisted_resource_uri_is_refused_before_any_request(self):
        client = UnityMcp(self.endpoint)
        with self.assertRaises(ValueError):
            client.read_resource("mcpforunity://something/else")


def state(**overrides):
    base = {"schema_version": "unity-mcp/editor_state@2", "observed_at_unix_ms": 0,
            "unity": {"instance_id": "slot-1@0123456789abcdef"}, "staleness": {"is_stale": False},
            "advice": {"ready_for_tools": True},
            "play_mode": {"is_playing": False, "is_paused": False, "is_changing": False},
            "compilation": {"is_compiling": False, "is_domain_reload_pending": False},
            "assets": {"is_updating": False}, "tests": {"is_running": False}}
    base.update(overrides)
    return base


class ReadyTests(unittest.TestCase):
    def setUp(self):
        self.now_ms = 1_700_000_000_000

    def test_a_fresh_idle_editor_of_the_expected_instance_is_ready(self):
        self.assertTrue(ready(state(observed_at_unix_ms=self.now_ms - 500), "slot-1@0123456789abcdef",
                              now_ms=self.now_ms))

    def test_a_stale_a_future_a_playing_and_a_compiling_editor_are_all_refused(self):
        instance = "slot-1@0123456789abcdef"
        self.assertFalse(ready(state(observed_at_unix_ms=self.now_ms - 10_001), instance, now_ms=self.now_ms))
        self.assertFalse(ready(state(observed_at_unix_ms=self.now_ms + 1), instance, now_ms=self.now_ms))
        self.assertFalse(ready(state(observed_at_unix_ms=self.now_ms,
                                     play_mode={"is_playing": True, "is_paused": False, "is_changing": False}),
                               instance, now_ms=self.now_ms))
        self.assertFalse(ready(state(observed_at_unix_ms=self.now_ms,
                                     compilation={"is_compiling": True, "is_domain_reload_pending": False}),
                               instance, now_ms=self.now_ms))
        self.assertFalse(ready(state(observed_at_unix_ms=self.now_ms), "other@ffffffffffffffff",
                               now_ms=self.now_ms))

    def test_the_aggregate_is_match_only_when_every_check_matches_and_unknown_is_never_match(self):
        self.assertEqual(aggregate({"a": "match", "b": "match"}), "match")
        self.assertEqual(aggregate({"a": "match", "b": "unknown"}), "unknown")
        self.assertEqual(aggregate({"a": "mismatch", "b": "unknown"}), "mismatch")

    def test_quiet_ignores_the_instance_and_the_clock_but_not_the_four_busy_flags(self):
        """The refresh wait cannot compare instances — hearing from the instance is what it is waiting for —
        and cannot bound staleness, because a compiling Editor stops publishing fresh samples."""
        self.assertTrue(quiet(state(observed_at_unix_ms=0, unity={"instance_id": "anything"})))
        for busy in ({"compilation": {"is_compiling": True, "is_domain_reload_pending": False}},
                     {"compilation": {"is_compiling": False, "is_domain_reload_pending": True}},
                     {"assets": {"is_updating": True}},
                     {"tests": {"is_running": True}}):
            self.assertFalse(quiet(state(**busy)), busy)
```

with `quiet` added to the `from agent.identity import ...` line.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k McpTests -k ReadyTests`
Expected: FAIL with `ModuleNotFoundError: No module named 'agent.unity_mcp'`.

- [ ] **Step 3: Copy the client and make its endpoint configuration**

```bash
cp /Users/elendil/WorkSpaces/Farm/FarmTestAgent/tools/farmqa_unity_identity.py agent/unity_mcp.py
mkdir -p agent/probes
cp /Users/elendil/WorkSpaces/Farm/FarmTestAgent/tests/probes/editor-readiness.cs.txt agent/probes/editor-readiness.cs.txt
```

Then in `agent/unity_mcp.py`: rename the class to `UnityMcp`, replace the module docstring with `"""Loopback JSON-RPC client for MCP for Unity (spec §7). Ported from FarmTestAgent/tools/farmqa_unity_identity.py."""`, delete the `9090` default so the endpoint is a required argument, and replace the instance-selection helper with:

```python
    RESOURCES = ("mcpforunity://custom-tools", "mcpforunity://instances", "mcpforunity://project/info",
                 "mcpforunity://editor/state")

    def select_instance(self, instance):
        """HTTP selection is per MCP session (the Mcp-Session-Id header), so each worker pins its own slot.
        UNITY_MCP_DEFAULT_INSTANCE is a stdio-only variable and has no effect on this path."""
        listed = [entry.get("id") for entry in self.read_resource("mcpforunity://instances").get("instances", [])]
        if instance not in listed:
            raise ValueError(f"instance {instance} is not connected; connected: {listed}")
        return self.call_tool("set_active_instance", {"instance": instance})
```

- [ ] **Step 4: Copy the identity module and open its constants**

```bash
cp /Users/elendil/WorkSpaces/Farm/FarmTestAgent/tools/farmqa_identity.py agent/identity.py
```

Also open the C# probe's assembly filter, so the expected set really is configuration. In `agent/probes/editor-readiness.cs.txt`, delete the two lines

```csharp
    if (name != "HotUpdate" && name != "AOTScripts" && name != "Nova.Runtime" && name != "MCPForUnity.Editor")
        continue;
```

so the probe returns every loaded assembly and `collect` filters in Python against `expected["assemblies"]`. Leave everything else in the file verbatim, including the `dataPath` field, which Task 0 Step 5 reads.

Then in `agent/identity.py`: keep `source_snapshot`, `ready`, `safe_text` and `project_matches` as they are, except that `ready` takes `now_ms=None` (defaulting to the wall clock) so the gate is testable without sleeping. Replace the observation write, which targeted `controller_identity_observations` directly, with a plain return value — `Ledger.record_identity` owns that table now. Replace the hardcoded verdict with:

```python
def aggregate(checks):
    """match only when every check is match; unknown is never match (farmqa_request_session.py:138-139)."""
    values = set(checks.values())
    if "mismatch" in values:
        return "mismatch"
    if values - {"match"}:
        return "unknown"
    return "match"
```

and make `collect(client, *, repository, instance, expected, probe_source)` take the expected assembly set from `expected["assemblies"]` instead of the module-level `{'HotUpdate','AOTScripts','Nova.Runtime','MCPForUnity.Editor'}`, and the build target from `expected["build_target"]` instead of `StandaloneWindows64`. Keep the order of operations exactly: source snapshot, read `custom-tools`, read `instances`, select, read `editor/state`, `ready()` gate, read `project/info`, run the probe, re-read `editor/state`, second source snapshot. Keep `source_stable` — the before-and-after comparison is what makes "the slot really was on that commit for the whole run" checkable. Keep the rule that no SQLite transaction is ever held across an MCP call.

- [ ] **Step 5: Give the pool its real collaborator**

At the end of `agent/slots.py`:

```python
class UnityIdentity:
    """The pool's `mcp` collaborator in production: one MCP session per call, pinned to the slot's instance,
    plus the Editor's own life cycle, because starting and closing it is what the state table in spec §7
    requires and nothing else in FarmBot does it."""

    def __init__(self, probe_path, timeout=120, start_timeout=120, clock=time.time, sleep=time.sleep):
        self.probe_path = Path(probe_path)
        self.timeout = timeout
        # Task 0 Step 5 measured cold Editor start to a usable MCP endpoint at 16 s. 120 is generous headroom
        # over a measured number; the 600 an earlier draft carried was a guess at an unmeasured one.
        self.start_timeout = start_timeout
        self.clock = clock
        self.sleep = sleep

    def _client(self, slot):
        from .unity_mcp import UnityMcp
        client = UnityMcp(slot["mcp_address"], timeout=self.timeout)
        if slot.get("instance"):
            client.select_instance(slot["instance"])
        return client

    def discover_instance(self, slot):
        """The instance id for this folder, read from the live server rather than assumed.

        Nothing else writes slots.instance, and without it the whole interactive path is dead: collect()
        passes the instance to ready(), which compares it against unity.instance_id, so a NULL instance makes
        ready() False, the aggregate unknown and every interactive switch a probe-stage hold. The plugin
        derives the id as SHA1(Application.dataPath) truncated to 16 hex characters
        (Editor/Helpers/ProjectIdentityUtility.cs) and Task 0 Step 5 settled the exact input:
        sha1("<folder>/Assets")[:16] — no trailing slash — reproduced the live slot-1@54462c1bfe7b5261
        exactly, while sha1("<folder>") and sha1("<folder>/Assets/") did not. It is still **read, not
        recomputed**: the rule is known, but the live value is what the worker must address, and a folder
        that is moved or symlinked would make a recomputed hash confidently wrong.
        """
        from .unity_mcp import UnityMcp
        folder = Path(slot["folder"]).resolve()
        client = UnityMcp(slot["mcp_address"], timeout=self.timeout)
        for entry in client.read_resource("mcpforunity://instances").get("instances", []):
            for key in ("projectPath", "dataPath", "path"):
                value = entry.get(key)
                if value and Path(value).resolve() in (folder, folder / "Assets"):
                    return entry.get("id")
        raise SlotError(f"no connected Editor instance reports {folder}", stage="editor")

    def start(self, slot, entry):
        """Start the Editor for an interactive run and wait until the MCP server reports this folder.

        The endpoint is served by a uvx process, not by the Editor itself, but Task 0 Step 5 established that
        the Editor **starts it** — with --project-scoped-tools and a per-slot pidfile — so no operator action
        and no separate agent is needed. What must still read as an editor-stage failure rather than an
        identity mismatch is the other direction: a server left behind by a previous Editor still answers on
        that address, which is why close_editor reaps it and why the message below names both possibilities.
        """
        from .unity import editor_path
        command = [str(editor_path(slot["folder"], override=entry.get("unity"))), "-projectPath",
                   str(slot["folder"]), "-logFile", str(Path(slot["folder"]) / "Logs" / "farmbot-editor.log")]
        subprocess.Popen(command, start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = self.clock() + self.start_timeout
        while True:
            try:
                return self.discover_instance(slot)
            except Exception:
                if self.clock() >= deadline:
                    raise SlotError(f"{slot['slot_id']}: no MCP instance after {self.start_timeout}s "
                                    f"(measured cold start is 16s); either the Editor did not come up, or a "
                                    f"stale server from a previous Editor still holds {slot['mcp_address']}",
                                    stage="editor")
                self.sleep(5.0)

    def terminate(self, slot, timeout):
        """Task 0 Step 5 settled this: `EditorApplication.Exit(0)` through execute_code returns "exiting" and
        the Editor keeps running, so it is not used at all. SIGTERM the pid that holds the folder — measured
        gone in 1 s — and confirm it. Removing Temp/UnityLockfile is the pool's job, not this method's,
        because Unity leaves it behind even here."""
        from .unity import editor_holds_project
        pid = editor_holds_project(slot["folder"])
        if pid is None:
            return
        os.kill(pid, signal.SIGTERM)
        deadline = self.clock() + timeout
        while editor_holds_project(slot["folder"]) is not None:
            if self.clock() >= deadline:
                raise SlotError(f"Unity pid {pid} still holds {slot['folder']} {timeout}s after SIGTERM",
                                stage="editor")
            self.sleep(1.0)

    def reap_server(self, slot):
        """The uvx MCP server is a child of the Editor but outlives it: after the kill it still held port
        8080 and answered HTTP 200 (Task 0 Step 5). Its pid is in the slot's own RunState pidfile, which is
        also why one host can eventually run two slots. A missing or stale pidfile is not an error.

        The pidfile's name is **derived from the port**, not hardcoded: the spike saw
        `--pidfile <slot>/Library/MCPForUnity/RunState/mcp_http_8080.pid` beside
        `--http-url http://127.0.0.1:8080`, and `mcp_address` is a configuration key (DEFAULTS, Task 3). A
        second slot on another port would otherwise never be reaped, and a stale server holding that port
        is exactly what this method exists to prevent."""
        port = urllib.parse.urlsplit(slot["mcp_address"]).port or 8080
        pidfile = (Path(slot["folder"]) / "Library" / "MCPForUnity" / "RunState"
                   / f"mcp_http_{port}.pid")
        try:
            pid = int(pidfile.read_text(encoding="utf-8").strip())
        except (OSError, ValueError):
            return
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        pidfile.unlink(missing_ok=True)

    def refresh(self, slot):
        self._client(slot).call_tool("refresh_unity", {})

    def wait_quiet(self, slot, timeout):
        """One sample of editor/state. The pool's wait_for_quiet owns the loop and the deadline; this raises
        TimeoutError when the Editor is still compiling, reloading, importing or running tests."""
        from .identity import quiet
        if not quiet(self._client(slot).read_resource("mcpforunity://editor/state")):
            raise TimeoutError("editor is not quiet")

    def console_errors_since(self, slot, marker):
        """spec §7's 'zero Console errors'. Reads the Editor's log entries and returns the error lines."""
        result = self._client(slot).call_tool("read_console", {"types": ["error"], "count": 50})
        return [line for line in (result or {}).get("lines", []) if "error CS" in line or "Exception" in line]

    def probe(self, slot, target):
        from .identity import collect
        client = self._client(slot)
        return collect(client, repository=target["repository"], instance=slot.get("instance"),
                       expected={"build_target": target.get("build_target"),
                                 "commit_sha": target["commit_sha"],
                                 "assemblies": ("HotUpdate", "AOTScripts", "Nova.Runtime", "MCPForUnity.Editor")},
                       probe_source=self.probe_path.read_text(encoding="utf-8"))

    def quiescent(self, slot, mode):
        """Spec §7's release predicate.

        In interactive mode: the Editor is back in Edit Mode, nothing is compiling, importing or running
        tests, and the state sample is fresh. In batch mode it is **not** a constant True — the batch release
        is defined as the Editor process being gone and its results file written, and returning True
        regardless would let park_idle run `git checkout --force` and `git lfs checkout` over a folder that
        still held Temp/UnityLockfile and a half-written Library/. That is precisely the corruption slots
        exist to avoid, and it would read as a project problem rather than a pool bug.
        """
        from .identity import ready
        from .unity import editor_holds_project
        if mode == "batch":
            # A live Unity on this folder holds the slot; a dead one leaves only a stale lock, which
            # SlotPool.settle clears through clear_stale_lock before anything checks the folder out.
            return not editor_holds_project(slot["folder"])
        state = self._client(slot).read_resource("mcpforunity://editor/state")
        return ready(state, slot.get("instance"))
```

One small addition comes with it. `quiet(state)` is a new two-line helper in `agent/identity.py` beside `ready`: the same four clauses (`compilation.is_compiling`, `compilation.is_domain_reload_pending`, `assets.is_updating`, `tests.is_running`) with neither the instance comparison nor the staleness bound, because during a refresh the instance is what we are waiting to hear from; `ready` keeps both. `agent.unity.editor_holds_project` needs nothing here — Task 4 already added it, because `SlotPool.editor_is_open` asks it the same question `terminate` and `quiescent` do. `import os`, `import signal` and `import urllib.parse` go at the top of `agent/slots.py` for `terminate` and `reap_server`.

- [ ] **Step 6: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k McpTests -k ReadyTests`
Expected: PASS, seven tests.

- [ ] **Step 7: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 186 tests (+7).

```bash
git add agent/unity_mcp.py agent/identity.py agent/probes/editor-readiness.cs.txt agent/slots.py tests/test_identity.py
git commit -m "feat(identity): port the FarmQA Editor identity probe

The loopback JSON-RPC client, the editor_state@2 readiness gate and the source
snapshot come over unchanged. Four things open up: the endpoint is configuration
rather than port 9090, the expected instance must be present rather than alone, the
expected assembly set moves out of the C# probe and into the probe's arguments, and
the verdict is an aggregate over the checks rather than a constant.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

