# Task 3 report — Slot 1 exists as a detached worktree with real binaries

Branch `phase1b-unity-slots`, on top of 52e8ca6.

## What I implemented

**`agent/worktrees.py`**
- `_git(*args, cwd, env=GIT_ENV, timeout=600)` — the environment is now an argument, defaulting to today's
  pointer-preserving map, so no existing call site changes.
- `SLOT_ENV = {"GIT_TERMINAL_PROMPT": "0"}` (smudge on) and `LFS_POINTER = b"version https://git-lfs"`.
- `add_slot(repo, path, commit)` — refuses anything but a full 40-hex commit, creates the detached worktree
  only when the folder is absent, then materializes LFS and marks the generated files, both ways.
- `checkout_commit(path, commit)`, `materialize(path)`, `skip_generated(path)`, `slot_clean(path)`,
  `pointers_remain(path)`, and the `GENERATED_PER_FOLDER = (".vscode/settings.json",)` class attribute.
  `materialize` separates a credentials failure from a reachability failure in its message.

**`agent/config.py`** — `Paths.editors = Path(config.local_root) / "editors"`.

**`agent/slots.py`** (new) — `DEFAULTS`, `SlotError`, `slot_entry(raw)`, `SlotPool.__init__`, `SlotPool.folder`,
`SlotPool.ensure`. The constructor is Task 3's only: `(ledger, worktrees, entries, *, host, editors_root,
unity=None, mcp=None, clock=time.time)`. No `sleep` and no `editor_scan` — those belong to Task 4.

**`docs/superpowers/specs/2026-09-17-farm-linear-agent-design.md`** §7 — the "Slot 1 is FarmQA's existing
isolated client copy on the Windows host" sentence replaced with the brief's amendment verbatim.

## Tests

`tests/test_worktrees.py` (the module `git()` helper gained `allow_failure=False`):
- `test_a_slot_worktree_is_detached_at_the_commit_and_lives_where_it_is_told`
- `test_slot_git_runs_without_the_pointer_preserving_environment`

`tests/test_slots.py` (new — `SlotFixture`, `EnsureTests`):
- `test_ensure_registers_the_slot_and_creates_its_folder_parked_on_main`
- `test_ensure_is_idempotent_and_never_disturbs_a_busy_slot`
- `test_a_restart_parks_the_slot_on_the_commit_its_folder_is_really_at`  *(added — see defect 6)*
- `test_a_slot_whose_binaries_are_still_pointers_is_refused_by_name`
- `test_a_git_failure_in_any_part_of_slot_creation_names_the_slot`  *(added — see defect 7)*

## Commands and output

Failing first (Step 2), before any source existed:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v -k slot
ImportError: Failed to import test module: test_slots
  ModuleNotFoundError: No module named 'agent.slots'
AttributeError: 'Worktrees' object has no attribute 'add_slot'     (x2, both new worktree tests)
Ran 9 tests in 0.479s
FAILED (errors=3)
```

Selection after the implementation (Step 7):

```
$ python3 -W error -m unittest discover -s tests -v -k slot
Ran 13 tests in 3.508s
OK
```

Whole suite (Step 8):

```
$ python3 -W error -m unittest discover -s tests
Ran 172 tests in 14.475s
OK
```

Baseline before this task was **165**; the suite is now **172** (+7), green and warning-free under `-W error`.

### Mutation checks (all run with `-B` / `PYTHONDONTWRITEBYTECODE=1`)

| mutation | result |
|---|---|
| drop `skip_generated(path)` from `add_slot` | FAILED (1) |
| slot `worktree add` uses `GIT_ENV` instead of `SLOT_ENV` | FAILED (1) |
| `ensure` parks on the resolved head instead of the folder's head | FAILED (1) |
| remove the `pointers_remain` refusal | FAILED (1) |
| pass a `Path` (not `str`) to `ledger.ensure_slot` | FAILED (7 errors) |
| move `pointers_remain` back outside the `WorktreeError` guard | FAILED (1) |
| restored source | OK |

## The three known brief defects

All three were **already corrected in the on-disk brief** when I read it; I verified each and kept the
corrected form rather than reintroducing the defect.

1. **Fixture passing `sleep=` / `editor_scan=`.** The on-disk `SlotFixture.pool()` passes only
   `ledger, worktrees, [entry], host=, editors_root=, clock=`, plus `**kwargs`. I copied it as-is and
   implemented the Task 3 constructor to match. Task 4's `sleep`/`editor_scan`/`editor_pid` are **not**
   present in `SlotPool.__init__`, per your ruling. `advance()` is kept in the fixture (unused today) because
   Task 4 wires it to the injected `sleep`; it costs nothing and its docstring says so.
2. **"three parts" vs four.** The on-disk brief says "four parts" in both the Design paragraph (line 9) and
   the `SlotPool.ensure` contract (line 29). Consistent; nothing to change.
3. **The false Global Constraint comment.** The on-disk comment in `pool()` is about Task 4's constructor and
   `TypeError`, not about shelling out to git. Correct as written; the tests here do shell out to real `git`
   and real `git-lfs`, which is the established pattern.

## Other things in the brief that were wrong

4. **`git ls-files -v` tags skip-worktree `S`, not `h`** (defect I found; the brief's assertion would have
   failed on every machine). Verified against git 2.54.0 (Apple Git-157): after
   `git update-index --skip-worktree`, `git ls-files -v .vscode/settings.json` prints
   `S .vscode/settings.json`. The lowercase letters are the *assume-unchanged* (`-v`) and *fsmonitor-clean*
   (`-f`) bits, which are different index bits this task never sets. I changed the assertion to
   `assertIn("S .vscode/settings.json", ...)` and replaced the brief's comment with one that says which bit
   each letter is.
5. **`SlotPool.ensure` passing a `Path` as `folder` to `Ledger.ensure_slot` cannot work.** `Ledger.ensure_slot`
   runs `_text(folder, "folder")` *before* its `str(folder)` in the INSERT, and `_text` refuses a non-`str`
   with `LedgerError: folder must be a nonempty string`. The brief's `folder=folder` would have made every
   `EnsureTests` case raise. I pass `folder=str(folder)`; the mutation table above shows reverting it breaks
   7 tests.
6. **`ensure` would have recorded a `parked_commit` the folder is not on.** `add_slot` deliberately does not
   move a folder that already exists (a restart must not cost a Unity reimport), but the brief then wrote
   `set_slot_state(..., parked_commit=commit)` with `commit` being the *freshly resolved origin head*. On any
   restart after origin moved, the ledger would claim the slot is parked at a commit its worktree has never
   seen — and Task 4's switch, which will compare the wanted commit to `parked_commit`, would skip the
   checkout it actually needs. I read the parked commit back from the folder with `Worktrees.head(folder)`.
   For a fresh slot that is identical to `commit`, so the brief's own first test is unchanged. Pinned by the
   new `test_a_restart_parks_the_slot_on_the_commit_its_folder_is_really_at`.
7. **The `SlotError` contract leaked a `WorktreeError` from part three.** The brief calls `pointers_remain`
   *outside* the `except WorktreeError` guard, so a git-lfs failure in the sampled check would escape
   `ensure()` as a bare `WorktreeError` naming neither the slot nor the folder, contradicting the contract
   ("Raises `SlotError` ... naming which of the four parts failed"). I moved the call inside the guard; the
   pointer *refusal* still happens after it, so the "still holds git-lfs pointer files" message is unchanged.
   Pinned by `test_a_git_failure_in_any_part_of_slot_creation_names_the_slot`.
8. **Step 2's and Step 7's predicted selection sizes are wrong.** `-k slot` matches 6 pre-existing tests
   today (one in `test_cli.py`, five in `test_ledger.py`), not 1. The selection is 13, not 6.
9. **Step 8's expected total is wrong.** The brief says "OK, 164 tests (+5)". The baseline is 165 and the
   result is 172.

## Self-review findings (things I chose *not* to change)

- **`ensure` fetches from origin on every service start, even when every slot folder already exists.**
  `resolve_commit` clones-if-needed and always fetches, so an unreachable origin makes `ensure()` raise
  `SlotError` and the service refuses to start although the slots on disk are perfectly usable. It could call
  `resolve_commit` only when the folder is fresh. I left the brief's behaviour: a fetch at service start is
  probably wanted so the pool has current refs, and changing it is a design decision above this task.
- **A host without `git-lfs` gets pointer files silently.** `materialize` returns "git-lfs is not installed"
  and `pointers_remain` returns `False`, so the guard cannot fire on such a host. That is unavoidable without
  git-lfs, and it is what makes the fixture's LFS-free origin a passing case, but it means the Windows host
  must have git-lfs on PATH or slot creation will "succeed" into a broken import. Worth an operator item.
- **`fresh or record["state"] == "idle_closed"`** — `fresh` is redundant, since `ensure_slot` inserts a new
  slot as `idle_closed`. Harmless; kept as the brief wrote it.
- **`pointers_remain` samples the first 20 names**, which `git lfs ls-files` returns in a stable order, so the
  same 20 files are checked every time. That is the brief's "sampled check" by design.
- **`park_idle` (carried note from Task 2's review).** Task 3 does not create `park_idle`, so there was no
  shape to give it. The `sqlite3.IntegrityError`-instead-of-`LedgerError` surfacing when a slot is freed while
  a reservation is still active remains open for whichever task adds `park_idle` (Task 4/6). I did not touch
  `agent/ledger.py`.
- **`.local/editors/slot-1` was not touched.** Verified read-only afterwards: still detached at
  `7d886c72ea3f49fce98b20d7ef19636bd7eabf50`, and `git status --porcelain=v1 --untracked-files=no` is empty.
  Note for the operator: that folder predates this code, so its `.vscode/settings.json` does not carry the
  skip-worktree bit yet — the first `SlotPool.ensure()` on this host will set it, because `add_slot` runs
  `skip_generated` on the existing-folder path too. No test opens, reads or writes that folder; every test
  builds its own throwaway origin, bare clone and slot in a `TemporaryDirectory`.
- No third-party imports; `agent/slots.py` imports only `pathlib`, `time` and `.worktrees`.

---

# Fix round 1 — three Important review findings

Applied on top of 3eca690. Suite: **165 baseline → 172 at 3eca690 → 173 now** (one test added; two strengthened
in place). Green and warning-free.

## Finding 1 — the busy-slot invariant was untested

**Changed:** `tests/test_slots.py`, `test_ensure_is_idempotent_and_never_disturbs_a_busy_slot` strengthened in
place rather than duplicated. The second `ensure()` of each subtest now runs against an `Untouchable`
`Worktrees` spy whose `resolve_commit` and `add_slot` both raise `AssertionError`. The unchanged-state
assertion is kept, and the docstring now says why it is not sufficient on its own. No source change — the
guard was correct, only undefended.

**Covering test:** `test_slots.EnsureTests.test_ensure_is_idempotent_and_never_disturbs_a_busy_slot`
(4 subtests: `interactive_busy`, `batch_busy`, `switching`, `held`).

**Mutation — the reviewer's own:** deleting `if record["state"] in self.BUSY: … continue` from
`agent/slots.py`:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k slot
Ran 14 tests in 3.644s
FAILED (failures=4)
```

One failure per busy state, where the reviewer's run was `6 tests, OK`.

## Finding 2 — `SLOT_ENV` could not unset an ambient `GIT_LFS_SKIP_SMUDGE`

**Changed:** `agent/worktrees.py` — `SLOT_ENV = {"GIT_TERMINAL_PROMPT": "0", "GIT_LFS_SKIP_SMUDGE": "0"}`,
with a comment saying the `"0"` is explicit and not an omission, and naming the shell that built this host's
first slot as the reason. `tests/test_worktrees.py` — the assertion is now `{"0"}`, not `{None}`, so the test
states the guarantee instead of the absence.

**Covering test:** `test_worktrees.WorktreeTests.test_slot_git_runs_without_the_pointer_preserving_environment`.

**Mutation** — `SLOT_ENV` back to omitting the key:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k slot
Ran 14 tests in 3.649s
FAILED (failures=1)
```

**Empirical check that the guarantee now survives the operator's shell** — the whole suite under exactly the
export that caused the finding:

```
$ GIT_LFS_SKIP_SMUDGE=1 python3 -B -W error -m unittest discover -s tests
Ran 173 tests in 14.632s
OK
```

Before the fix this run would have failed that test, because the merged environment would have carried `"1"`.

## Finding 3 — the credentials/reachability classification never fired on a fresh host

**Changed:** `agent/worktrees.py` — the classification is factored into module-level `CREDENTIAL_FAILURE`,
`TRANSFER_FAILURE` and `_transfer_kind(exc)`, and `add_slot` now wraps its `git worktree add` with it, since
with smudge on that is where the LFS download happens. `materialize` calls the same helper
(`_transfer_kind(exc) or "reachability"`), unchanged in behaviour: every way `git lfs fetch` fails is a
transfer, so it is never left unlabelled.

One deliberate difference from "the same classification": `_transfer_kind` can return `None`, and `add_slot`
re-raises untouched in that case. `git lfs fetch` only ever fails as a transfer, but `git worktree add` also
fails for reasons that are neither — a bad reference, a path already registered — and labelling those
`(reachability)` would send the operator to the network for a local problem. The third outcome is asserted.

**Covering test:** `test_worktrees.WorktreeTests.test_a_slot_that_cannot_be_built_tells_credentials_from_reachability`
(subtests `credentials` and `reachability`, plus the unlabelled `fatal: invalid reference` case).

**Mutations:**

| mutation | result |
|---|---|
| `add_slot` re-raises without classifying | `Ran 14 … FAILED (failures=2)` |
| `_transfer_kind` always returns `"reachability"` | `Ran 14 … FAILED (failures=1)` |
| restored | `Ran 14 … OK` |

## Final verification

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k slot
Ran 14 tests in 3.646s
OK

$ python3 -W error -m unittest discover -s tests
Ran 173 tests in 14.615s
OK
```

Deferred items were not touched: `checkout_commit`, `Paths.editors`, `slot_entry`'s untested `SlotError`
branches, the four-parts test covering only part three, the stale `parked_commit` on an `idle_open` record,
and the spec amendment's line width. `.local/editors/slot-1` was not read or written by any test or by me.
