### Task 2: The ledger holds slots and reservations

Port `FarmTestAgent/tools/farmqa_controller.py`, reshaped around FarmBot's work items. Copy the state set, the partial unique index, the hashed owner token and the transition rules; drop `event_key`, `organization_id`, `session_id` and the receiver-table validation, because FarmBot has work items with a lifecycle instead. Everything not mentioned here has no counterpart and is not ported.

**Why:** `await_resource` and `resume` have existed since Plan 1a and nothing drives them, so an `awaiting_resource` item is inert: `queue()` selects `state='queued' AND worker_pid IS NULL`, and `tests/test_scheduler.py:221` asserts that as intended 1a behaviour. The reservation row is the thing that makes the wait finite, and the unique index is the thing that makes "one worker at a time on one Editor folder" true across processes rather than by convention.

**Decision this task encodes:** three of them. First, FIFO is `ORDER BY sequence`, arrival order, not the `priority, created_at, id` order `queue()` uses — a late high-priority item must not jump ahead of one that already waited, and criterion 3's "two items serialize" is only assertable on a deterministic order. Second, the unique index is on `resource`, not on FarmQA's constant `(1)`, so a second slot needs no schema change **and no change to `acquire`**: there is deliberately no kind-wide pre-check, because one would be a semantic restriction rather than an optimisation — it would refuse to grant slot 2 while slot 1 was busy, and it would starve one host while another host's reservation was active. The free-slot query is the whole gate, and a busy slot is simply not free. The table CHECK that forbids an `active` row without a `resource` is what makes the index binding, because SQLite treats NULLs as distinct. Third, an item may hold at most one open reservation, enforced by `one_open_reservation_per_item`, so a worker that wants a different mode must release the slot it holds first.

**Files:**
- Modify: `agent/ledger.py` (schema block, `await_resource`, `cancel`, new reservation and slot methods)
- Test: `tests/test_ledger.py`

**Interfaces:**
- Consumes: `Ledger._transaction()` (`BEGIN IMMEDIATE`), `_hash_token`, `_audit`, `_set_state`, `_owned`, and `await_resource(item_id, token, resource, mode)` as it exists.
- Produces:
  - `Ledger.ensure_slot(slot_id, *, kind, host, folder, instance=None, mcp_address=None, account=None) -> dict`, an upsert that never clears a discovered `instance` with `None`.
  - `Ledger.slots(kind=None, host=None) -> list[dict]`, `Ledger.slot(slot_id) -> dict | None`.
  - `Ledger.set_slot_state(slot_id, state, *, parked_commit=..., instance=..., last_switch_at=...) -> dict`. States: `idle_closed`, `idle_open`, `switching`, `interactive_busy`, `batch_busy`, `held`.
  - `Ledger.await_resource(item_id, token, resource, mode)` unchanged in signature; it now also inserts the `queued` reservation in the same transaction, copying the item's pinned `commit_sha` and `generation`. It raises `LedgerError` when the item has no pinned commit or already holds an open reservation.
  - `Ledger.acquire(kind, *, owner, host) -> dict | None` returning `{reservation_id, token, resource, item_id, mode, commit_sha, folder}`. The raw token exists exactly once, as in `claim`.
  - `Ledger.reservation(reservation_id) -> dict | None` (token-free), `Ledger.reservations(states=None) -> list[dict]`, `Ledger.active_reservation(item_id) -> dict | None`, `Ledger.reservations_to_settle() -> list[dict]`.
  - `Ledger.release(reservation_id, token, reason) -> str`, returning `"released"` or `"cancelled"`; `cancel_requested` resolves to `cancelled`, `active` to `released`, and an already-terminal reservation returns its state unchanged.
  - `Ledger.hold(reservation_id, reason) -> dict` — the reservation stays open, the slot becomes `held`.
  - `Ledger.recover_slot(slot_id, reason) -> dict` — the operator's way out of `held`: any open reservation on that slot is force-released with the reason, the slot becomes `idle_closed` and its `parked_commit` is cleared to NULL, because after a recovery the ledger no longer knows what commit the folder is on.
  - `Ledger.cancel_reservations(item_id, reason) -> list[dict]` — `queued` → `cancelled`, `active` → `cancel_requested`, in one statement.
  - `Ledger.record_identity(item_id, reservation_id, slot_id, result) -> str`, the observation id.

- [ ] **Step 1: Write the failing tests**

Add a new class at the end of `tests/test_ledger.py`. The existing `LedgerTests.setUp` seeds an issue and a session and is reused through a small helper; this class needs two items on two issues, so it builds its own.

```python
class ReservationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.now = 1000.0
        self.ledger = Ledger(Path(self.tmp.name) / "l.sqlite3", clock=lambda: self.now, lease_seconds=60)
        self.addCleanup(self.ledger.close)
        self.ledger.ensure_slot("unity_slot:1", kind="unity_slot", host="mac", folder="/e/slot-1")

    def item(self, issue_id, commit, priority=2):
        # The helper's keyword is `id`, not `issue_id`: tests/test_ledger.py defines `def issue(id=ISSUE,
        # **changes)`, so issue(issue_id=OTHER) would leave the row on ISSUE and the create would then fail
        # with "unknown issue". The two items must be on two issue rows because create_work_item refuses a
        # second active item on one issue.
        self.ledger.observe_issue(issue(id=issue_id, priority=priority))
        session = f"session-{issue_id}"
        self.ledger.ensure_session(session, issue_id, True)
        target = {"repository": "Farm-Client", "requested_ref": "main", "commit_sha": commit,
                  "server_environment": "公共测试服", "selected_at": SELECTED_AT}
        return self.ledger.create_work_item(issue_id=issue_id, session_id=session, skill="fix", target=target)

    def waiting(self, issue_id, commit, mode, priority=2):
        item = self.item(issue_id, commit, priority=priority)
        token = self.ledger.claim(item["id"], worker_id="w")["token"]
        self.ledger.await_resource(item["id"], token, "unity_slot", mode)
        return item["id"]

    def test_two_requests_are_granted_in_arrival_order_not_priority_order(self):
        # The second issue is *more* urgent, so an implementation that ordered by priority would grant it
        # first and this test would fail. With both at the same priority the assertion proves nothing.
        first = self.waiting(ISSUE, "a" * 40, "batch")
        second = self.waiting(OTHER, "b" * 40, "interactive", priority=1)
        granted = self.ledger.acquire("unity_slot", owner="pool", host="mac")
        self.assertEqual((granted["item_id"], granted["mode"], granted["commit_sha"]), (first, "batch", "a" * 40))
        self.assertIsNone(self.ledger.acquire("unity_slot", owner="pool", host="mac"))
        self.assertEqual(self.ledger.release(granted["reservation_id"], granted["token"], "batch finished"), "released")
        self.assertEqual(self.ledger.acquire("unity_slot", owner="pool", host="mac")["item_id"], second)

    def test_the_unique_index_refuses_a_second_active_owner_of_one_slot(self):
        self.waiting(ISSUE, "a" * 40, "batch")
        granted = self.ledger.acquire("unity_slot", owner="pool", host="mac")
        with self.assertRaises(sqlite3.IntegrityError):
            self.ledger.connection.execute(
                """INSERT INTO reservations(reservation_id,item_id,generation,kind,mode,resource,host,commit_sha,
                   state,owner,token_hash,created_at,acquired_at)
                   VALUES('r2',?,0,'unity_slot','batch','unity_slot:1','mac',?,'active','x','y',?,?)""",
                (granted["item_id"], "a" * 40, self.now, self.now))

    def test_a_worker_may_not_stack_a_second_request_while_it_holds_one(self):
        item = self.item(ISSUE, "a" * 40)
        token = self.ledger.claim(item["id"], worker_id="w")["token"]
        self.ledger.await_resource(item["id"], token, "unity_slot", "batch")
        self.ledger.resume(item["id"], "granted")
        token = self.ledger.claim(item["id"], worker_id="w")["token"]
        with self.assertRaises(LedgerError):
            self.ledger.await_resource(item["id"], token, "unity_slot", "interactive")

    def test_an_item_without_a_pinned_commit_cannot_request_a_slot(self):
        self.ledger.observe_issue(issue())
        self.ledger.ensure_session(SESSION, ISSUE, True)
        item = self.ledger.create_work_item(issue_id=ISSUE, session_id=SESSION, skill="fix")
        token = self.ledger.claim(item["id"], worker_id="w")["token"]
        with self.assertRaises(LedgerError):
            self.ledger.await_resource(item["id"], token, "unity_slot", "batch")

    def test_a_wrong_token_can_neither_read_nor_release_a_reservation(self):
        self.waiting(ISSUE, "a" * 40, "batch")
        granted = self.ledger.acquire("unity_slot", owner="pool", host="mac")
        with self.assertRaises(LedgerError):
            self.ledger.release(granted["reservation_id"], "not-the-token", "nope")
        self.assertEqual(self.ledger.reservation(granted["reservation_id"])["state"], "active")
        self.assertNotIn("token", self.ledger.reservation(granted["reservation_id"]))

    def test_stop_cancels_a_queued_reservation_and_only_marks_an_active_one(self):
        first = self.waiting(ISSUE, "a" * 40, "batch")
        second = self.waiting(OTHER, "b" * 40, "interactive")
        granted = self.ledger.acquire("unity_slot", owner="pool", host="mac")
        self.ledger.cancel_reservations(first, "Linear stop")
        self.ledger.cancel_reservations(second, "Linear stop")
        self.assertEqual(self.ledger.reservation(granted["reservation_id"])["state"], "cancel_requested")
        self.assertEqual([r["state"] for r in self.ledger.reservations() if r["item_id"] == second], ["cancelled"])
        self.assertEqual(self.ledger.release(granted["reservation_id"], granted["token"], "stopped"), "cancelled")

    def test_cancelling_a_work_item_cancels_its_reservations_in_the_same_transaction(self):
        item = self.waiting(ISSUE, "a" * 40, "batch")
        self.ledger.cancel(item, "operator")
        self.assertEqual([r["state"] for r in self.ledger.reservations() if r["item_id"] == item], ["cancelled"])

    def test_a_failing_probe_holds_the_slot_until_the_operator_recovers_it(self):
        self.waiting(ISSUE, "a" * 40, "batch")
        granted = self.ledger.acquire("unity_slot", owner="pool", host="mac")
        self.ledger.hold(granted["reservation_id"], "quiescence probe failed")
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "held")
        self.waiting(OTHER, "b" * 40, "batch")
        self.assertIsNone(self.ledger.acquire("unity_slot", owner="pool", host="mac"))
        self.ledger.recover_slot("unity_slot:1", "operator closed Unity by hand")
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "idle_closed")
        self.assertIsNotNone(self.ledger.acquire("unity_slot", owner="pool", host="mac"))

    def test_a_reservation_is_listed_for_settlement_once_its_item_is_no_longer_running(self):
        item = self.waiting(ISSUE, "a" * 40, "batch")
        granted = self.ledger.acquire("unity_slot", owner="pool", host="mac")
        self.ledger.resume(item, "granted")
        self.assertEqual(self.ledger.reservations_to_settle(), [])
        token = self.ledger.claim(item, worker_id="w")["token"]
        self.ledger.fail(item, "worker died")
        self.assertEqual([r["reservation_id"] for r in self.ledger.reservations_to_settle()],
                         [granted["reservation_id"]])

    def test_an_identity_observation_is_appended_per_item(self):
        item = self.waiting(ISSUE, "a" * 40, "batch")
        granted = self.ledger.acquire("unity_slot", owner="pool", host="mac")
        self.ledger.record_identity(item, granted["reservation_id"], "unity_slot:1",
                                    {"aggregate": "match", "checks": {"source_commit": "match"}})
        rows = self.ledger.identity_observations(item)
        self.assertEqual(rows[0]["result"]["aggregate"], "match")

    def test_one_hosts_active_reservation_does_not_starve_another_host(self):
        """The Windows plan inherits this file. A pre-check without a host predicate would make one host's
        busy slot block the other host's pool forever."""
        self.ledger.ensure_slot("unity_slot:2", kind="unity_slot", host="win", folder="/e/slot-2")
        self.waiting(ISSUE, "a" * 40, "batch")
        self.waiting(OTHER, "b" * 40, "batch")
        self.assertIsNotNone(self.ledger.acquire("unity_slot", owner="pool", host="mac"))
        second = self.ledger.acquire("unity_slot", owner="pool", host="win")
        self.assertEqual(second["resource"], "unity_slot:2")

    def test_two_connections_acquiring_at_once_produce_exactly_one_grant(self):
        """The 'across processes rather than by convention' claim, tested across two connections rather than
        two calls on one. BEGIN IMMEDIATE takes the write lock for the whole transaction, so the loser reads a
        slot that is already 'switching' and returns None — the unique index never has to fire."""
        self.waiting(ISSUE, "a" * 40, "batch")
        other = Ledger(Path(self.tmp.name) / "l.sqlite3", clock=lambda: self.now, lease_seconds=60)
        self.addCleanup(other.close)
        barrier, results = threading.Barrier(2), []
        lock = threading.Lock()

        def run(ledger):
            barrier.wait()
            granted = ledger.acquire("unity_slot", owner="pool", host="mac")
            with lock:
                results.append(granted)

        threads = [threading.Thread(target=run, args=(l,)) for l in (self.ledger, other)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=20)
        self.assertEqual(len([r for r in results if r is not None]), 1, results)
        self.assertEqual(len(self.ledger.reservations(("active",))), 1)
```

Add `import sqlite3`, `import threading` and `from pathlib import Path` to the module's imports if they are not there, and extend the existing `from agent.ledger import ...` line with `LedgerError` and `Ledger` if either is missing. `OTHER` is the second issue uuid the module defines; `SELECTED_AT` is the constant Task 1 added.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k Reservation`
Expected: FAIL with `AttributeError: 'Ledger' object has no attribute 'ensure_slot'`.

- [ ] **Step 3: Add the three tables**

In `agent/ledger.py`, inside the existing `executescript` block, after the `inbox` table and before `audit`:

```sql
                CREATE TABLE IF NOT EXISTS slots (
                    slot_id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    host TEXT NOT NULL,
                    folder TEXT NOT NULL,
                    state TEXT NOT NULL CHECK(state IN ('idle_closed','idle_open','switching',
                        'interactive_busy','batch_busy','held')),
                    parked_commit TEXT,
                    instance TEXT,
                    mcp_address TEXT,
                    account TEXT,
                    last_switch_at REAL,
                    updated_at REAL NOT NULL,
                    UNIQUE(host, folder)
                );
                CREATE TABLE IF NOT EXISTS reservations (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    reservation_id TEXT NOT NULL UNIQUE,
                    item_id TEXT NOT NULL REFERENCES work_items(id),
                    generation INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    mode TEXT NOT NULL CHECK(mode IN ('interactive','batch')),
                    resource TEXT,
                    host TEXT,
                    commit_sha TEXT NOT NULL,
                    state TEXT NOT NULL CHECK(state IN ('queued','active','cancel_requested','cancelled','released')),
                    owner TEXT,
                    token_hash TEXT,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    created_at REAL NOT NULL,
                    acquired_at REAL,
                    released_at REAL,
                    release_reason TEXT,
                    CHECK ((owner IS NULL) = (token_hash IS NULL)),
                    CHECK (state NOT IN ('active','cancel_requested')
                           OR (token_hash IS NOT NULL AND resource IS NOT NULL))
                );
                CREATE UNIQUE INDEX IF NOT EXISTS one_active_owner_per_resource
                    ON reservations(resource)
                    WHERE state IN ('active','cancel_requested');
                CREATE UNIQUE INDEX IF NOT EXISTS one_open_reservation_per_item
                    ON reservations(item_id)
                    WHERE state IN ('queued','active','cancel_requested');
                CREATE INDEX IF NOT EXISTS reservations_queue ON reservations(kind, state, sequence);
                CREATE TABLE IF NOT EXISTS identity_observations (
                    observation_id TEXT PRIMARY KEY,
                    item_id TEXT NOT NULL REFERENCES work_items(id),
                    reservation_id TEXT NOT NULL,
                    slot_id TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    result_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS identity_by_item ON identity_observations(item_id, created_at);
```

`AUTOINCREMENT` on `sequence` is deliberate and matches `farmqa_controller.py:49`: FIFO must survive row deletion. `one_active_owner_per_resource` is FarmQA's `controller_single_slot` widened from the constant `(1)` to a column, and the second table CHECK is what makes it binding — SQLite treats NULLs as distinct, so without it a `queued` row could reach `active` with a NULL `resource` and the index would never fire.

- [ ] **Step 4: Add the slot methods**

In `agent/ledger.py`, after `set_worker`:

```python
    SLOT_STATES = ("idle_closed", "idle_open", "switching", "interactive_busy", "batch_busy", "held")
    FREE_SLOT_STATES = ("idle_closed", "idle_open")

    def _slot_row(self, slot_id):
        row = self.connection.execute("SELECT * FROM slots WHERE slot_id=?", (slot_id,)).fetchone()
        if row is None:
            raise LedgerError(f"unknown slot: {slot_id}")
        return row

    @staticmethod
    def _slot_view(row):
        return {key: row[key] for key in ("slot_id", "kind", "host", "folder", "state", "parked_commit",
                                          "instance", "mcp_address", "account", "last_switch_at")}

    def ensure_slot(self, slot_id, *, kind, host, folder, instance=None, mcp_address=None, account=None):
        """Upsert a slot from the host configuration. Discovered values are never cleared by a later None."""
        for value, name in ((slot_id, "slot_id"), (kind, "kind"), (host, "host"), (folder, "folder")):
            _text(value, name)
        with self._transaction():
            self.connection.execute(
                """INSERT INTO slots(slot_id,kind,host,folder,state,mcp_address,account,instance,updated_at)
                   VALUES(?,?,?,?,'idle_closed',?,?,?,?)
                   ON CONFLICT(slot_id) DO UPDATE SET kind=excluded.kind, host=excluded.host,
                       folder=excluded.folder,
                       mcp_address=COALESCE(excluded.mcp_address, slots.mcp_address),
                       account=COALESCE(excluded.account, slots.account),
                       instance=COALESCE(excluded.instance, slots.instance),
                       updated_at=excluded.updated_at""",
                (slot_id, kind, host, str(folder), mcp_address, account, instance, self.clock()))
        return self.slot(slot_id)

    def slot(self, slot_id):
        row = self.connection.execute("SELECT * FROM slots WHERE slot_id=?", (slot_id,)).fetchone()
        return self._slot_view(row) if row else None

    def slots(self, kind=None, host=None):
        clauses, values = [], []
        if kind:
            clauses.append("kind=?"); values.append(kind)
        if host:
            clauses.append("host=?"); values.append(host)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        return [self._slot_view(row) for row in
                self.connection.execute(f"SELECT * FROM slots{where} ORDER BY slot_id", values)]

    _UNSET = object()

    def set_slot_state(self, slot_id, state, *, parked_commit=_UNSET, instance=_UNSET, last_switch_at=_UNSET):
        if state not in self.SLOT_STATES:
            raise LedgerError(f"slot state must be one of {self.SLOT_STATES}")
        with self._transaction():
            row = self._slot_row(slot_id)
            columns, values = ["state=?"], [state]
            for name, value in (("parked_commit", parked_commit), ("instance", instance),
                                ("last_switch_at", last_switch_at)):
                if value is not self._UNSET:
                    columns.append(f"{name}=?"); values.append(value)
            self.connection.execute(f"UPDATE slots SET {','.join(columns)},updated_at=? WHERE slot_id=?",
                                    (*values, self.clock(), row["slot_id"]))
            self._audit(slot_id, "slot", state)
        return self.slot(slot_id)
```

- [ ] **Step 5: Add the reservation lifecycle**

In `agent/ledger.py`, replace `await_resource` and add the rest after it:

```python
    RESERVATION_OPEN = ("queued", "active", "cancel_requested")

    @staticmethod
    def _reservation_view(row):
        return {key: row[key] for key in ("reservation_id", "sequence", "item_id", "generation", "kind", "mode",
                                          "resource", "host", "commit_sha", "state", "attempts", "created_at",
                                          "acquired_at", "released_at", "release_reason")}

    def await_resource(self, item_id, token, resource, mode):
        _text(resource, "resource")
        if mode not in ("interactive", "batch"):
            raise LedgerError("mode must be interactive or batch")
        with self._transaction():
            row = self._owned(item_id, token)
            target = json.loads(row["target_json"]) if row["target_json"] else None
            if not target or not COMMIT_SHA.match(target.get("commit_sha") or ""):
                raise LedgerError("a resource request needs a pinned commit; this item has none")
            open_row = self.connection.execute(
                f"""SELECT reservation_id FROM reservations WHERE item_id=? AND state IN
                    ({','.join('?' * len(self.RESERVATION_OPEN))})""",
                (row["id"], *self.RESERVATION_OPEN)).fetchone()
            if open_row:
                raise LedgerError("release the resource this item already holds before requesting another")
            reservation_id = str(uuid4())
            self.connection.execute(
                """INSERT INTO reservations(reservation_id,item_id,generation,kind,mode,commit_sha,state,created_at)
                   VALUES(?,?,?,?,?,?,'queued',?)""",
                (reservation_id, row["id"], row["generation"], resource, mode, target["commit_sha"], self.clock()))
            self._set_state(row["id"], "awaiting_resource", f"needs {resource}:{mode}", token=None,
                            lease_expires_at=None, worker_pid=None, needs_resource=f"{resource}:{mode}")
            self._audit(row["id"], "reservation", "queued", details={"reservation_id": reservation_id, "mode": mode})
            return self._view(self._row(row["id"]))

    def acquire(self, kind, *, owner, host):
        """Grant the oldest queued request of this kind a free slot. FIFO by arrival, never by item priority.

        There is deliberately no kind-wide "is anything active?" pre-check. It would read as an optimisation
        and behave as a restriction: with a second slot it would refuse to grant slot 2 while slot 1 was busy,
        and with a second host it would starve one host behind the other. A busy slot is not in
        FREE_SLOT_STATES, which is the whole gate; the partial unique index is the fence behind it. Because
        the body runs inside BEGIN IMMEDIATE, two connections racing here serialize: the loser reads the slot
        this transaction already moved to 'switching' and returns None, so the index never has to fire.
        """
        _text(kind, "kind"); _text(owner, "owner"); _text(host, "host")
        with self._transaction():
            row = self.connection.execute(
                "SELECT * FROM reservations WHERE kind=? AND state='queued' ORDER BY sequence LIMIT 1",
                (kind,)).fetchone()
            if row is None:
                return None
            # Spec §7 scheduling preference: interactive wants an Editor already open, batch wants none.
            order = ("idle_open", "idle_closed") if row["mode"] == "interactive" else ("idle_closed", "idle_open")
            free = [s for s in self.slots(kind=kind, host=host) if s["state"] in self.FREE_SLOT_STATES]
            free.sort(key=lambda s: (order.index(s["state"]), s["slot_id"]))
            if not free:
                return None
            slot = free[0]
            token = "res_" + secrets.token_urlsafe(32)
            self.connection.execute(
                """UPDATE reservations SET state='active',resource=?,host=?,owner=?,token_hash=?,acquired_at=?
                   WHERE reservation_id=?""",
                (slot["slot_id"], host, owner, _hash_token(token), self.clock(), row["reservation_id"]))
            self.connection.execute("UPDATE slots SET state='switching',updated_at=? WHERE slot_id=?",
                                    (self.clock(), slot["slot_id"]))
            self._audit(row["item_id"], "reservation", "acquired",
                        details={"reservation_id": row["reservation_id"], "slot": slot["slot_id"]})
            granted = self._reservation_view(self.connection.execute(
                "SELECT * FROM reservations WHERE reservation_id=?", (row["reservation_id"],)).fetchone())
            granted["folder"] = slot["folder"]
            granted["token"] = token  # the only time the raw token exists outside the pool
            return granted

    def reservation(self, reservation_id):
        row = self.connection.execute("SELECT * FROM reservations WHERE reservation_id=?", (reservation_id,)).fetchone()
        return self._reservation_view(row) if row else None

    def reservations(self, states=None):
        states = tuple(states) if states else None
        sql = "SELECT * FROM reservations"
        values = ()
        if states:
            sql += f" WHERE state IN ({','.join('?' * len(states))})"
            values = states
        return [self._reservation_view(row) for row in self.connection.execute(sql + " ORDER BY sequence", values)]

    def active_reservation(self, item_id):
        row = self.connection.execute(
            "SELECT * FROM reservations WHERE item_id=? AND state IN ('active','cancel_requested')",
            (item_id,)).fetchone()
        return self._reservation_view(row) if row else None

    def reservations_to_settle(self):
        """A slot is only useful to a running worker: anything else is the pool's to probe and release.

        A slot in 'held' is excluded. hold() leaves the reservation 'active' and only changes the slot, so
        without this clause the same reservation would come back on every two-second pool tick: the pool
        would re-probe a slot the operator has been told to recover, write an audit row each time, and — if a
        probe happened to pass later — release and park a slot spec §7 says must wait for recover-slot.
        """
        rows = self.connection.execute(
            """SELECT r.* FROM reservations r JOIN work_items w ON w.id=r.item_id
               LEFT JOIN slots s ON s.slot_id=r.resource
               WHERE r.state IN ('active','cancel_requested')
                 AND COALESCE(s.state,'') <> 'held'
                 AND (r.state='cancel_requested' OR w.state NOT IN ('queued','running','awaiting_resource'))
               ORDER BY r.sequence""")
        return [self._reservation_view(row) for row in rows]

    def _reservation_owned(self, reservation_id, token):
        row = self.connection.execute("SELECT * FROM reservations WHERE reservation_id=?", (reservation_id,)).fetchone()
        if row is None:
            raise LedgerError(f"unknown reservation: {reservation_id}")
        presented = _hash_token(token) if isinstance(token, str) and token.isascii() and token else ""
        if not presented or not secrets.compare_digest(row["token_hash"] or "", presented):
            raise LedgerError("reservation token required")
        return row

    def release(self, reservation_id, token, reason):
        """FarmQA's rule (farmqa_controller.py:139): cancel_requested resolves to cancelled, active to released."""
        _text(reason, "reason")
        with self._transaction():
            row = self._reservation_owned(reservation_id, token)
            if row["state"] in ("released", "cancelled"):
                return row["state"]
            state = "cancelled" if row["state"] == "cancel_requested" else "released"
            self.connection.execute(
                "UPDATE reservations SET state=?,released_at=?,release_reason=? WHERE reservation_id=?",
                (state, self.clock(), reason[:500], reservation_id))
            if row["resource"]:
                self.connection.execute("UPDATE slots SET state='switching',updated_at=? WHERE slot_id=?",
                                        (self.clock(), row["resource"]))
            self._audit(row["item_id"], "reservation", state, details={"reservation_id": reservation_id,
                                                                      "reason": reason[:200]})
            return state

    def hold(self, reservation_id, reason):
        """A failing quiescence probe keeps the reservation open and takes the slot out of the pool (spec §7)."""
        _text(reason, "reason")
        with self._transaction():
            row = self.connection.execute("SELECT * FROM reservations WHERE reservation_id=?",
                                          (reservation_id,)).fetchone()
            if row is None or row["state"] not in ("active", "cancel_requested"):
                raise LedgerError("only an active reservation can be held")
            self.connection.execute("UPDATE slots SET state='held',updated_at=? WHERE slot_id=?",
                                    (self.clock(), row["resource"]))
            self._audit(row["item_id"], "reservation", "held", details={"reservation_id": reservation_id,
                                                                       "reason": reason[:200]})
            return self._reservation_view(row)

    def recover_slot(self, slot_id, reason):
        """The operator's way out of held: force-release whatever holds the slot and return it to the pool.

        parked_commit is cleared, not kept. Whatever the slot was doing when it was held, the ledger no longer
        knows what commit the folder is on, and park_idle will not correct it because the state is no longer
        'switching'. A NULL says "unknown", and the pool's next grant does a full switch rather than trusting
        a stale value.
        """
        _text(reason, "reason")
        with self._transaction():
            row = self._slot_row(slot_id)
            self.connection.execute(
                """UPDATE reservations SET state=CASE WHEN state='cancel_requested' THEN 'cancelled' ELSE 'released' END,
                   released_at=?,release_reason=? WHERE resource=? AND state IN ('active','cancel_requested')""",
                (self.clock(), f"recover-slot: {reason}"[:500], slot_id))
            self.connection.execute(
                "UPDATE slots SET state='idle_closed',parked_commit=NULL,updated_at=? WHERE slot_id=?",
                (self.clock(), slot_id))
            self._audit(slot_id, "slot", "recovered", details={"reason": reason[:200]})
            return self._slot_view(self._slot_row(row["slot_id"]))

    def cancel_reservations(self, item_id, reason):
        """Stop: queued requests die, an active one keeps the slot and is marked for the probe (spec §7)."""
        _text(reason, "reason")
        with self._transaction():
            self.connection.execute(
                """UPDATE reservations
                   SET state=CASE WHEN state='queued' THEN 'cancelled' ELSE 'cancel_requested' END,
                       released_at=CASE WHEN state='queued' THEN ? ELSE released_at END,
                       release_reason=CASE WHEN state='queued' THEN ? ELSE release_reason END
                   WHERE item_id=? AND state IN ('queued','active')""",
                (self.clock(), reason[:500], item_id))
            self._audit(item_id, "reservation", "cancel requested", details={"reason": reason[:200]})
        return [r for r in self.reservations() if r["item_id"] == item_id]

    def record_identity(self, item_id, reservation_id, slot_id, result):
        observation_id = str(uuid4())
        with self._transaction():
            self.connection.execute(
                """INSERT INTO identity_observations(observation_id,item_id,reservation_id,slot_id,created_at,result_json)
                   VALUES(?,?,?,?,?,?)""",
                (observation_id, item_id, reservation_id, slot_id, self.clock(), _json(result)))
            self._audit(item_id, "identity", str(result.get("aggregate", "unknown")))
        return observation_id

    def identity_observations(self, item_id):
        rows = self.connection.execute(
            "SELECT * FROM identity_observations WHERE item_id=? ORDER BY created_at", (item_id,))
        return [{"observation_id": r["observation_id"], "reservation_id": r["reservation_id"],
                 "slot_id": r["slot_id"], "created_at": r["created_at"],
                 "result": json.loads(r["result_json"])} for r in rows]
```

In `cancel`, add the reservation sweep inside the existing transaction, immediately before `_set_state`, so the operator CLI path cannot orphan a slot:

```python
            self.connection.execute(
                """UPDATE reservations
                   SET state=CASE WHEN state='queued' THEN 'cancelled' ELSE 'cancel_requested' END,
                       released_at=CASE WHEN state='queued' THEN ? ELSE released_at END,
                       release_reason=CASE WHEN state='queued' THEN ? ELSE release_reason END
                   WHERE item_id=? AND state IN ('queued','active')""",
                (self.clock(), reason[:500], row["id"]))
```

- [ ] **Step 6: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k Reservation`
Expected: PASS, twelve tests.

- [ ] **Step 7: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 159 tests (+12 in `tests/test_ledger.py`).

```bash
git add agent/ledger.py tests/test_ledger.py
git commit -m "feat(ledger): slots, reservations and identity observations

Ports the FarmQA controller queue onto work items: FIFO by arrival, hashed owner
token, and one active owner per resource enforced by a partial unique index rather
than by convention. await-resource now enqueues the request in the same
transaction that parks the item, and cancelling an item cancels its reservations.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

