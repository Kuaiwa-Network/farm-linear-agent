# Task 5 report: the identity probe

Commit: `e00ad8f` on `phase1b-tasks-5-11` (parent `b4efc61`).
Whole suite: **214 tests, OK, warning-free** under `python3 -W error -m unittest discover -s tests` (was 195; +19).

While reviewing I found the installed plugin and MCP server on disk outside the protected slot
(`Farm-Client/Library/PackageCache/com.coplaydev.unity-mcp@30d2207509` and
`~/.cache/uv/archive-v0/Ja8LrQ1tYflj35ry`, mcpforunityserver 10.1.0). Reading them turned two of the
risks below from "unverifiable here" into settled defects with fixes — see defects 3 and 4. Nothing was
started and the slot was never touched.

## What I implemented

- **`agent/unity_mcp.py`** — the loopback JSON-RPC client, ported from
  `FarmTestAgent/tools/farmqa_unity_identity.py`. The adversarial parts are verbatim: the redirect-refusing
  opener, the empty `ProxyHandler`, the 1 MiB response bound, the `initialize` handshake pinned to
  `2024-11-05`, the single-matching-id SSE parse, the `_payload` unwrapping. Changed: class renamed to
  `UnityMcp`; the endpoint is a required argument (no 9090 default); `timeout` is a constructor argument and
  is what `_rpc` passes to `opener.open` (FarmQA hardcoded 20 s, the interface specifies `timeout=30`);
  `read`→`read_resource`, `select`→`select_instance` with the presence rule from the brief; a new
  `call_tool(name, arguments)`; `probe()` and `session_probe()` dropped, because the probe source is now an
  argument to `collect` and `session-identity.cs.txt` is FarmQA's. `clientInfo.name` is `farmbot-identity`
  rather than `farmqa-readonly-identity` — it identifies the client in the server's logs, and this client is
  neither FarmQA nor read-only once Task 7 injects tools.
- **`agent/probes/editor-readiness.cs.txt`** — copied; the two-line `continue` filter deleted, so the probe
  returns every loaded assembly and the expected set is genuinely configuration. Everything else, including
  `dataPath`, is verbatim.
- **`agent/identity.py`** — `source_snapshot`, `safe_text`, `project_matches` verbatim; `ready` verbatim
  clause for clause except `now_ms=None`; new `quiet`, `aggregate`, `collect`. `collect` keeps FarmQA's
  order of operations exactly, never raises (an MCP or git failure becomes `error_type` and an `unknown`
  aggregate) and holds no SQLite transaction across an MCP call — there is no SQLite in this module at all
  now, since `Ledger.record_identity` owns the table.
- **`agent/slots.py`** — `UnityIdentity` at the end, per the brief: `discover_instance`, `start`,
  `terminate`, `reap_server`, `refresh`, `wait_quiet`, `console_errors_since`, `probe`, `quiescent`.
- **`tests/test_identity.py`** — 19 tests against a real loopback `http.server`, real `git` in a temp repo,
  real subprocesses. No Unity, no `/Applications`, no network, no real ledger, nothing near
  `.local/editors/slot-1`.

## Test names per file

`tests/test_identity.py` (19):

- `McpTests` — `test_only_a_loopback_mcp_endpoint_is_accepted`,
  `test_a_resource_reads_the_same_through_json_and_through_one_sse_message`,
  `test_an_unlisted_resource_uri_is_refused_before_any_request`,
  `test_selecting_an_instance_that_is_not_connected_names_the_ones_that_are` *(added)*
- `ReadyTests` — `test_a_fresh_idle_editor_of_the_expected_instance_is_ready`,
  `test_a_stale_a_future_a_playing_and_a_compiling_editor_are_all_refused`,
  `test_the_aggregate_is_match_only_when_every_check_matches_and_unknown_is_never_match`,
  `test_quiet_ignores_the_instance_and_the_clock_but_not_the_four_busy_flags`
- `CollectTests` *(added, 5)* — `test_a_matching_editor_aggregates_to_match_beside_a_second_connected_instance`,
  `test_the_expected_assembly_set_is_configuration_and_not_baked_into_the_csharp_probe`,
  `test_a_commit_or_a_build_target_the_editor_does_not_hold_is_a_mismatch_not_an_error`,
  `test_an_editor_that_is_not_ready_never_reaches_the_probe_and_aggregates_to_unknown`,
  `test_a_dirty_or_moving_checkout_is_caught_by_the_two_source_snapshots`
- `UnityIdentityTests` *(added, 6)* — `test_the_instance_is_read_from_the_server_and_matched_by_the_folder_it_reports`,
  `test_an_instance_listing_without_any_path_falls_back_to_the_measured_hash_rule`,
  `test_no_editor_on_this_folder_is_an_editor_stage_slot_error_naming_the_folder`,
  `test_the_console_is_read_in_every_shape_the_installed_plugin_actually_returns`,
  `test_a_console_payload_in_no_known_shape_holds_the_slot_instead_of_certifying_it_clean`,
  `test_the_server_pidfile_is_derived_from_the_slots_own_port_and_a_missing_one_is_no_error`

No other file changed its tests.

## Commands and output

Failing first (Step 2), before any production file existed:

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -v \
      -k McpTests -k ReadyTests -k CollectTests -k UnityIdentityTests
ImportError: Failed to import test module: test_identity
...
ModuleNotFoundError: No module named 'agent.identity'
Ran 1 test in 0.000s
FAILED (errors=1)
```

Selection passing (Step 6):

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests \
      -k McpTests -k ReadyTests -k CollectTests -k UnityIdentityTests
...................
Ran 19 tests in 8.809s
OK
```

Whole suite (Step 7):

```
$ python3 -W error -m unittest discover -s tests
Ran 214 tests in 35.066s
OK
```

The brief predicted 7 tests and a total of 186. The real numbers are 19 and 214: the baseline was already
195 (the brief's figure is three tasks stale), and I added twelve tests beyond the brief's seven.

### Mutation checks

All run with `python3 -B` and `PYTHONDONTWRITEBYTECODE=1`, each reverted from a copy and re-verified green.
Every one was detected:

| # | Mutation | Test that caught it |
|---|---|---|
| 1 | `aggregate` drops the `unknown` rule | `test_the_aggregate_is_match_only...` FAILED |
| 2 | `collect` uses FarmQA's hardcoded four assemblies | `test_the_expected_assembly_set_is_configuration...` FAILED |
| 3 | `ready` loses the `play_mode` clause | `test_a_stale_a_future_a_playing...` FAILED |
| 4 | `collect` runs the probe regardless of the gate | `test_an_editor_that_is_not_ready_never_reaches_the_probe` FAILED |
| 5 | the URI allow-list moves after `_start()` | `test_an_unlisted_resource_uri_is_refused_before_any_request` FAILED |
| 6 | `reap_server` hardcodes port 8080 | `test_the_server_pidfile_is_derived...` FAILED |
| 7 | `discover_instance` loses the hash fallback | `test_an_instance_listing_without_any_path...` FAILED |
| 8 | `console_errors_since` reverted to the brief's `result["lines"]` | `test_the_console_is_read_in_every_shape...` FAILED (1 failure + 1 AttributeError) |

## Brief defects found, and how I resolved them

1. **`play_mode` is nested under `editor`, not at the top level.** The brief's `state()` fixture put
   `play_mode` at the top level while `ready` reads `state['editor']['play_mode']`. As written, the fixture
   makes `test_a_fresh_idle_editor_of_the_expected_instance_is_ready` **fail** (KeyError on the missing
   `editor` key), and makes the playing assertion pass for that same missing key rather than for the flag it
   names — so the clause would be untested and could be deleted silently.
   *Resolution:* the fixture nests `play_mode` under `editor`, which is what the live plugin emits
   (`FarmTestAgent/reports/2026-09-16-unity-readiness/evidence/live-editor.json`, and the two
   `2026-09-16-initial-learning` captures agree). `ready` stays verbatim. Mutation 3 confirms the clause is
   now load-bearing. The fixture keeps the brief's call sites unchanged by taking `play_mode` as a keyword.

2. **FarmQA's permanently-`unknown` checks make the aggregate permanently `unknown`.** FarmQA pinned
   `loaded_source` and `server_environment` to `'unknown'` on purpose and set `loaded_assemblies` to
   `'observed'`, all of which was free beside a constant `BLOCKED` verdict. With the brief's `aggregate`,
   `unknown` is never `match`, so a straight port would make **every** observation aggregate to `unknown`,
   and `SlotPool.switch` raises a probe-stage hold on anything that is not `match`. The interactive path
   would have been dead on arrival and the brief's own argument that all four assemblies exist in this
   project would have been pointless. The brief does not mention these three.
   *Resolution:* `loaded_source` and `server_environment` are dropped (documented in `collect`'s docstring),
   and `loaded_assemblies` is now `match`/`mismatch`. The check set is `editor_ready`, `project`,
   `source_commit`, `source_clean`, `source_stable`, `build_target`, `loaded_assemblies`.

3. **`discover_instance` matches on a path the HTTP listing does not contain.** The brief iterates
   `("projectPath", "dataPath", "path")` over the `mcpforunity://instances` entries. The installed server
   settles it: in mcpforunityserver 10.1.0's `services/resources/unity_instances.py`, the HTTP branch —
   the transport FarmBot uses — builds each entry as `id`, `name`, `hash`, `unity_version`, `connected_at`,
   `session_id`, and the function's own docstring marks `path` as *"(stdio only)"*. The captured payload in
   `FarmTestAgent/reports/2026-09-16-unity-readiness/evidence/live-editor.json` matches exactly. So the
   brief's method never matches, `start()` spins to its 120 s deadline, and every interactive switch dies at
   the editor stage.
   *Resolution:* the path match stays first and is preferred, exactly as the brief argues (it will fire on
   stdio, or if a later server adds the field). When no entry reports any path, the fallback is the rule the
   brief itself documents and Task 0 Step 5 measured — and which
   `com.coplaydev.unity-mcp/Editor/Helpers/ProjectIdentityUtility.cs` confirms line for line:
   `ComputeProjectHash` is SHA1 of `Application.dataPath`, hex, lower-cased, truncated to 16, and the HTTP
   session's `hash` is that value. So `sha1("<folder>/Assets")[:16]`, no trailing slash. It stays safe
   because the computed digest is only ever used to pick an id **out of the list the server returned** — a
   moved or symlinked folder produces no match and raises, rather than confidently addressing somebody
   else's Editor, which was the brief's stated worry. Both spellings of the folder are hashed (as given and
   `resolve()`d): the Editor hashes the `-projectPath` string `start()` handed it, but a host whose slot
   path runs through a symlink would report the resolved one.

4. **`console_errors_since` cannot read what `read_console` returns.** The brief's body is
   `(result or {}).get("lines", [])`. `Editor/Tools/ReadConsole.cs` returns the formatted entries as a
   **bare list** in the `SuccessResponse` payload whenever `count` is given and paging is not — which is
   exactly how the brief calls it — so `.get` is an `AttributeError` on a list at the first interactive
   switch. Worse, `SlotPool.switch` does not wrap this call, so it would not even become a `SlotError` with
   a stage: the operator gets a bare traceback. Under paging the same entries arrive as `items`; the
   server's own stacktrace stripper also knows `lines`. Entries are strings in the default `plain` format
   and dicts (`type`/`message`/`file`/`line`/`stackTrace`) in `json`/`detailed`, so the brief's
   `"error CS" in line` would have silently found nothing against a dict even if the container were right.
   *Resolution:* all three container spellings and both entry kinds are handled, and a payload in none of
   those shapes raises a probe-stage `SlotError` instead of returning `[]` — silently certifying a Console
   clean is how a commit that does not compile reaches a worker with the pool's blessing. Mutation 8
   confirms the brief's version fails. `marker` remains accepted and unused, and the docstring now says so:
   nothing clears the Console between switches, so this cannot yet be "since" anything.

5. **`collect` had no test at all.** The brief's Step 1 covers the client and the gate; the collector, which
   is where all four of this task's changes actually live, was untested. The brief's Step 6 count of seven
   would have been met without a single line of `collect` being executed.
   *Resolution:* `CollectTests` (5 tests), against the same real loopback server plus a real temp git
   repository. They pin the presence-not-uniqueness rule with a second instance connected, the ordering of
   the selection before `project/info`, the Python-side assembly filter, the expected build target, both
   source snapshots, and that a not-ready Editor never reaches `execute_code`.

6. **`UnityIdentity` had no test at all.** Most of it needs a live Editor, but `discover_instance` and
   `reap_server` are pure MCP and path logic.
   *Resolution:* `UnityIdentityTests` (6 tests), covering both `discover_instance` branches and its
   editor-stage failure, the four console shapes, and the pidfile. The pidfile test proves the port is
   derived from `mcp_address` and not hardcoded, without signalling anything: the 8080 pidfile holds a pid
   far above any `pid_max`, so a regression that reads it unlinks the file and fails the assertion instead
   of killing a process.

7. **Stale predicted counts**, as forewarned: 7 → 19 tests, 186 → 214 total.

## Carried findings

- **`SlotError.fault`.** `UnityIdentity` raises `SlotError` in three places (`discover_instance`, `start`,
  `terminate`), all with `stage="editor"` and the default `fault="external"` — correct, since all three are
  Unity, the host or a stale server, never a FarmBot bug. `test_no_editor_on_this_folder...` asserts both
  fields. The probe path itself never raises: `collect` swallows into `error_type` by design.
- **`SlotError.STAGES` still unread, `FakeMcp.quiescent` still unused.** Task 5 did not need either.
  `UnityIdentity.quiescent` now exists as the production counterpart of that double, but nothing calls it
  yet — Task 6's `settle`/`park_idle` is its first consumer, as the plan expects. `STAGES` is still only a
  declaration; nothing in Task 5 validates a stage against it.
- **The `read_resource` allow-list.** The prior review was right that the brief asserts a refusal no step
  introduces *in its diff* — but the check does arrive, because `RESOURCES` and the `uri not in
  self.RESOURCES` guard are part of the file Step 3 copies verbatim. So I implemented neither an extra
  allow-list nor a weakened test; instead I gave the existing test teeth. The brief's version asserts only
  `ValueError`, which an allow-list applied *after* the handshake would satisfy just as well, so the test
  could not see the word "before" in its own name. It now asserts the server received nothing
  (`Handler.seen == []`), and mutation 5 confirms it fails when the check moves after `_start()`.

## Self-review findings

Things I changed after reviewing my own diff:

- Reading the installed plugin and server (both outside the protected slot) turned two "unverifiable"
  risks into the settled defects 3 and 4 above. It is worth saying plainly: the brief's `discover_instance`
  and `console_errors_since` were both non-functional against the software actually installed on this Mac,
  and neither would have been caught by any test the brief specified — the first interactive switch would
  have been the discovery.

- The first version of `discover_instance` hashed only the resolved folder, which failed its own test on
  this Mac (`/var` → `/private/var`). Both spellings are hashed now, with the reason in a comment.
- The pidfile test first wrote pid `1`; under mutation 6 that meant the suite attempted `SIGTERM` on
  launchd (EPERM, harmless, but no test should do that). It now writes a pid that cannot exist.

Things I am reporting rather than changing, because they are outside this task or unverifiable here:

- **`switch()` calls `console_errors_since` outside any `try`** — the one collaborator call in Task 4 that
  `_collaborator_error` does not wrap. My implementation raises `SlotError` directly (which carries a stage)
  rather than a bare exception, so the common path is covered, but a genuine transport failure there still
  escapes `switch` unclassified. Task 6 should wrap it like the others.
- **A failure inside `collect` reaches the operator as "identity probe did not match: {all unknown}".**
  `collect` never raises by design, and `switch` formats only `observation.get("checks")`, dropping
  `error_type`. A FarmBot bug, a dead MCP server and a busy Editor are therefore indistinguishable in the
  hold message, which is exactly the blame confusion `fault` exists to prevent. Task 6 should put
  `error_type` in that message.
- **`build_target` defaults to `None` in `DEFAULTS`**, so an unconfigured slot fails `build_target` on every
  probe and holds at the probe stage with no hint that a configuration key is missing. Task 11's
  configuration should set it (`StandaloneOSX` on this Mac).
- **Deleting the C# filter grows the probe response** from four assembly entries to every loaded assembly —
  roughly 200-300 entries, an estimated ~100 KB of JSON against the client's 1 MiB bound. Comfortable, but
  it is the one cost of making the expected set configuration, and `collect` therefore stores a compacted
  assembly list (name, mvid, `hasGameTestDriver`) in its samples rather than the raw `fullName`/`location`
  of every framework assembly.
- **`UnityIdentity` has no production consumer yet.** `SlotPool` is still never constructed outside tests;
  Task 6 wires both.
- Module-level imports: I hoisted `from .identity import ...` and `from .unity_mcp import UnityMcp` to the
  top of `agent/slots.py` instead of the brief's function-local imports. There is no cycle (neither module
  imports from `agent/`), and a missing module now fails at service start rather than in the middle of a
  switch. `import hashlib`, `os`, `signal`, `subprocess`, `urllib.parse` and `editor_path` went with them.
- No packaging change was needed for `agent/probes/editor-readiness.cs.txt`: the project has no
  `pyproject.toml`/`MANIFEST.in` and runs from the source tree.

---

# Fix round 1 of 5

Commit: `121c249` on `phase1b-tasks-5-11`.
Whole suite after the fixes: **217 tests, OK, warning-free** (was 214; +3 tests, one of them six subtests).

All three findings were the same species — a test that reads like coverage and is not — and all three
mutations the reviewer used now fail. One harness change serves all of them: `Handler.hooks` maps a request
key to a callable that runs **after the reply is composed and before it is released**, which is how a test
says "and then, mid-observation, the world moved". My first draft ran the hook after `wfile.write` and lost
the race: the client was already free to send its next request, and the test saw no change at all.

## Finding 1 — `source_stable` was untested

*What changed:* the old `test_a_dirty_or_moving_checkout_is_caught_by_the_two_source_snapshots` was doing
only the "dirty" half, so it is renamed `test_a_checkout_that_was_already_dirty_fails_source_clean` — which
is what it actually tests. The "moving" half is now a real test:
`test_a_checkout_that_moves_while_the_probe_runs_fails_source_stable` hooks `tools/call:execute_code` and
**commits** a new file in the slot while the probe is running. Both snapshots are therefore clean and the
commit differs, so `source_clean` stays `match` and `source_stable` is the only witness — which is the whole
reason two snapshots exist.

*Covering tests:* `CollectTests.test_a_checkout_that_moves_while_the_probe_runs_fails_source_stable`.

```
$ python3 -B ... (mutation: checks['source_stable'] = 'match' unconditionally)
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k CollectTests
Ran 7 tests in 6.347s
FAILED (failures=1)          # was: all green
```

## Finding 2 — half of `editor_ready` was untested, and permissively so

*What changed:* a new `test_an_editor_that_stops_being_the_same_idle_editor_mid_probe_fails_editor_ready`
hooks the `editor/state` read and swaps the reply, so the post-probe re-read sees a different world from the
pre-probe one. Two subcases, one per half of the clause: the Editor starts compiling (kills
`ready(after, instance)`), and the Editor reports the same instance id with a different `unity` block (kills
`before['unity'] == after['unity']` specifically, since a changed instance id would already fail `ready`).
Both assert that everything the probe itself reported still matched — only the re-read refused it.

*Covering tests:* `CollectTests.test_an_editor_that_stops_being_the_same_idle_editor_mid_probe_fails_editor_ready`.

```
$ python3 -B ... (mutation: `ready(after, instance) and before['unity'] == after['unity']` -> `True and True`)
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k CollectTests
Ran 7 tests in 5.730s
FAILED (failures=2)          # was: all green
```

## Finding 3 — the pin in `_client` was untested and no-opped when it mattered

*The decision, and why.* Neither offered option is right. A **silent skip** leaves the compile gate
unpinned on exactly the path that matters: `switch()` writes `slots.instance` only after the console read,
so a fresh slot's first interactive switch runs `refresh`, `wait_quiet` and `console_errors_since` against
whatever the server routes to by default. A **refusal** breaks that same first switch outright, because the
id genuinely is not in the row yet — and it would have to be fixed by reordering `switch()`, which is Task
4's code and outside this round. So `_client` now **resolves** a missing id from the live server, exactly as
`start` resolved it, and pins the session either way. The pin is never skipped and nothing breaks. Cost: one
extra `instances` read on the three calls that precede the row write.

*What changed:* `_client` is `client.select_instance(slot.get("instance") or self.discover_instance(slot))`,
with the reasoning in its docstring. This made three existing console tests fail, correctly — their slot had
no resolvable Editor — so `UnityIdentityTests.setUp` now connects one, which is also more honest about what
every one of these calls requires.

*Covering tests:* `UnityIdentityTests.test_every_editor_call_pins_the_instance_even_before_the_slot_row_records_it`,
six subtests: `refresh`, `wait_quiet` and `console_errors_since`, each with the row's instance set and NULL.

```
$ python3 -B ... (mutation: the select_instance line deleted from _client)
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k test_every_editor_call_pins
Ran 1 test in 0.577s
FAILED (failures=6)          # all six subtests

$ python3 -B ... (mutation: the old `if slot.get("instance"):` silent skip)
Ran 1 test in 0.576s
FAILED (failures=3)          # exactly the three NULL-row subtests: the permissive gap, named
```

## Promoted Minor — blame on an unreadable console payload

Both `console_errors_since` raises now carry `fault="farmbot"`. Unity answered; it is this reader that does
not understand the answer, so `recover-slot` cannot fix it and an operator sent there wastes their time.
The message says FarmBot must be taught the shape. The covering test asserts the pair, not just the stage.

*Covering test:* `UnityIdentityTests.test_a_console_payload_in_no_known_shape_holds_the_slot_instead_of_certifying_it_clean`.

```
$ python3 -B ... (mutation: fault reverted to the default external)
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests -k test_a_console_payload_in_no_known_shape
Ran 1 test in 0.534s
FAILED (failures=1)
```

## Final verification

```
$ PYTHONDONTWRITEBYTECODE=1 python3 -B -W error -m unittest discover -s tests \
      -k McpTests -k ReadyTests -k CollectTests -k UnityIdentityTests
Ran 22 tests in 10.917s
OK

$ python3 -W error -m unittest discover -s tests
Ran 217 tests in 40.522s
OK
```

The five deferred items were left alone.
