### Task 4: The slot switch moves the slot to a commit and parks it back

The heart of the plan. Spec §7, verbatim: confirm tracked files are clean, `git checkout --detach <commit>`, `git lfs checkout`, then in interactive mode ask the Editor to refresh and wait for compilation with zero Console errors. In batch mode the batchmode Editor compiles on start. When a slot becomes idle the pool parks it back on `origin/main`.

**Why:** the switch is the whole reason slots exist: `Library/` is built once and then moved between commits instead of being rebuilt per task. Task 0 Step 5 measured three unfocused forced recompiles at **9.6 / 7.7 / 5.7 seconds** against Step 3's **170-second** first import, which is what makes the design pay.

**Decision this task encodes:** five.

1. **A switch fetches before it checks out.** The pinned commit is not guaranteed to be in FarmBot's bare clone: `enqueue --commit <sha>` lets an operator name any commit, Task 1's receiver pin comes from a bare `ls-remote` that never touched the clone, and minutes to hours pass between the pin and the grant. Without a fetch, `checkout --detach` fails with `fatal: reference is not a tree`, which this plan would classify as a retryable git failure, re-queue once, and then fail the item as a bogus "verification gap". The fetch is the first action of the git stage, so its own failure is retryable, and the tests below depend on it: they create a commit on the fixture origin *after* `ensure()` and expect the switch to reach it.
2. **The pool starts and closes the Editor; nothing else does.** Spec §7's state table says an `idle_closed` slot accepts interactive work, which means something has to start an Editor, and that a batch request on an `idle_open` slot is accepted "after a graceful close". With exactly one slot, the graceful close is not an edge case — it is the required path for every batch run that follows an interactive one. Without `open_editor`, an interactive grant on a closed slot would refresh and probe an MCP server with no Editor behind it, fail at the probe stage, hold the slot and fail the item. Without `close_editor`, the ledger would say the slot is free while a real Editor still held `Temp/UnityLockfile`, and the next batch run would start `Unity -batchmode` on a locked folder. Both directions get a test.

   **The close is a signal, not a request, and it cleans up after Unity.** Task 0 Step 5 measured all three parts of this and each one contradicts what the plan first assumed. `EditorApplication.Exit(0)` through `execute_code` returned `"exiting"` in 0.1 s and **did not close the Editor** — it was still running and fully responsive two minutes later, so it cannot be the mechanism. `SIGTERM` on the Editor pid works and the process is gone in **1 s**. Unity leaves `Temp/UnityLockfile` behind even on an ordinary close — it was still present at **+32 s** — so the lockfile must be removed by hand, and an earlier draft's "wait for the lockfile to disappear" would have hung for ever, on every close, with no diagnostic. And the `uvx` MCP server **outlives the Editor**: it kept port 8080 bound and still answered HTTP 200 after the Editor was gone, so it must be reaped from `<slot>/Library/MCPForUnity/RunState/mcp_http_8080.pid` or the next `open_editor` meets a stale server that answers for an Editor that no longer exists.
3. **The interactive switch waits for quiet and reads the Console.** `refresh_unity` returns immediately; probing straight afterwards normally observes `compilation.is_compiling` or `is_domain_reload_pending` and aggregates to `unknown`, which this plan routes to a permanent hold. So a `wait_for_quiet` sits between them, and a compile-error check sits after it with its **own** stage, because a project that fails to compile is the item's problem and must not take the slot out of the pool for a human to recover.
4. **A switch that fails at a git step** releases the reservation and re-queues it once at the tail; a second failure fails the item with the reason recorded as a verification gap, because with one slot an endless retry is an endless wait. A switch that fails at the *probe* never retries: it holds the slot and fails the item, because §7 says a failing probe holds the slot for the operator's `recover-slot` and there is no second slot to try. A `compile` failure fails the item and leaves the slot in the pool.
5. **The switch runs on the pool's own thread**, never inside `Scheduler.tick()` — see Task 6.

**Files:**
- Create: `agent/unity.py`
- Modify: `agent/slots.py` (`SlotPool.switch`, `SlotPool.park`, `SlotPool.open_editor`, `SlotPool.close_editor`, `SlotPool.clear_stale_lock`, `SlotPool.another_editor_running`)
- Test: `tests/test_unity.py`, `tests/test_slots.py`

**Interfaces:**
- Consumes: `Worktrees.fetch`, `Worktrees.slot_clean`, `Worktrees.checkout_commit`, `Worktrees.head`, `Ledger.set_slot_state`.
- Produces:
  - `agent.unity.project_version(project) -> str`, read from `ProjectSettings/ProjectVersion.txt`.
  - `agent.unity.candidates(version, system=None) -> list[Path]`, the same probe order Farm-Client's `pack.sh` uses per platform.
  - `agent.unity.editor_path(project, override=None, system=None, exists=None, environ=None) -> Path`, raising `UnityError` naming every path tried. `environ` defaults to `os.environ` and is injectable so a developer with `FARMBOT_UNITY_EXE` exported cannot make the discovery tests pass or fail for the wrong reason.
  - `agent.unity.read_results(path) -> dict`, the batch run's only evidence: `{"total", "passed", "failed", "result"}` read from the test-framework XML's root element, raising `UnityError` when the file is missing, unparseable or carries no `total`. It exists because Task 0 Step 4 measured the exit code as actively misleading — exit 0 means *nothing ran* — so the contract has to be executable rather than described, and Task 7's pool, Task 11's checker and the worker's own report all read the same function's answer.
  - **`agent.unity.writable_roots()` is removed, not repurposed.** It existed to widen the *worker's* seatbelt so a Unity child of the worker could write the UPM cache, the Editor log, EditorPrefs and the licence files. Task 0's addendum voided that job: the worker never starts Unity at all now, and the launcher's invocation is unsandboxed and needs no roots. Keeping the function would leave a list nothing relies on and a test asserting a property nothing checks — and the addendum says so plainly: "its list is no longer load-bearing for correctness". The Windows host's `%LOCALAPPDATA%\Unity` is therefore not a configuration key this plan owes; if a future phase ever sandboxes the batch run again, it is re-derived then, against whatever policy language can express Mach lookups.
  - `agent.unity.other_editor_project(folder, system=None, run=None) -> str | None` and `agent.unity.editor_holds_project(folder, system=None, run=None) -> int | None`, the two halves of one process listing: an Editor on some *other* folder, and the **pid** of the one holding *this* folder. Both take an injectable `run`, so no test shells out to `pgrep`.
  - `agent.unity.batch_test_command(editor, project, *, results, log, test_platform="EditMode", assemblies=(), build_target=None) -> list[str]`. No `-quit` and no `-nographics` (spec §8), and no `-accept-apiupdate` either: spec §8 does not list it, and it authorises the API Updater to rewrite scripts under `Assets/`, which would leave tracked files modified and make the *next* switch fail its clean check — an intermittent failure whose cause is two runs earlier. **Task 7's pool calls this function and `agent/launcher.py` runs the argv outside the worker's sandbox; the worker never receives it and never composes one**, so no host-specific flag is ever spelled out in prose and no value a worker supplied ever reaches an unsandboxed command line.
  - `SlotPool.switch(slot_id, commit, mode) -> dict`, the slot view. Raises `SlotError` with `.stage` set to `"git"`, `"editor"`, `"compile"` or `"probe"` so the caller can apply the right rule.
  - `SlotPool.open_editor(slot, entry) -> str`, starting `Unity -projectPath <folder>` and waiting until the MCP endpoint answers and reports this instance; returns the discovered instance id. Raises `SlotError(stage="editor")` on timeout. The timeout is **120 s** against Task 0 Step 5's measured **16 s** cold start — generous headroom over a measured number, not a guess.
  - `SlotPool.close_editor(slot) -> bool`, in three parts, all of them required by Task 0 Step 5: `SIGTERM` the Editor pid and confirm the process is gone (1 s measured), remove `Temp/UnityLockfile` **by hand** because Unity leaves it behind on an ordinary close, and reap the `uvx` MCP server named in `<slot>/Library/MCPForUnity/RunState/mcp_http_<port>.pid`, whose `<port>` comes from the slot's configured `mcp_address` (8080 on this Mac) and which otherwise keeps that port bound and answering. Raises `SlotError(stage="editor")` if the Editor process survives the SIGTERM window. It never waits for the lockfile to disappear on its own, because it never does.
  - `SlotPool.wait_for_quiet(slot, timeout) -> None`, polling `mcpforunity://editor/state` until compilation, domain reload, asset import and test running are all false. Raises `SlotError(stage="probe")` on timeout.
  - `SlotPool.park(slot_id, mode) -> dict`, moving the slot to the repo's remote default head and recording `parked_commit`. The departing mode decides the parked state, so it is passed in rather than read back from a slot row the release has already overwritten.
  - `SlotPool.clear_stale_lock(folder, alive) -> bool`, removing `Temp/UnityLockfile` only when `alive()` says the process is gone (spec §7). Called from the batch branch of `switch`, from `park` on the closed path and from `settle` in Task 6, and tested in all three branches; not the dead, unverified code it would otherwise be.
  - `SlotPool.editor_is_open(slot) -> bool`, whether a **live Unity process** holds the slot folder. It is a process question, never a file question: Task 0 Step 5 found `Temp/UnityLockfile` still present 32 seconds after an ordinary close, so the lock file is not a liveness marker and a stale one would make `switch` skip `open_editor` and refresh an endpoint with no Editor behind it — a probe-stage hold on the only slot. The answer comes from `agent.unity.editor_holds_project(folder)`, injected as `editor_pid` for the same reason `editor_scan` is.
  - `SlotPool.another_editor_running(folder) -> str | None`, the cheap preflight: a Unity process on this host whose command line names a *different* project folder. It survives the spike because contention is the one licensing question Task 0 Step 6 could **not** exercise — no operator Editor was open — and until it is, refusing to start a second Editor is cheaper than discovering what happens.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_unity.py`:

```python
import tempfile
import unittest
from pathlib import Path

from agent.unity import (UnityError, batch_test_command, candidates, editor_holds_project, editor_path,
                         other_editor_project, project_version, read_results)


class UnityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.project = Path(self.tmp.name) / "slot-1"
        (self.project / "ProjectSettings").mkdir(parents=True)
        (self.project / "ProjectSettings" / "ProjectVersion.txt").write_text(
            "m_EditorVersion: 2022.3.62f3\nm_EditorVersionWithRevision: 2022.3.62f3 (96770f904ca7)\n",
            encoding="utf-8")

    def test_the_editor_is_found_per_host_from_the_project_version(self):
        self.assertEqual(project_version(self.project), "2022.3.62f3")
        mac = candidates("2022.3.62f3", system="Darwin")[0]
        windows = candidates("2022.3.62f3", system="Windows")
        self.assertTrue(str(mac).endswith("Unity.app/Contents/MacOS/Unity"))
        self.assertTrue(all(str(p).endswith("Editor/Unity.exe") for p in windows), windows)
        found = editor_path(self.project, system="Darwin", exists=lambda p: p == mac)
        self.assertEqual(found, mac)

    def test_an_absent_editor_names_every_path_it_tried(self):
        # environ is injected: an exported FARMBOT_UNITY_EXE would otherwise decide this test's outcome.
        with self.assertRaises(UnityError) as caught:
            editor_path(self.project, system="Windows", exists=lambda p: False, environ={})
        self.assertIn("2022.3.62f3", str(caught.exception))
        self.assertGreaterEqual(str(caught.exception).count("Unity.exe"), 2)

    def test_the_batch_command_never_quits_never_drops_graphics_and_never_rewrites_sources(self):
        command = batch_test_command("/u/Unity", self.project, results=self.project / "r.xml",
                                     log=self.project / "r.log", assemblies=("HotUpdate.Tests",),
                                     build_target="OSXUniversal")
        self.assertEqual(command[0], "/u/Unity")
        self.assertNotIn("-quit", command)              # the test runner exits on its own (spec §8)
        self.assertNotIn("-nographics", command)        # PlayMode fixtures render FairyGUI (spec §8)
        self.assertNotIn("-accept-apiupdate", command)  # would rewrite Assets/ and dirty the next switch
        self.assertEqual(command[command.index("-testPlatform") + 1], "EditMode")
        self.assertEqual(command[command.index("-projectPath") + 1], str(self.project))
        self.assertEqual(command[command.index("-buildTarget") + 1], "OSXUniversal")

    def test_the_results_file_is_the_evidence_and_a_zero_total_is_a_verification_gap(self):
        """Task 0 Step 4, the spike's own "most important answer": exit 0 means *nothing ran* and exit 2
        means tests failed, so the exit code is advisory and the XML is the evidence. The three cases are
        the three the contract has to separate — a real run, an empty run behind a green exit code, and no
        run at all — and each of the three callers (the pool, the checker, the worker's report) asks this
        one function rather than parsing the file again."""
        red = self.project / "red.xml"
        red.write_text('<?xml version="1.0"?><test-run result="Failed(Child)" total="4388" passed="4362" '
                       'failed="26" />', encoding="utf-8")
        self.assertEqual(read_results(red), {"result": "Failed(Child)", "total": 4388, "passed": 4362,
                                             "failed": 26})
        empty = self.project / "empty.xml"
        empty.write_text('<?xml version="1.0"?><test-run result="Passed" total="0" passed="0" failed="0" />',
                         encoding="utf-8")
        # Not an error to read — a green exit code over an empty run is exactly what a wrong -assemblyNames
        # produces, and the caller is the one that must call total == 0 a gap rather than a pass.
        self.assertEqual(read_results(empty)["total"], 0)
        for broken in (self.project / "missing.xml", self.project / "truncated.xml"):
            broken.write_text("<test-run", encoding="utf-8") if broken.name == "truncated.xml" else None
            with self.assertRaises(UnityError):
                read_results(broken)

    def test_another_editor_on_a_different_project_is_seen_and_our_own_is_not(self):
        """The two halves of one process listing, and they must not answer the same question. The first is
        the contention preflight; the second is what `SlotPool.editor_is_open` asks instead of looking at
        Temp/UnityLockfile, which Task 0 Step 5 found still present 32 s after the process was gone."""
        listing = (f"901 /Applications/Unity/Hub/Editor/2022.3.62f3/Unity.app/Contents/MacOS/Unity "
                   f"-projectPath /Users/x/WorkSpaces/Farm/Farm-Client\n")
        self.assertEqual(other_editor_project(self.project, system="Darwin", run=lambda: listing),
                         "/Users/x/WorkSpaces/Farm/Farm-Client")
        mine = f"901 Unity -projectPath {self.project}\n"
        self.assertIsNone(other_editor_project(self.project, system="Darwin", run=lambda: mine))
        self.assertIsNone(other_editor_project(self.project, system="Darwin", run=lambda: ""))
        # editor_holds_project is the complement: our folder, and a pid rather than a bool.
        self.assertEqual(editor_holds_project(self.project, system="Darwin", run=lambda: mine), 901)
        self.assertIsNone(editor_holds_project(self.project, system="Darwin", run=lambda: listing))
        self.assertIsNone(editor_holds_project(self.project, system="Darwin", run=lambda: ""))
```

In `tests/test_slots.py`, first extend `SlotFixture.pool` with the three collaborators this task's
constructor adds, then add the rest:

```python
    def pool(self, worktrees=None, **kwargs):
        # editor_scan and editor_pid are both stubbed: a developer with their own Unity Editor open would
        # otherwise fail every switch test on their machine, and neither test may shell out to pgrep.
        # editor_pid answers from the fake's open_folders, which is what makes it liveness rather than the
        # lock file — the whole point of Task 0 Step 5's +32 s finding.
        mcp = kwargs.get("mcp")
        kwargs.setdefault("editor_scan", lambda folder: None)
        kwargs.setdefault("editor_pid",
                          lambda folder: 4242 if mcp is not None and str(folder) in mcp.open_folders else None)
        return SlotPool(self.ledger, worktrees or self.trees, [self.entry], host="test",
                        editors_root=self.root / "editors", clock=lambda: self.now,
                        sleep=self.advance, **kwargs)
```

```python
INSTANCE = "slot-1@0123456789abcdef"


class FakeMcp:
    """Stands in for the Unity MCP client: records what the pool asked the Editor to do, and stands in for
    the Editor *process* by keeping `open_folders` — which is what the injected `editor_pid` reads, exactly
    as `agent.unity.editor_holds_project` reads the real process listing.

    It also writes the lock file on start and deliberately does **not** remove it on terminate, because the
    real Editor does not either (Task 0 Step 5: still present at +32 s after the process was gone). The two
    are kept apart on purpose: `open_folders` is liveness, the lock file is the litter Unity leaves. The
    pool's own removal of that litter is what the close test proves, and a double that tidied up after
    itself would hide the bug the spike found."""

    def __init__(self, ready=True, quiet=True, console_errors=(), instance=INSTANCE):
        self.ready = ready
        self.quiet = quiet
        self.console_errors = list(console_errors)
        self.instance = instance
        self.calls = []
        self.open_folders = set()

    def _lock(self, slot):
        return Path(slot["folder"]) / "Temp" / "UnityLockfile"

    def start(self, slot, entry):
        self.calls.append(("start", slot["slot_id"]))
        self._lock(slot).parent.mkdir(parents=True, exist_ok=True)
        self._lock(slot).write_text("1", encoding="utf-8")
        self.open_folders.add(slot["folder"])
        return self.instance

    def terminate(self, slot, timeout):
        """SIGTERM and confirm the pid is gone. The lock file is left exactly where Unity leaves it."""
        self.calls.append(("terminate", slot["slot_id"]))
        self.open_folders.discard(slot["folder"])

    def reap_server(self, slot):
        """The uvx MCP server outlives the Editor and keeps port 8080 bound; the pool kills it by pidfile."""
        self.calls.append(("reap_server", slot["slot_id"]))

    def refresh(self, slot):
        self.calls.append(("refresh", slot["slot_id"]))

    def wait_quiet(self, slot, timeout):
        self.calls.append(("wait_quiet", slot["slot_id"]))
        if not self.quiet:
            raise TimeoutError("still compiling")

    def console_errors_since(self, slot, marker):
        self.calls.append(("console", slot["slot_id"]))
        return list(self.console_errors)

    def probe(self, slot, target):
        self.calls.append(("probe", slot["slot_id"]))
        return {"aggregate": "match" if self.ready else "mismatch",
                "checks": {"source_commit": "match" if self.ready else "mismatch"}}

    def quiescent(self, slot, mode):
        self.calls.append(("quiescent", slot["slot_id"]))
        return self.ready


class SwitchTests(SlotFixture):
    def test_a_batch_switch_moves_the_slot_to_the_commit_and_marks_it_busy(self):
        self.pool().ensure()
        commit = self.commit("fix")          # made on the origin *after* ensure: the switch must fetch
        pool = self.pool(mcp=FakeMcp())
        slot = pool.switch("unity_slot:1", commit, "batch")
        self.assertEqual(slot["state"], "batch_busy")
        self.assertEqual(self.trees.head(self.root / "editors" / "slot-1"), commit)
        self.assertEqual(pool.mcp.calls, [])  # a batch run on a closed slot needs no MCP at all (spec §7)

    def test_an_interactive_switch_on_a_closed_slot_starts_the_editor_before_it_probes(self):
        self.pool().ensure()
        commit = self.commit("fix")
        pool = self.pool(mcp=FakeMcp())
        slot = pool.switch("unity_slot:1", commit, "interactive")
        self.assertEqual(slot["state"], "interactive_busy")
        self.assertEqual([name for name, _ in pool.mcp.calls],
                         ["start", "refresh", "wait_quiet", "console", "probe"])
        # The instance the Editor reported is recorded, so the worker and the next probe can address it.
        self.assertEqual(self.ledger.slot("unity_slot:1")["instance"], INSTANCE)

    def test_an_interactive_switch_on_an_open_slot_does_not_restart_the_editor(self):
        self.pool().ensure()
        pool = self.pool(mcp=FakeMcp())
        pool.switch("unity_slot:1", self.commit("one"), "interactive")
        pool.park("unity_slot:1", "interactive")
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "idle_open")
        pool.mcp.calls.clear()
        pool.switch("unity_slot:1", self.commit("two"), "interactive")
        self.assertNotIn("start", [name for name, _ in pool.mcp.calls])

    def test_a_batch_switch_on_an_open_slot_closes_the_editor_gracefully_first(self):
        """All three parts of Task 0 Step 5's close, in one assertion: the Editor is signalled rather than
        asked (EditorApplication.Exit(0) does not close it), the lock file is removed by the *pool* because
        Unity leaves it behind, and the uvx MCP server is reaped because it outlives the Editor and would
        otherwise still be holding port 8080 when the next open_editor runs."""
        self.pool().ensure()
        pool = self.pool(mcp=FakeMcp())
        pool.switch("unity_slot:1", self.commit("one"), "interactive")
        pool.park("unity_slot:1", "interactive")
        pool.mcp.calls.clear()
        pool.switch("unity_slot:1", self.commit("two"), "batch")
        self.assertEqual([name for name, _ in pool.mcp.calls], ["terminate", "reap_server"])
        self.assertFalse((self.root / "editors" / "slot-1" / "Temp" / "UnityLockfile").exists())

    def test_a_dirty_slot_refuses_to_switch_and_says_which_stage_failed(self):
        self.pool().ensure()
        (self.root / "editors" / "slot-1" / "README.md").write_text("edited by hand", encoding="utf-8")
        with self.assertRaises(SlotError) as caught:
            self.pool(mcp=FakeMcp()).switch("unity_slot:1", self.commit("fix"), "batch")
        self.assertEqual(caught.exception.stage, "git")

    def test_a_failing_identity_probe_fails_at_the_probe_stage_not_the_git_stage(self):
        self.pool().ensure()
        with self.assertRaises(SlotError) as caught:
            self.pool(mcp=FakeMcp(ready=False)).switch("unity_slot:1", self.commit("fix"), "interactive")
        self.assertEqual(caught.exception.stage, "probe")

    def test_a_refresh_that_never_goes_quiet_fails_at_the_probe_stage_before_any_probe(self):
        self.pool().ensure()
        pool = self.pool(mcp=FakeMcp(quiet=False))
        with self.assertRaises(SlotError) as caught:
            pool.switch("unity_slot:1", self.commit("fix"), "interactive")
        self.assertEqual(caught.exception.stage, "probe")
        self.assertNotIn("probe", [name for name, _ in pool.mcp.calls])

    def test_a_compile_error_fails_the_item_at_its_own_stage_and_leaves_the_slot_usable(self):
        """spec §7 asks for 'zero Console errors'. A project that does not compile is the item's problem: it
        must not take the one slot out of the pool until a human runs recover-slot."""
        self.pool().ensure()
        pool = self.pool(mcp=FakeMcp(console_errors=["Assets/A.cs(3,1): error CS1002: ; expected"]))
        with self.assertRaises(SlotError) as caught:
            pool.switch("unity_slot:1", self.commit("fix"), "interactive")
        self.assertEqual(caught.exception.stage, "compile")
        self.assertIn("CS1002", str(caught.exception))

    def test_a_stale_lockfile_is_cleared_and_a_live_one_is_kept(self):
        self.pool().ensure()
        lock = self.root / "editors" / "slot-1" / "Temp" / "UnityLockfile"
        lock.parent.mkdir(parents=True, exist_ok=True)
        lock.write_text("1", encoding="utf-8")
        self.assertFalse(SlotPool.clear_stale_lock(lock.parent.parent, lambda: True))
        self.assertTrue(lock.exists())
        self.assertTrue(SlotPool.clear_stale_lock(lock.parent.parent, lambda: False))
        self.assertFalse(lock.exists())
        self.assertFalse(SlotPool.clear_stale_lock(lock.parent.parent, lambda: False))

    def test_park_returns_a_batch_slot_to_main_closed_and_an_interactive_slot_to_main_open(self):
        self.pool().ensure()
        pool = self.pool(mcp=FakeMcp())
        pool.switch("unity_slot:1", self.commit("fix"), "batch")
        main = self.trees.resolve_commit("Farm-Client")
        slot = pool.park("unity_slot:1", "batch")
        self.assertEqual((slot["state"], slot["parked_commit"]), ("idle_closed", main))
        self.assertEqual(self.trees.head(self.root / "editors" / "slot-1"), main)
        pool.switch("unity_slot:1", self.commit("more"), "interactive")
        main = self.trees.resolve_commit("Farm-Client")
        slot = pool.park("unity_slot:1", "interactive")
        # spec §7: "After an interactive run the Editor stays open, parked on main."
        self.assertEqual((slot["state"], slot["parked_commit"]), ("idle_open", main))
```

Three notes. The probe test switches to a commit that is already `origin/main`'s child, so the git stage succeeds and only the probe can fail; that is the point of the assertion. Every test creates its commit on the fixture origin *after* `ensure()`, which is what makes the fetch at the top of `switch` load-bearing rather than decorative. And `park` takes the departing mode as an argument: in production `park` is reached from `park_idle`, by which time `Ledger.release` has already overwritten the slot's state to `switching`, so a ternary on `slot["state"]` would be false every time and `idle_open` would be unreachable — while a unit test that called `park` directly from `batch_busy` would still pass and hide it.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k UnityTests -k SwitchTests`
Expected: FAIL with `ModuleNotFoundError: No module named 'agent.unity'` and `AttributeError: 'SlotPool' object has no attribute 'switch'`.

- [ ] **Step 3: Write the Unity module**

Create `agent/unity.py`:

```python
"""Where the Editor is on this host, and how a batch test run is spelled (spec §8).

The probe order is Farm-Client's own pack.sh, so a host that builds by hand and FarmBot agree about which
Editor is in use. This is the only module in agent/ allowed to name an operating system or an install path.
"""
import os
import platform
import re
from pathlib import Path

VERSION = re.compile(r"^m_EditorVersion:\s*(\S+)\s*$", re.MULTILINE)


class UnityError(RuntimeError):
    pass


def project_version(project):
    path = Path(project) / "ProjectSettings" / "ProjectVersion.txt"
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise UnityError(f"{path}: unreadable; is this a Unity project folder?") from exc
    match = VERSION.search(text)
    if not match:
        raise UnityError(f"{path} names no m_EditorVersion")
    return match.group(1)


def candidates(version, system=None):
    system = system or platform.system()
    if system == "Darwin":
        return [Path(f"/Applications/Unity/Hub/Editor/{version}/Unity.app/Contents/MacOS/Unity")]
    if system == "Windows":
        return [Path(f"D:/Program/UnityEditor/{version}/Editor/Unity.exe"),
                Path(f"D:/Unity Hub/{version}/Editor/Unity.exe"),
                Path(f"C:/Program Files/Unity/Hub/Editor/{version}/Editor/Unity.exe")]
    return [Path.home() / "Unity" / "Hub" / "Editor" / version / "Editor" / "Unity"]


def editor_path(project, override=None, system=None, exists=None, environ=None):
    """An explicit path wins, then FARMBOT_UNITY_EXE, then the per-host probe for the project's own version.

    environ is injectable so that a developer who happens to export FARMBOT_UNITY_EXE cannot silently decide
    the outcome of the discovery tests — the global constraint says no test touches /Applications, and
    nothing else stops the environment from redirecting this lookup."""
    exists = exists or (lambda path: path.exists())
    environ = os.environ if environ is None else environ
    explicit = override or environ.get("FARMBOT_UNITY_EXE")
    if explicit:
        path = Path(explicit)
        if not exists(path):
            raise UnityError(f"configured Unity editor not found: {path}")
        return path
    version = project_version(project)
    tried = candidates(version, system)
    for path in tried:
        if exists(path):
            return path
    raise UnityError(f"no Unity {version} editor found; tried: " + ", ".join(str(p) for p in tried))


def batch_test_command(editor, project, *, results, log, test_platform="EditMode", assemblies=(),
                       build_target=None):
    """spec §8: no -quit, because the test runner exits on its own and -quit races the results writer; no
    -nographics, because the PlayMode fixtures render FairyGUI; and no -accept-apiupdate, because it is not in
    §8's argument list and it lets the API Updater rewrite scripts under Assets/, which would leave the slot
    dirty and make the *next* switch fail its clean check two runs later."""
    command = [str(editor), "-batchmode", "-silent-crashes",
               "-projectPath", str(project),
               "-runTests", "-testPlatform", test_platform,
               "-testResults", str(results), "-logFile", str(log)]
    if build_target:
        command[2:2] = ["-buildTarget", str(build_target)]
    if assemblies:
        command += ["-assemblyNames", ";".join(assemblies)]
    return command


def read_results(path):
    """The only evidence a batch run produces. Task 0 Step 4: exit 0 means *nothing ran* and exit 2 means
    tests failed, so the caller must read this rather than the return code. Missing, unparseable or without a
    total is a *verification gap*, which is why those three raise instead of returning zeros that would read
    as a green empty run."""
    path = Path(path)
    try:
        root = ElementTree.parse(path).getroot()
    except OSError as exc:
        raise UnityError(f"{path}: no results file; the run produced no evidence either way") from exc
    except ElementTree.ParseError as exc:
        raise UnityError(f"{path}: unparseable results file: {exc}") from exc
    if root.get("total") is None:
        raise UnityError(f"{path}: results file has no total on <{root.tag}>")
    return {"result": root.get("result"), "total": int(root.get("total")),
            "passed": int(root.get("passed") or 0), "failed": int(root.get("failed") or 0)}
```

`read_results` adds `from xml.etree import ElementTree` to the module's imports and is the whole of the exit-code contract as code: three callers read it — the pool in Task 7, `scripts/check-rehearsal.py` in Task 11, and the `fix` worker itself when it writes its report — and none of them parses the file a second time.

The `-assemblyNames` separator is the one the installed `com.unity.test-framework@1.1.33` documentation gives; Phase 1 passes a single assembly, and Task 0's spike records the observed behaviour if more than one is ever needed.

- [ ] **Step 4: Write the switch and the park**

In `agent/slots.py`, extend `SlotError` and add the methods:

```python
class SlotError(RuntimeError):
    STAGES = ("git", "editor", "compile", "probe")

    def __init__(self, message, stage="git"):
        super().__init__(message)
        # "git" and "editor" may be retried once at the tail of the queue; "compile" fails the item and leaves
        # the slot in the pool; "probe" holds the slot for the operator's recover-slot (spec §7).
        self.stage = stage
```

```python
    BUSY_FOR = {"interactive": "interactive_busy", "batch": "batch_busy"}

    def switch(self, slot_id, commit, mode):
        """Spec §7's sequence, in order. The caller has already marked the slot 'switching' by acquiring it.

        `was_open` therefore cannot come from the slot row — `acquire` has already overwritten its state with
        the transient 'switching'. It is a question about the host: is a Unity process alive on this folder?
        See `editor_is_open` for why it is not a question about Temp/UnityLockfile.
        """
        slot = self.ledger.slot(slot_id)
        if slot is None:
            raise SlotError(f"unknown slot: {slot_id}")
        folder = Path(slot["folder"])
        entry = self.entries.get(slot_id, DEFAULTS)
        was_open = bool(self.mcp is not None and self.editor_is_open(slot))
        other = self.another_editor_running(folder)
        if other:
            # The licence is a paid serial and resolves fine both foreground and under launchd (Task 0 Step
            # 6), but two Editors contending for it was the one case the spike could not run, because the
            # operator had none open. Until that is measured, do not discover it during a graded item: a
            # lost licence race reports as something that reads like project corruption, so hold the slot
            # with a sentence a human can act on instead.
            raise SlotError(f"{slot_id}: another Unity Editor is open on {other}; close it, then "
                            f"`recover-slot --slot {slot_id}`", stage="probe")
        try:
            self.worktrees.fetch(entry["repo"])   # the pin may post-date the clone's last fetch
            if not self.worktrees.slot_clean(folder):
                raise SlotError(f"{slot_id}: tracked files are dirty; a human edited the slot folder")
            if mode == "batch" and was_open:
                # spec §7: a batch request on an idle-open slot is accepted "after a graceful close".
                self.close_editor(slot)
            self.worktrees.checkout_commit(folder, commit)
            if self.worktrees.pointers_remain(folder):
                raise SlotError(f"{slot_id}: git-lfs pointers survived the checkout")
        except WorktreeError as exc:
            raise SlotError(f"{slot_id}: git stage failed: {exc}", stage="git") from exc
        if mode == "batch":
            # A batch run needs no MCP at all; its result is a results file and an exit code (spec §7). The
            # only thing it needs from the pool is a folder no dead Editor still claims.
            self.clear_stale_lock(folder, lambda: False)
            return self.ledger.set_slot_state(slot_id, self.BUSY_FOR[mode], last_switch_at=self.clock())
        instance = slot.get("instance")
        if not was_open:
            instance = self.open_editor(slot, entry)
        try:
            self.mcp.refresh(slot)
            self.wait_for_quiet(slot, entry["quiet_timeout"])
        except SlotError:
            raise
        except Exception as exc:
            raise SlotError(f"{slot_id}: the Editor never went quiet after the refresh: {exc}", stage="probe") from exc
        errors = self.mcp.console_errors_since(slot, commit)
        if errors:
            # Not a probe failure: the slot is fine, the commit does not compile. Keep the slot in the pool.
            raise SlotError(f"{slot_id}: {len(errors)} compile error(s) at {commit[:7]}: {errors[0]}",
                            stage="compile")
        if instance and instance != slot.get("instance"):
            self.ledger.set_slot_state(slot_id, "switching", instance=instance)
            slot = self.ledger.slot(slot_id)
        try:
            observation = self.mcp.probe(slot, {"commit_sha": commit,
                                                "build_target": entry.get("build_target"),
                                                "repository": str(folder)})
        except Exception as exc:
            raise SlotError(f"{slot_id}: identity probe failed: {exc}", stage="probe") from exc
        if observation.get("aggregate") != "match":
            raise SlotError(f"{slot_id}: identity probe did not match: {observation.get('checks')}",
                            stage="probe")
        self.last_observation = observation
        return self.ledger.set_slot_state(slot_id, self.BUSY_FOR[mode], last_switch_at=self.clock())

    def editor_is_open(self, slot):
        """A live Unity process on this folder — never Temp/UnityLockfile.

        The lock file looks like the obvious answer and is the wrong one. Task 0 Step 5 measured it **still
        present at +32 s** after the Editor process was gone, and Task 4's own close_editor exists to delete
        it by hand for exactly that reason. Reading it here would make a stale lock say "open": switch()
        would skip open_editor, refresh() would hit an endpoint with no Editor behind it, wait_for_quiet
        would time out, and the single slot would end held at the probe stage after any crash, unreaped
        close or service restart. `agent.unity.editor_holds_project` asks the process listing instead and
        returns a pid; it is injected as `editor_pid` so no test in this suite shells out to pgrep."""
        return self.editor_pid(slot["folder"]) is not None

    def open_editor(self, slot, entry):
        """Start the Editor and wait until the MCP endpoint answers and names this folder's instance. The
        timeout is the cold-start figure Task 0 Step 5 measured; the returned instance id is what the worker
        pins its own MCP session with."""
        try:
            return self.mcp.start(slot, entry)
        except Exception as exc:
            raise SlotError(f"{slot['slot_id']}: the Editor did not come up: {exc}", stage="editor") from exc

    def close_editor(self, slot, timeout=None):
        """Close the Editor and leave the folder and the port fit for the next run. Three parts, all measured
        in Task 0 Step 5, none of them optional:

        1. SIGTERM the Editor pid. `EditorApplication.Exit(0)` through execute_code is **not** used: it
           returns "exiting" in 0.1 s and the Editor keeps running, fully responsive, indefinitely. The
           signal works and the process was gone in 1 s.
        2. Remove Temp/UnityLockfile by hand, on *every* close and not only after a crash. Unity leaves it
           behind on an ordinary close (still present at +32 s), so there is nothing to wait for — an
           earlier draft of this method waited for it to disappear, which would have hung for ever on every
           batch run that followed an interactive one. Starting `Unity -batchmode` on a folder whose lock
           survives is the corruption the slot design exists to avoid.
        3. Reap the uvx MCP server from <slot>/Library/MCPForUnity/RunState/mcp_http_<port>.pid, where
           <port> is the slot's own mcp_address port (8080 here). It outlives the Editor, keeps that port
           bound and still answers HTTP 200, so the next open_editor would attach to a server whose Editor
           is gone and read somebody else's state — or none.
        """
        timeout = self.entries.get(slot["slot_id"], DEFAULTS)["close_timeout"] if timeout is None else timeout
        folder = Path(slot["folder"])
        try:
            self.mcp.terminate(slot, timeout)
        except Exception as exc:
            raise SlotError(f"{slot['slot_id']}: the Editor did not stop within {timeout}s of SIGTERM: {exc}",
                            stage="editor") from exc
        self.clear_stale_lock(folder, lambda: False)   # the pid is confirmed gone; Unity left the lock behind
        if (folder / "Temp" / "UnityLockfile").exists():
            # Deliberately the file, not editor_is_open: the process question was already answered by
            # terminate(). What is checked here is that the litter Unity leaves is actually gone, because
            # the next `Unity -batchmode` on a folder whose lock survives is the corruption slots prevent.
            raise SlotError(f"{slot['slot_id']}: Temp/UnityLockfile could not be removed", stage="editor")
        try:
            self.mcp.reap_server(slot)
        except Exception as exc:
            # A surviving server is not worth failing the close over, but it must be visible: the next
            # open_editor is the thing that will meet it, and it fails there with a clearer message.
            raise SlotError(f"{slot['slot_id']}: the MCP server on {slot['mcp_address']} outlived the Editor "
                            f"and could not be reaped: {exc}", stage="editor") from exc
        return True

    def wait_for_quiet(self, slot, timeout):
        """spec §7's 'wait for compilation'. refresh_unity returns at once, so probing straight afterwards
        normally observes is_compiling or is_domain_reload_pending and aggregates to unknown — which this plan
        routes to a permanent hold.

        Task 0 Step 5 measured three unfocused forced recompiles at 9.6 / 7.7 / 5.7 s, so the deadline is the
        only thing that decides: a sample is 'stalled' when it crosses the absolute timeout, never because it
        differs from another sample by some ratio. A no-op refresh is legitimately sub-second and would make
        any ratio rule fire on a healthy Editor. App Nap does not stall an unfocused Editor on this Mac."""
        deadline = self.clock() + timeout
        while True:
            try:
                self.mcp.wait_quiet(slot, max(1.0, deadline - self.clock()))
                return
            except TimeoutError:
                if self.clock() >= deadline:
                    raise SlotError(f"{slot['slot_id']}: still not quiet after {timeout}s", stage="probe")
                self.sleep(1.0)

    def another_editor_running(self, folder):
        """A Unity Editor on this host that is not this slot's. Returns the other project path, or None.

        The process listing lives in agent/unity.py, which is the only module allowed to know a host, and the
        whole call is injectable (`editor_scan`) so that no test in this suite shells out to pgrep — a
        developer with their own Editor open would otherwise fail every switch test on their machine.
        """
        return self.editor_scan(folder)

    def park(self, slot_id, mode):
        """When a slot becomes idle it goes back to the remote default head, so Library/ tracks main in small
        steps and the slot is ready for a baseline run (spec §7).

        The departing mode is an argument, not something read back from the slot row: in production park() is
        reached from park_idle(), by which time Ledger.release has already set the slot to 'switching', so a
        ternary on slot['state'] would always choose idle_closed and spec §7's "after an interactive run the
        Editor stays open, parked on main" would be unimplemented — while a unit test calling park() directly
        from batch_busy would still pass and hide it.
        """
        slot = self.ledger.slot(slot_id)
        entry = self.entries.get(slot_id, DEFAULTS)
        folder = Path(slot["folder"])
        try:
            commit = self.worktrees.resolve_commit(entry["repo"])
            if self.worktrees.head(folder) != commit:
                self.worktrees.checkout_commit(folder, commit)
        except WorktreeError as exc:
            raise SlotError(f"{slot_id}: could not park on the default branch: {exc}", stage="git") from exc
        state = "idle_open" if mode == "interactive" and self.editor_is_open(slot) else "idle_closed"
        if state == "idle_closed":
            self.clear_stale_lock(folder, lambda: False)
        return self.ledger.set_slot_state(slot_id, state, parked_commit=commit, last_switch_at=self.clock())

    @staticmethod
    def clear_stale_lock(folder, alive):
        """An Editor that died mid-run leaves Unity's lock file behind; it is removed only after the process is
        confirmed gone (spec §7). Callers: the batch branch of switch(), park() on the closed path, and
        settle() in Task 6 — each of which has already established that no process holds the folder, which is
        why each passes `lambda: False` rather than guessing a second time. Not dead code and not untested."""
        lock = Path(folder) / "Temp" / "UnityLockfile"
        if not lock.exists() or alive():
            return False
        lock.unlink()
        return True
```

Add three arguments to `SlotPool.__init__`: `self.sleep = sleep or time.sleep` (injected so no test waits on a real clock), `self.editor_scan = editor_scan or agent.unity.other_editor_project` and `self.editor_pid = editor_pid or agent.unity.editor_holds_project` (both injected so no test in this suite shells out to `pgrep`; `SlotFixture.pool` stubs the first with `lambda folder: None` and answers the second from `FakeMcp.open_folders`). Add two keys to `DEFAULTS`, both seeded from Task 0 Step 5's measured numbers with headroom: `"quiet_timeout": 300` (measured recompiles 5.7–9.6 s; the 120-second absolute threshold is the stall verdict, and this is the pool's own deadline above it) and `"close_timeout": 60` (the Editor was gone **1 second** after SIGTERM, so a minute is already extravagant — it was 120 when the close was expected to wait on a lockfile that in fact never disappears). In `agent/unity.py`, beside `batch_test_command`:

```python
def _editor_processes(system=None, run=None):
    """(pid, project_path) for every Unity Editor on this host. The only place a host's process-listing
    spelling is written, and `run` is injectable so no test in this suite shells out to pgrep."""
    system = system or platform.system()
    command = (["pgrep", "-fl", "Unity.app/Contents/MacOS/Unity"] if system == "Darwin" else
               ["pgrep", "-fl", "Unity"] if system != "Windows" else
               ["powershell", "-NoProfile", "-Command",
                "(Get-CimInstance Win32_Process | Where-Object Name -eq 'Unity.exe' | "
                "ForEach-Object { \"$($_.ProcessId) $($_.CommandLine)\" })"])
    run = run or (lambda: subprocess.run(command, capture_output=True, text=True, timeout=5).stdout)
    try:
        out = run()
    except (OSError, subprocess.TimeoutExpired):
        return []
    found = []
    for line in (out or "").splitlines():
        match = re.search(r"-projectPath\s+\"?([^\"\s]+)", line)
        pid = re.match(r"\s*(\d+)\b", line)
        if match and pid:
            found.append((int(pid.group(1)), match.group(1)))
    return found


def other_editor_project(folder, system=None, run=None):
    """The project path of a Unity Editor on this host that is not this slot's, or None.

    The licence here is a paid serial, not a Personal seat, and it resolves both foreground and under
    launchd (Task 0 Step 6) — but two Editors contending for it was the one case that spike could not
    exercise, because the operator had none open. A second Editor that loses a licence race reports it as
    something that reads like project corruption. This is the cheap preflight that turns that into a
    sentence, and it is removed when contention has actually been measured."""
    for _, project in _editor_processes(system, run):
        if Path(project).resolve() != Path(folder).resolve():
            return project
    return None


def editor_holds_project(folder, system=None, run=None):
    """The pid of a Unity process that holds *this* folder, or None — `other_editor_project`'s complement
    over the same listing.

    It returns a pid rather than a bool because a caller needs the number: `UnityIdentity.terminate`
    signals it, while `SlotPool.editor_is_open` only asks whether it is None. It exists because
    Temp/UnityLockfile cannot answer the question at all — Task 0 Step 5 found the lock still present 32 s
    after the process was gone, so the file is litter Unity leaves behind, not a liveness marker."""
    for pid, project in _editor_processes(system, run):
        if Path(project).resolve() == Path(folder).resolve():
            return pid
    return None
```

with `import subprocess` added to that module. Both readers go through one listing, so a host's spelling is
written once and a Windows change is a change to `_editor_processes` alone.

- [ ] **Step 5: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k UnityTests -k SwitchTests`
Expected: PASS, fifteen tests (five in `tests/test_unity.py`, ten in `tests/test_slots.py`).

- [ ] **Step 6: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 179 tests (+15).

```bash
git add agent/unity.py agent/slots.py tests/test_unity.py tests/test_slots.py
git commit -m "feat(slots): the slot switch, the Editor life cycle and the park back to main

Spec section 7's sequence, in order: fetch, confirm clean, close a stale Editor,
checkout --detach, git lfs checkout, and in interactive mode start the Editor if it
is closed, refresh, wait for quiet, read the Console and run the identity probe. The
four failure stages get four different rules: git and editor retry once, compile
fails the item and keeps the slot, probe holds the slot for an operator.
agent/unity.py is now the only module that knows an install path or a host path.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

