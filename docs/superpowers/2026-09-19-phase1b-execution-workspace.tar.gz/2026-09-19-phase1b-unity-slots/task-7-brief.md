### Task 7: A worker is launched with exactly the tools its reservation allows

Spec §7: "A worker reaches the Unity MCP or device-mcp only if the launcher put that server into its configuration, and only while the item holds the matching reservation." `Launcher.spawn` has taken an `mcp_servers` argument since Plan 1a and `agent/scheduler.py:60` passes a hardcoded `{}`. This task makes that argument a function of the reservation.

**Why:** the skill manifest's `resources` and `mcp` fields are parsed and validated by `agent/skills.py` and read by no production code at all — only by `tests/test_skills.py`. Injection from the manifest alone would give every `fix` worker the Unity MCP whether or not it holds a slot, which is precisely the enforcement §7 forbids. There is a second reason to be careful here: `Farm-Client/.codex/config.toml` is tracked in git and carries an MCP server URL, so it lands in every worktree a worker runs in. The isolated home makes it inert, and the plan says so explicitly: repository-local agent configuration is never a source of tool configuration. Separately and more seriously, that file also carries a plaintext bearer token for an internal MCP server, in git history. That is a secret-hygiene problem owed to whoever owns Farm-Client, not something this plan can fix; FarmBot's guarantee is only that the file never becomes a source of tool configuration, and `tests/test_launcher.py` already builds the isolated home, so the guarantee is worth asserting there.

**Design:** an interactive reservation adds one MCP server named `unity`, pointing at the slot's `mcp_address`; the worker pins its own session with `set_active_instance`, because HTTP selection is per MCP session and the launcher cannot do it on the worker's behalf. The server entry is built **per runtime**: `{"url": ...}` for the codex TOML writer and `{"type": "http", "url": ...}` for the `claude` JSON writer, because `Launcher.write_mcp_config` emits `{"mcpServers": servers}` and an entry there with a bare `url` and no `type` is not a valid HTTP server definition — spec §8 requires `claude -p` to work with the same manifest and dispatch message, and §19's first risk is that the default runtime may have to switch after Task 0. Getting this wrong makes interactive slots silently lose their only tool.

**A batch reservation adds no MCP server, no writable roots and no argv — because the worker does not run Unity at all.** Task 0 Step 6 ran the batch suite under a plain one-shot LaunchAgent with **no seatbelt**, so it verified the *unsandboxed* run and nothing else; an earlier draft of this task claimed it verified the sandboxed one and was wrong. The spike's addendum tested what Step 6 did not, and the answer is worse than a missing root: under `sandbox_workspace_write`, with `writable_roots = [state_dir, slot]` and `network_access = true` — this launcher's own default set — the Editor **hung indefinitely**, killed at 25 minutes at 0.0% CPU and 113 MB RSS, log frozen at 2,289 bytes, no results file, while the identical command on the identical slot minutes later exited **2 in 19 s** with 2,536,767 bytes of XML and 4388 tests. There were **zero** file-permission denials and licensing *succeeded* inside the seatbelt; the log stops at `Connection Invalid error for service com.apple.hiservices-xpcservice`, a **Mach service** lookup, which is a different axis of the seatbelt that `[sandbox_workspace_write]` does not express. No `writable_roots` entry can fix it, and `codex exec --approve-for-me` is documented as using the workspace-write sandbox, so this holds for every Codex worker FarmBot spawns.

**So the division of labour moves, exactly as spec §7 already divides the slot switch** — "Before a run the launcher, not the worker, moves the slot" — extended to the run itself. The worker *requests* a batch run by asking for a `batch` reservation and exiting; the pool switches the slot and then **runs the Editor through `agent/launcher.py`, outside any sandbox**; the fresh worker that resumes is handed the results file, the parsed totals and the exit code in its `resource` block and reads them as evidence. Two alternatives are **rejected and must not be reintroduced**: giving the worker `danger-full-access` removes the seatbelt from an agent that also holds repository write access and network, which defeats §15; and hand-maintaining a seatbelt profile with Mach-service exceptions is not expressible here and would mean tracking an undocumented set of services Unity happens to need.

**What that buys, stated as properties rather than hopes.** The argv is composed by the pool from the *slot entry's* configuration — `unity`, `build_target_argument`, `test_platform`, `test_assemblies` — and from the item's own state directory; **no value a worker supplied ever reaches it**, so the one unsandboxed command line in FarmBot is not an injection surface. The slot folder is in **no** worker's writable roots in either mode, so a worker cannot write the slot even by accident, which is a stronger guarantee than the one the old batch branch gave. And the flags that matter — no `-quit`, no `-nographics`, no `-accept-apiupdate` — are enforced in the one function that builds the argv, never in prose a worker might paraphrase. The dispatch payload carries the token's *path*, never the token.

**`resource.batch_command` is gone from the payload in both modes.** An interactive worker still has the better route it always had, and now so does a batch one: Task 0 Step 5 found that **MCP for Unity exposes `run_tests` asynchronously** — it returns a `job_id`, is polled with `get_test_job` (which takes a `wait_timeout`), and exposes `clear_stuck` for a job orphaned by a domain reload — so an interactive slot never needs a second Editor, which is the corruption slots exist to prevent, the same class as `git checkout --force` over an open `Library/`. That is the interactive verify path, it runs inside the Editor the pool already started, and it is what rung 5 of `skills/fix/SKILL.md` tells the worker to use (Task 8 Step 5).

**The exit-code contract, measured rather than assumed — and now enforced by the pool rather than trusted to the worker.** Task 0 Step 4 ran the EditMode suite twice. With `-assemblyNames HotUpdate.Tests` the Editor exited **2** and wrote 2.5 MB of XML with `total="4388" passed="4362" failed="26"`. With `-assemblyNames NoSuchAssembly` it exited **0** and wrote 652 bytes reading `result="Passed"` with `total="0"`. So the mapping is the opposite of the intuitive one: **exit 0 means nothing ran and exit 2 means tests failed**, and a typo in an assembly name produces a green exit code over an empty run. The contract is therefore: **read the results XML through `agent.unity.read_results`, assert `total > 0`, and treat the exit code as advisory only.** The pool applies it the moment the run ends and writes the verdict into `resource.batch_result` as `state`: `"ran"`, or `"gap"` when the file is missing, unparseable or reports `total == 0`, or `"timeout"` when the Editor outlived its deadline. A gap is not a failed verification — it is *no* verification, and the worker reports it as a verification gap rather than as evidence either way. The same sentence is in the `AUTHORITY` block in Step 3 and in rung 4 of `skills/fix/SKILL.md` (Task 8 Step 5), which is where the worker actually reads it.

**`origin/main` is known-red: 26 failures of 4388.** Task 0 Step 4 recorded the failing set by class — `AnimalBarnConfigTests` (2), `AnimalUpgradeCostConfigTests` (3), `DressUpConfigContractTests` (1), `LeaderboardConfigContractTests` (1), `GrowthTaskGroupConfigTests` (1), `FirstChargeHeroCropConfigTests` (1), `ConfigProtobufGeneratedGoldenTests` (1), `FriendShelfUnlockConfigTests` (6), `NetworkProtobufGeneratedSmokeTests` (1), `StatInfoConfigTests` (5), `VisitSharedRequestTests` (4) — almost all configuration-table contract tests, which reads as exported tables being out of step with the code rather than as broken code. A `fix` worker will meet these 26 on **every** batch run in this phase and **must not attribute them to its own change**. Comparing a failure set against a stored baseline is still spec §8's verify stage and still belongs to Phase 3 (see Scope); what Phase 1 owes is the warning, so the worker's report says "26 pre-existing failures on main, unchanged" instead of inventing a regression. The list in the spike record is the baseline until it is re-measured.

**The scheduling band, which everything Unity here inherits.** Task 0 Step 6 measured the *same* EditMode suite at **105 s under launchd against 14 s foreground with warm caches** — 7.5x — because `agent/deploy.py:29` writes `"ProcessType": "Background"` into the serve agent's plist and macOS gives that job and every child it spawns lowered CPU priority, timer coalescing and throttled disk I/O. The batch Editor is now started by `Launcher.run_unsandboxed` on the pool thread, which makes it a direct child of `serve` rather than a grandchild through the worker — the band is inherited either way, so the fix is the same and the need for it is if anything plainer. It is one line in the generator and one assertion, it needs no operator and no host, and it belongs here because this is the task that decides what a Unity child inherits from the service.

**Files:**
- Modify: `agent/launcher.py` (`run_unsandboxed`, the only process started outside the worker seatbelt)
- Modify: `agent/slots.py` (`SlotPool.run_batch`, called from `_hand_over` after a batch switch; `__init__` gains `run_unsandboxed`)
- Modify: `agent/scheduler.py` (`launch`, `Scheduler.__init__` gains `slot_entries`)
- Modify: `agent/dispatch.py` (`dispatch_message` gains `resource=None`)
- Modify: `agent/service.py` (`build` fills `Scheduler(slot_entries=...)` from the same entries it hands the pool, and hands `SlotPool` the launcher's `run_unsandboxed`)
- Modify: `agent/deploy.py` (`ProcessType` becomes `Standard`)
- Test: `tests/test_launcher.py`, `tests/test_slots.py`, `tests/test_scheduler.py`, `tests/test_dispatch.py`, `tests/test_deploy.py`

**Interfaces:**
- Consumes: `Launcher.spawn(item_id, message, mcp_servers, budget_seconds, cwd, extra_env=None, writable=())`, unchanged; `Ledger.active_reservation(item_id)`; `Ledger.slot(slot_id)`; `agent.unity.batch_test_command`, `agent.unity.editor_path` and `agent.unity.read_results` from Task 4.
- Produces:
  - `Launcher.run_unsandboxed(argv, *, cwd, timeout, log=None, env=None, owner=None) -> Unsandboxed(returncode, timed_out, seconds)`. **The one place in FarmBot that starts a process outside the worker seatbelt**, and the reason the module owns it: `agent/launcher.py` is already where the sandbox is configured, so both sides of that decision are readable in one file and auditable by one test. It writes no `CODEX_HOME`, no `config.toml` and no sandbox table; it takes an argv the caller composed and never one a worker supplied. On timeout it terminates the process group and sets `timed_out`, because the thing this exists to run is the thing Task 0 watched hang for 25 minutes. `owner` registers the process under a work item for the lifetime of the call, which is the only reason anything else can reach it.
  - `Launcher.kill_group(pid, grace=5.0)`, `Launcher.stop_unsandboxed(owner) -> bool`, `Launcher.stop_all_unsandboxed() -> list`. **These exist because the redesign created a reachability hole and this is where it is closed.** Moving the Editor out of the worker removed the only thing that ever killed it: `Launcher.stop` resolves a handle that `spawn` wrote, the batch Editor never went through `spawn`, the worker that requested it has already exited, and `SlotPool.run_batch` then blocks in `wait(timeout=batch_timeout)` — up to half an hour — on the pool thread, which is a daemon. Without these three, a Stop leaves a real Editor running on a cancelled item and a `serve` shutdown orphans it with the slot folder still open, which the next `ensure` reads as a slot some other Editor holds. `kill_group` takes the process group rather than `kill_pid`'s `ps`-derived descendants walk, because a wedged Editor's children may be re-parented and those are the ones still holding the folder; every process it kills was started with `start_new_session=True`, so the pid is its own group leader.
  - `SlotPool.run_batch(slot, reservation) -> dict`, the batch run itself: compose the argv with `agent.unity.batch_test_command` from the slot entry, run it through `run_unsandboxed` with the slot folder as cwd, then read the XML with `agent.unity.read_results` and write the summary to `<state_dir>/unity-batch.json`. The summary is `{"state", "exit_code", "results_file", "log_file", "seconds", "total", "passed", "failed", "result"}` with `state` one of `"ran"`, `"gap"` or `"timeout"`. It raises `SlotError(stage="probe")` only when a timed-out Editor is still holding the folder afterwards — a Unity process the pool could not kill is precisely §7's "a failing probe holds the slot for the operator's `recover-slot`". A gap never raises: the slot is fine and the worker owes the report.
  - `SlotPool(..., run_unsandboxed=None)`, injected so no test in this suite starts a process it did not write. `service.build` passes `launcher.run_unsandboxed`; a pool built without one refuses a batch grant with a `SlotError` rather than silently handing a worker a run that never happened.
  - `dispatch_message(..., resource=None)`. When given, the payload gains a `resource` object with `kind`, `mode`, `slot`, `folder`, `instance`, `mcp_address`, `account`, `commit`, `token_file`, `build_target`, `batch_result` and `results_dir`. **There is no `batch_command` key and no `unity` key, in either mode** — the worker receives neither an argv to run nor the Editor binary to run it with, because it never starts Unity. `batch_result` is the summary `SlotPool.run_batch` wrote, and it is `None` in `interactive` mode.
  - `Scheduler.launch` unchanged in signature and return value.
  - `agent.launcher.write_mcp_config` unchanged in signature; the scheduler hands it a per-runtime server entry rather than one shape for both writers.
  - `agent.deploy.plist(...)` unchanged in signature; the rendered job's `ProcessType` becomes `Standard`.

- [ ] **Step 1: Write the failing tests**

In `tests/test_launcher.py`, the property the whole redesign rests on:

```python
    def test_an_unsandboxed_run_is_the_only_way_out_of_the_seatbelt_and_carries_no_sandbox_config(self):
        """Task 0's addendum: `Unity -batchmode -runTests` inside sandbox_workspace_write hangs for ever on a
        denied Mach lookup — 25 min at 0.0% CPU, no results file — with zero file-permission denials, while
        the same command unsandboxed exits 2 in 19 s. So the batch Editor is started here, not by the worker.
        This asserts the two halves of that: the run really happens, and it writes none of the isolated home,
        CODEX_HOME or sandbox_workspace_write machinery that would put it back inside the seatbelt."""
        launcher = Launcher(Path(self.tmp.name) / "runs", RUNTIMES["fake"], host="test")
        log = Path(self.tmp.name) / "unity-editor.log"
        result = launcher.run_unsandboxed([sys.executable, "-c", "import sys; sys.stderr.write('hi'); "
                                           "sys.exit(2)"], cwd=self.tmp.name, timeout=30, log=log)
        self.assertEqual((result.returncode, result.timed_out), (2, False))
        self.assertIn("hi", log.read_text(encoding="utf-8"))
        self.assertEqual(list((Path(self.tmp.name) / "runs").rglob("config.toml")), [])
        slow = launcher.run_unsandboxed([sys.executable, "-c", "import time; time.sleep(30)"],
                                        cwd=self.tmp.name, timeout=0.5)
        self.assertTrue(slow.timed_out)   # the 25-minute hang must end at a deadline, not at an operator

    def test_an_owned_unsandboxed_run_can_be_killed_by_item_and_takes_its_children_with_it(self):
        """The reachability hole the redesign opened. The batch Editor is a direct child of `serve`, not a
        descendant of any worker — the worker asked for the reservation and exited — so `stop()`'s handle
        lookup and its `descendants` walk both miss it, and `run_batch` is meanwhile blocked in `wait()` for
        up to `batch_timeout`. This asserts the two things that close it: the run is reachable by item id,
        and the kill takes the process GROUP, so a child that outlived its parent dies too. That child is
        the case that matters — it is what would still be holding the slot folder open."""
        launcher = Launcher(Path(self.tmp.name) / "runs", RUNTIMES["fake"], host="test")
        marker = Path(self.tmp.name) / "child.pid"
        # Parent spawns a grandchild that survives it, then sleeps; killing only the parent would leave the
        # grandchild alive, which is precisely the wedged-Editor shape Task 0 measured.
        script = ("import os, subprocess, sys, time, pathlib;"
                  "c = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)']);"
                  "pathlib.Path(sys.argv[1]).write_text(str(c.pid));"
                  "time.sleep(60)")
        started = threading.Event()
        result = {}

        def run():
            started.set()
            result["run"] = launcher.run_unsandboxed([sys.executable, "-c", script, str(marker)],
                                                     cwd=self.tmp.name, timeout=60, owner="itm_batch")
        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        started.wait(5)
        deadline = time.monotonic() + 10
        while not marker.exists() and time.monotonic() < deadline:
            time.sleep(0.05)
        grandchild = int(marker.read_text())

        self.assertTrue(launcher.stop_unsandboxed("itm_batch"))
        thread.join(15)
        self.assertFalse(thread.is_alive())
        self.assertFalse(Launcher.alive(grandchild))          # the group, not just the pid
        self.assertFalse(launcher.stop_unsandboxed("itm_batch"))  # deregistered; idempotent for Stop
```

`tests/test_launcher.py` gains `import threading` for this case if it is not already imported.

In `tests/test_slots.py`, beside `PoolTests`, the pool doing the run the worker is no longer allowed to do:

```python
    def test_the_pool_runs_the_batch_itself_and_hands_the_worker_the_results(self):
        """The worker never starts Unity; the launcher does, outside the sandbox. What the worker gets is
        this summary, and the argv is built from the slot entry alone — nothing the worker supplied."""
        self.pool().ensure()
        item = self.waiting(ISSUE, self.commit("fix"), "batch")
        pool = self.pool(mcp=FakeMcp(), run_unsandboxed=FakeUnity(total=4388, passed=4362, failed=26, code=2))
        self.assertEqual(pool.tick()["granted"], 1)
        argv = pool.run_unsandboxed.argv[-1]
        self.assertNotIn("-quit", argv)
        self.assertEqual(argv[argv.index("-projectPath") + 1], str(self.root / "editors" / "slot-1"))
        summary = json.loads((self.root / "runs" / item / "unity-batch.json").read_text(encoding="utf-8"))
        self.assertEqual((summary["state"], summary["exit_code"]), ("ran", 2))
        self.assertEqual((summary["total"], summary["failed"]), (4388, 26))
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "batch_busy")

    def test_a_batch_run_with_no_results_is_a_verification_gap_and_not_a_slot_failure(self):
        """Task 0 Step 4's trap: `-assemblyNames NoSuchAssembly` exits **0** and writes total="0". The slot is
        fine, so it stays in the pool and the item stays alive; the worker is told it has no evidence."""
        self.pool().ensure()
        item = self.waiting(ISSUE, self.commit("fix"), "batch")
        pool = self.pool(mcp=FakeMcp(), run_unsandboxed=FakeUnity(total=0, passed=0, failed=0, code=0))
        self.assertEqual(pool.tick()["granted"], 1)
        summary = json.loads((self.root / "runs" / item / "unity-batch.json").read_text(encoding="utf-8"))
        self.assertEqual((summary["state"], summary["exit_code"]), ("gap", 0))
        self.assertEqual(self.ledger.item(item)["state"], "queued")
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "batch_busy")

    def test_a_batch_editor_that_outlives_its_timeout_and_still_holds_the_folder_holds_the_slot(self):
        """The 25-minute hang, as the pool would meet it. A deadline is not enough on its own: what decides
        between "gap" and "hold" is whether the process is gone afterwards, which is the same liveness
        question editor_is_open asks and never the lock file."""
        self.pool().ensure()
        item = self.waiting(ISSUE, self.commit("fix"), "batch")
        pool = self.pool(mcp=FakeMcp(), run_unsandboxed=FakeUnity(hang=True),
                         editor_pid=lambda folder: 4242)
        self.assertEqual(pool.tick()["granted"], 0)
        self.assertEqual(self.ledger.slot("unity_slot:1")["state"], "held")
        self.assertEqual(self.ledger.item(item)["state"], "failed")
```

with one more double beside `FakeMcp`:

```python
class FakeUnity:
    """Stands in for `Launcher.run_unsandboxed`. It writes the results file the way the real Editor does —
    before the exit code, and independently of it — because the whole contract is that the file and the code
    disagree. `hang=True` reproduces the addendum's Editor: the deadline expires and nothing is written."""

    def __init__(self, total=0, passed=0, failed=0, code=0, hang=False):
        self.totals, self.code, self.hang, self.argv = (total, passed, failed), code, hang, []

    def __call__(self, argv, *, cwd, timeout, log=None, env=None):
        self.argv.append(list(argv))
        if self.hang:
            return Unsandboxed(returncode=None, timed_out=True, seconds=timeout)
        total, passed, failed = self.totals
        results = Path(argv[argv.index("-testResults") + 1])
        results.parent.mkdir(parents=True, exist_ok=True)
        results.write_text(f'<test-run result="Failed(Child)" total="{total}" passed="{passed}" '
                           f'failed="{failed}" />', encoding="utf-8")
        return Unsandboxed(returncode=self.code, timed_out=False, seconds=1.0)
```

and `SlotFixture.pool` gains one more default, so Task 6's nine `PoolTests` cases keep passing unchanged:

```python
        kwargs.setdefault("run_unsandboxed", FakeUnity(total=4388, passed=4362, failed=26, code=2))
```

In `tests/test_scheduler.py`, inside `SchedulerTests`:

```python
    def test_a_batch_reservation_gives_the_worker_results_and_neither_an_argv_nor_the_slot(self):
        """The worker does not run Unity: under the Codex seatbelt the Editor hangs for ever on a denied Mach
        lookup (Task 0's addendum), so the pool ran it already and this is the evidence. Two absences matter
        as much as the presence — no argv to execute, and no write access to the slot folder."""
        item = self.granted_item(mode="batch")
        self.scheduler.tick()
        item_id, message, servers, _, _ = self.launcher.spawned[-1]
        self.assertEqual((item_id, servers), (item, {}))
        self.assertNotIn(str(self.slot_folder), self.launcher.spawn_writable)
        payload = json.loads(message.split("\n\n", 1)[1])
        self.assertNotIn("batch_command", payload["resource"])
        self.assertNotIn("unity", payload["resource"])   # nor the binary it would have run
        self.assertEqual(payload["resource"]["batch_result"]["total"], 4388)
        self.assertTrue(payload["resource"]["batch_result"]["results_file"].endswith("unity-tests.xml"))

    def test_an_interactive_reservation_injects_the_slot_address_and_not_its_folder(self):
        item = self.granted_item(mode="interactive")
        self.scheduler.tick()
        _, message, servers, _, _ = self.launcher.spawned[-1]
        self.assertEqual(servers, {"unity": {"url": "http://127.0.0.1:8080/mcp"}})
        self.assertNotIn(str(self.slot_folder), self.launcher.spawn_writable)
        payload = json.loads(message.split("\n\n", 1)[1])
        self.assertEqual(payload["resource"]["mode"], "interactive")
        self.assertTrue(payload["resource"]["token_file"].endswith("reservation.token"))
        self.assertNotIn("res_", message)  # the token itself never reaches the prompt on disk
        # No run happened and none is offered: an Editor is live on that folder and run_tests over MCP is
        # the verify path (Task 0 Step 5).
        self.assertIsNone(payload["resource"]["batch_result"])
        self.assertNotIn("batch_command", payload["resource"])
```

In `tests/test_deploy.py`, one assertion that the deployed job does not put Unity in the background band:

```python
    def test_the_serve_agent_runs_in_the_standard_band_so_unity_is_not_throttled(self):
        """Task 0 Step 6: the same EditMode suite took 105 s under launchd's Background band against 14 s
        foreground with warm caches, against a warm-cache control — 7.5x, and a launchd job's band is
        inherited by every process it spawns, which here means the worker and its Editor."""
        job = plistlib.loads(plist("com.kuaiwa.farmbot.serve", ["/bin/true"], "/tmp", "/tmp").encode("utf-8"))
        self.assertEqual(job["ProcessType"], "Standard")
```

`granted_item(mode=..., issue_id=ISSUE)` is a new helper on `SchedulerTests`. It extends the existing `item()` helper: it seeds an issue and a session, creates the work item with a pinned `target` (commit `"a" * 40`, `selected_at` the ISO string), claims it, calls `await_resource(..., "unity_slot", mode)`, calls `ledger.ensure_slot("unity_slot:1", kind="unity_slot", host="test", folder=self.slot_folder, mcp_address="http://127.0.0.1:8080/mcp", instance="slot-1@0123456789abcdef")`, calls `ledger.acquire("unity_slot", owner="pool", host="test")`, sets the slot to the mode's busy state (`interactive_busy` or `batch_busy`) and then `ledger.resume` — leaving the item queued with an active reservation on a busy slot, which is exactly the state the pool leaves behind. That `set_slot_state` stands in for `SlotPool.switch`, which is what writes the busy state in production: `acquire` alone leaves the slot `switching`, no pool thread runs in `tests/test_scheduler.py`, and Task 9's ordering test reads that state back. It sets `self.slot_folder` (a real temporary directory holding `ProjectSettings/ProjectVersion.txt`) and `self.unity_binary` (a touched file, passed as the slot entry's `unity` override). Neither is read by the scheduler any more — after this task `agent/scheduler.py` resolves no Editor — but both keep the slot entry honest and stop any later change quietly reaching into `/Applications`. In `batch` mode it also writes `<state_dir>/unity-batch.json` with `{"state": "ran", "exit_code": 2, "total": 4388, "passed": 4362, "failed": 26, "results_file": "<state_dir>/unity-tests.xml", ...}` — the summary `SlotPool.run_batch` leaves behind in production, and the reason a fresh batch worker has evidence at all. `waiting_item(mode=...)`, used by Task 9, stops one step earlier: it never acquires, so the reservation stays `queued`.

In `tests/test_dispatch.py`. The module's existing tests build their dicts inline, so this one does too rather than depending on names that are not there:

```python
    def test_a_resource_block_names_the_slot_and_the_token_file_but_never_the_token(self):
        message = dispatch_message(item={"id": "i-1", "skill": "fix", "identifier": "FARM-1",
                                         "target": None, "checkpoint": {}, "evidence": {}},
                                   issue={"identifier": "FARM-1", "title": "t", "description": "",
                                          "url": "u", "labels": [], "comments": []},
                                   skill_path="/skills/fix/SKILL.md", worktrees={"Farm-Client": "/w"},
                                   db_path="/db", runtime="codex", guidance="",
                                   budget={"max_hours": 2, "max_usd": 5},
                                   resource={"kind": "unity_slot", "mode": "batch", "slot": "unity_slot:1",
                                             "folder": "/e/slot-1", "commit": "a" * 40, "instance": None,
                                             "account": None, "mcp_address": "http://127.0.0.1:8080/mcp",
                                             "token_file": "/runs/i/reservation.token",
                                             "build_target": "OSXUniversal",
                                             "batch_result": {"state": "ran", "exit_code": 2, "total": 4388,
                                                              "passed": 4362, "failed": 26,
                                                              "results_file": "/runs/i/unity-tests.xml"},
                                             "results_dir": "/runs/i"})
        payload = json.loads(message.split("\n\n", 1)[1])
        self.assertEqual(payload["resource"]["slot"], "unity_slot:1")
        self.assertEqual(payload["resource"]["batch_result"]["failed"], 26)
        # A worker is handed evidence, never a way to produce it: no argv and no Editor path.
        self.assertNotIn("batch_command", payload["resource"])
        self.assertNotIn("unity", payload["resource"])
        self.assertNotIn("token_file", json.dumps(payload).replace('"token_file"', ""))  # path only, no value
```

Match the keyword names and the two dict shapes to whatever `tests/test_dispatch.py` already passes; the point of the test is the `resource` block, not a second copy of the existing fixture.

Also in `tests/test_launcher.py`, an injected server entry has to survive **both** writers, because §19's first risk is that the default runtime changes after Task 0:

```python
    def test_an_injected_http_server_is_written_in_each_runtime_s_own_shape(self):
        home = Path(self.tmp.name) / "home"
        home.mkdir()
        toml = write_mcp_config(home, "toml", {"unity": {"url": "http://127.0.0.1:8080/mcp"}}).read_text()
        self.assertIn("[mcp_servers.unity]", toml)
        self.assertIn('url = "http://127.0.0.1:8080/mcp"', toml)
        written = json.loads(write_mcp_config(home, "json",
                                              {"unity": {"type": "http", "url": "http://127.0.0.1:8080/mcp"}}).read_text())
        self.assertEqual(written["mcpServers"]["unity"]["type"], "http")
```

and leave the existing writable-roots assertion as it is. It must **not** grow a slot-folder case: after this task no slot folder is ever passed through `writable`, in either mode, and a test asserting that one can be would document the opposite of the rule.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k reservation -k unsandboxed -k batch -k resource_block -k writable -k runtime_s_own_shape -k standard_band`
Expected: FAIL. `Launcher` has no `run_unsandboxed`, `SlotPool` has no `run_batch`, `dispatch_message()` rejects the `resource` keyword, the scheduler still passes `{}`, and the rendered plist still says `Background`. Count what `-k batch` matches before running it: Task 4's `test_the_batch_command_never_quits_never_drops_graphics_and_never_rewrites_sources` already matches and is expected to pass.

- [ ] **Step 3: Carry the resource in the dispatch payload**

In `agent/dispatch.py`, add `resource=None` to the signature and one line to the payload, after `"target"`:

```python
        "resource": resource,
```

and extend `AUTHORITY` with one sentence:

```python
    "When a resource block is present you hold that reservation for this run only: address the Editor with "
    "the instance id given and release it through the ledger CLI when you are done. You must NEVER start a "
    "Unity process yourself — not against the slot folder, not against a task worktree, not in batchmode "
    "and not through any script or tool that would. Unity cannot run inside your sandbox: it hangs for "
    "ever on a denied Mach lookup and there is no flag you can add that fixes it. The batch run was "
    "already performed for you, outside your sandbox, before you were started; resource.batch_result is "
    "its outcome and resource.batch_result.results_file is the XML. To run tests on an interactive slot, "
    "use the unity MCP server's run_tests tool (it returns a job_id, polls with get_test_job, and has "
    "clear_stuck for a job a domain reload orphaned); to get a fresh batch run, release your reservation "
    "and request a new batch one. A batch run's evidence is that XML, never the exit code: exit 0 means "
    "nothing ran and exit 2 means tests failed, so read total from the file and report a missing, "
    "unparseable or zero-total result — batch_result.state of 'gap' or 'timeout' — as a verification gap "
    "rather than as a pass or a failure. main is known-red at 26 of 4388; those failures are not yours."
```

- [ ] **Step 4: Run the batch outside the worker's sandbox**

In `agent/launcher.py`, beside `spawn` — deliberately beside it, so the two halves of the sandbox decision are one screen apart:

```python
# module level, beside Handle and Finished
Unsandboxed = namedtuple("Unsandboxed", "returncode timed_out seconds")
```

```python
    def run_unsandboxed(self, argv, *, cwd, timeout, log=None, env=None, owner=None):
        """Run one process OUTSIDE the worker seatbelt. This is the only method in FarmBot that does.

        Task 0's sandbox addendum: `Unity -batchmode -runTests` under [sandbox_workspace_write] hangs for
        ever — 25 minutes at 0.0% CPU, log frozen at 2,289 bytes, no results file — because the seatbelt
        denies a Mach lookup for com.apple.hiservices-xpcservice and the Editor blocks instead of exiting.
        There were zero file-permission denials, and Mach service access is not expressible through
        sandbox_workspace_write, so no writable_roots entry can fix it. The same command unsandboxed exits 2
        in 19 s. Hence: the launcher runs the Editor, the worker never does.

        The argv is the caller's, composed from configuration — never anything a worker supplied. Nothing
        here writes an isolated home, a CODEX_HOME or a sandbox table; this is a plain subprocess, and the
        deadline exists because the thing it runs is the thing that was watched hang.

        env=None on purpose: the Editor inherits the service's own environment, including the real HOME, and
        Task 0 Steps 3 and 6 measured licensing resolving under exactly that — foreground and under launchd.
        """
        start = time.monotonic()
        handle = open(log, "w", encoding="utf-8") if log else subprocess.DEVNULL
        kwargs = {"start_new_session": True} if os.name != "nt" else {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
        try:
            process = subprocess.Popen([str(part) for part in argv], cwd=str(cwd), env=env,
                                       stdin=subprocess.DEVNULL, stdout=handle, stderr=subprocess.STDOUT,
                                       **kwargs)
            # Registered under the item, because this process is the one thing in FarmBot that nothing else
            # can reach. The worker that asked for the run has already exited; the Editor is a direct child
            # of `serve`, not a descendant of any worker, so `Launcher.stop`'s handle lookup and its
            # `descendants` walk both miss it entirely. Without this line a Stop leaves a real Editor running
            # for the rest of `batch_timeout` on a cancelled item, and a `serve` shutdown orphans it holding
            # the slot folder — the exact outcome Task 9 is named after preventing.
            if owner is not None:
                with self._unsandboxed_lock:
                    self._unsandboxed[owner] = process
            try:
                return Unsandboxed(process.wait(timeout=timeout), False, time.monotonic() - start)
            except subprocess.TimeoutExpired:
                # Take the group, not the pid: a hung Editor has children, and leaving them holding the slot
                # folder is what turns a gap into a held slot. `start_new_session=True` above made this pid a
                # process-group leader precisely so this call can exist; `kill_pid` walks `ps` for
                # descendants, which misses anything Unity re-parented on its way down.
                self.kill_group(process.pid)
                return Unsandboxed(None, True, time.monotonic() - start)
        finally:
            if owner is not None:
                with self._unsandboxed_lock:
                    self._unsandboxed.pop(owner, None)
            if log:
                handle.close()

    def kill_group(self, pid, grace=5.0):
        """SIGTERM the whole process group, then SIGKILL what is left.

        `kill_pid` exists beside this and is the wrong tool here: it walks `ps` for descendants, which sees
        only processes still parented to `pid`. A Unity Editor that is wedged — the case Task 0 measured,
        25 minutes at 0.0% CPU — leaves children that may have been re-parented, and those are exactly the
        ones still holding the slot folder open. Every process this method exists to kill was started by
        `run_unsandboxed` with `start_new_session=True`, so the pid is its own group leader and the group is
        the honest unit. Mirrors the killpg pair `stop()` already uses at agent/launcher.py:216 and :226.
        """
        try:
            group = os.getpgid(pid)
        except (ProcessLookupError, PermissionError):
            return
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(group, sig)
            except ProcessLookupError:
                return
            deadline = time.monotonic() + (grace if sig is signal.SIGTERM else 1.0)
            while time.monotonic() < deadline:
                if not self.alive(pid):
                    return
                time.sleep(0.05)

    def stop_unsandboxed(self, owner):
        """Kill the unsandboxed run registered for this item, if one is in flight. Returns True if it was.

        The reachability fix. `stop()` resolves `self._handles`, which `spawn` populates — and the batch
        Editor never went through `spawn`. So Stop, service shutdown and `recover-slot` all had no way to
        touch it, while `SlotPool.run_batch` sat in `process.wait(timeout=batch_timeout)` for up to half an
        hour on the pool thread. Both callers reach it through here.
        """
        with self._unsandboxed_lock:
            process = self._unsandboxed.get(owner)
        if process is None or process.poll() is not None:
            return False
        self.kill_group(process.pid)
        return True

    def stop_all_unsandboxed(self):
        """Every in-flight unsandboxed run, for service shutdown. The pool thread is a daemon, so without
        this an Editor outlives the process that started it and keeps the slot folder open across a
        restart — which the next `ensure` then reads as a slot another Editor already holds."""
        with self._unsandboxed_lock:
            owners = list(self._unsandboxed)
        return [owner for owner in owners if self.stop_unsandboxed(owner)]
```

`Launcher.__init__` gains the two attributes these need, beside the existing `self._handles = {}` and
`self._stopping = {}`:

```python
        self._unsandboxed = {}
        self._unsandboxed_lock = threading.Lock()
```

and `agent/launcher.py` gains `import threading` — the module does not import it today, and this is the
first thing in it touched from two threads at once: `run_unsandboxed` registers from the pool thread while
`Scheduler.stop` reads from the scheduler thread. `signal` and `os` are already imported.

In `agent/slots.py`, add the run and call it from `_hand_over`. `__init__` gains `self.run_unsandboxed = run_unsandboxed`:

```python
    def run_batch(self, slot, reservation):
        """The batch run itself, performed by the launcher outside any sandbox and never by the worker.

        The argv comes from the slot entry and the item's state directory only. That is the security
        property this redesign rests on: exactly one process in FarmBot escapes the seatbelt, and no part of
        its command line is a value a worker chose.
        """
        if self.run_unsandboxed is None:
            raise SlotError(f"{slot['slot_id']}: no unsandboxed runner; a batch slot cannot be granted",
                            stage="editor")
        entry = self.entries.get(slot["slot_id"], DEFAULTS)
        state_dir = Path(self.state_dir(reservation["item_id"]))
        state_dir.mkdir(parents=True, exist_ok=True)
        results, log = state_dir / "unity-tests.xml", state_dir / "unity-editor.log"
        results.unlink(missing_ok=True)   # never let a previous run's file be read as this run's evidence
        try:
            editor = agent.unity.editor_path(slot["folder"], override=entry.get("unity"))
        except agent.unity.UnityError as exc:
            # The message names every path tried. One re-queue at the tail is wasted on a misconfigured
            # host, and the second failure records the paths where an operator will read them.
            raise SlotError(f"{slot['slot_id']}: {exc}", stage="editor") from exc
        argv = agent.unity.batch_test_command(
            editor, slot["folder"], results=results, log=log,
            test_platform=entry.get("test_platform", "EditMode"),
            assemblies=tuple(entry.get("test_assemblies", ())),
            build_target=entry.get("build_target_argument"))
        # log=None: the Editor's own -logFile already points at `log`, and a second capture of the same
        # stream would give the worker two files that disagree about where the run stopped.
        # owner=: the only thread that could otherwise reach this Editor is this one, and it is about to
        # block in `wait()` for up to `batch_timeout`. Registering it under the item is what lets
        # `Scheduler.stop` and a service shutdown kill it (Task 7's `stop_unsandboxed`).
        run = self.run_unsandboxed(argv, cwd=slot["folder"], timeout=entry["batch_timeout"], log=None,
                                   owner=reservation["item_id"])
        summary = {"state": "ran", "exit_code": run.returncode, "seconds": round(run.seconds, 1),
                   "results_file": str(results), "log_file": str(log),
                   "total": None, "passed": None, "failed": None, "result": None}
        try:
            # Task 0 Step 4, the contract: the exit code is advisory and actively misleading — exit 0 means
            # *nothing ran*. The file decides, and total == 0 is a verification gap, not a pass.
            summary.update(agent.unity.read_results(results))
            if summary["total"] == 0:
                summary["state"] = "gap"
        except agent.unity.UnityError as exc:
            summary.update({"state": "gap", "result": str(exc)[:200]})
        if run.timed_out:
            summary["state"] = "timeout"
        # Written before the raise below, not after it: the operator who reads a held slot needs the record
        # of what happened on it, and a summary that only exists on the happy path is the one nobody has.
        (state_dir / "unity-batch.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        if run.timed_out:
            self.clear_stale_lock(slot["folder"], lambda: self.editor_pid(slot["folder"]) is not None)
            if self.editor_pid(slot["folder"]) is not None:
                # A Unity the pool could not kill still holds the folder. Spec §7: a failing probe holds the
                # slot for the operator's recover-slot; there is no second slot to try.
                raise SlotError(f"{slot['slot_id']}: the batch Editor outlived its "
                                f"{entry['batch_timeout']}s deadline and still holds the folder",
                                stage="probe")
        return summary
```

and in `_hand_over`, immediately after the `switch` succeeds:

```python
        if reservation["mode"] == "batch":
            try:
                self.run_batch(self.ledger.slot(slot_id), reservation)
            except SlotError as exc:
                self._switch_failed(reservation, exc)
                return False
```

Add `"batch_timeout": 1800` to `DEFAULTS` — 19 s measured for the EditMode suite (Task 0 Step 4) and 105 s for the same suite under launchd's Background band, so half an hour is headroom of two orders of magnitude and still ends the hang the addendum watched run past 25 minutes. Add `import json` and `import agent.unity` to the module if they are not already there.

A `gap` and a `timeout` are deliberately **not** failures of the switch: `run_batch` returns the summary and the item goes on to its worker, which reports the gap. Only an Editor that survived its own kill raises, because that is the one case where the *slot* is the problem.

- [ ] **Step 5: Build the servers and the resource block from the reservation**

In `agent/scheduler.py`, inside `launch`, after `paths = self._worktrees_for(...)`:

```python
        reservation = self.ledger.active_reservation(item["id"])
        servers, slot, resource = {}, None, None
        if reservation is not None and reservation["kind"] in skill.resources:
            slot = self.ledger.slot(reservation["resource"])
            entry = self.slot_entries.get(slot["slot_id"], {})
            state_dir = self.launcher.state_dir(item["id"])
            resource = {"kind": reservation["kind"], "mode": reservation["mode"], "slot": slot["slot_id"],
                        "folder": slot["folder"], "instance": slot["instance"], "account": slot["account"],
                        "mcp_address": slot["mcp_address"], "commit": reservation["commit_sha"],
                        "token_file": str(Path(state_dir) / "reservation.token"),
                        # No `unity` key. A worker that may never start the Editor has no use for its path,
                        # and handing it one would be an instruction the AUTHORITY block then has to argue
                        # against. Resolving the binary is the pool's job now, in run_batch and open_editor.
                        "build_target": entry.get("build_target_argument"),
                        # The outcome of the run the POOL already performed through the launcher, outside
                        # this worker's sandbox — never an argv for the worker to execute. Unity cannot run
                        # inside sandbox_workspace_write at all: it hangs on a denied Mach lookup with no
                        # file-permission denial to fix (Task 0's addendum). None on an interactive slot,
                        # where run_tests over MCP is the verify path (Task 0 Step 5).
                        "batch_result": (self._batch_result(state_dir)
                                         if reservation["mode"] == "batch" else None),
                        "results_dir": str(state_dir)}
            if reservation["mode"] == "interactive":
                # Enforcement is tool injection (spec §7): the server exists for this worker only while the
                # reservation is held, and the worker pins its own MCP session with set_active_instance.
                # The shape is the runtime's, not one guess for both: write_mcp_config's JSON writer emits
                # mcpServers, where an entry without a type is not an HTTP server.
                servers["unity"] = ({"url": slot["mcp_address"]}
                                    if self.launcher.runtime.mcp_format == "toml"
                                    else {"type": "http", "url": slot["mcp_address"]})
```

with one small reader beside `launch`:

```python
    @staticmethod
    def _batch_result(state_dir):
        """What the pool's own run left behind. Missing is itself a verification gap the worker must report,
        so it is represented rather than dropped — a batch worker with no `batch_result` key at all would
        read as "no slot" instead of "no evidence"."""
        try:
            return json.loads((Path(state_dir) / "unity-batch.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {"state": "gap", "exit_code": None, "results_file": None,
                    "result": "the pool recorded no batch run for this reservation"}
```

then pass `resource=resource` to `dispatch_message` and `servers` instead of `{}` to `spawn`. **The `writable` list does not change at all**, and that is the point: no slot folder and no Unity host path is ever added to a worker's roots, in either mode. The worker reads the results XML in its own state directory, which `Launcher.spawn` already makes writable, and writes nothing in the slot.

`Scheduler.__init__` gains `slot_entries=None` (a `{slot_id: entry}` map, `{}` by default), which `service.build` fills from the same `slot_entry(raw)` list it hands the pool — a one-line change in `agent/service.py`, staged in this task's commit rather than left for a later one. `service.build` also hands `SlotPool` the launcher's own runner — `run_unsandboxed=launcher.run_unsandboxed`, on the same construction that already passes `state_dir=launcher.state_dir`. After this task `agent/scheduler.py` imports nothing from `agent/unity.py` at all: it names no Unity binary, no host path and no argv, which is the plainest statement of where the Editor is started and where it is not.

Finally, in `agent/deploy.py`, one line in `plist`:

```python
        # Standard, not Background. A launchd job's scheduling band is inherited by everything it spawns,
        # and Task 0 Step 6 measured the same EditMode suite at 105 s under Background against 14 s
        # foreground with warm caches — 7.5x, against a warm-cache control, so it is the band and not the
        # cache. A slot switch, an import and a test run each pay it.
        "ProcessType": "Standard",
```

- [ ] **Step 6: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k reservation -k unsandboxed -k batch -k resource_block -k writable -k runtime_s_own_shape -k standard_band`
Expected: PASS. Nine new tests — one in `tests/test_launcher.py` (`run_unsandboxed`), three in `tests/test_slots.py` (the run, the gap, the timeout), two in `tests/test_scheduler.py`, one in `tests/test_dispatch.py`, one more in `tests/test_launcher.py` (the two writer shapes) and one in `tests/test_deploy.py` — plus whatever the substrings already match, including Task 4's batch-command test and Task 6's nine `PoolTests` cases, which stay green on the `run_unsandboxed` default added to `SlotFixture.pool`.

- [ ] **Step 7: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 205 tests (+10).

```bash
git add agent/launcher.py agent/slots.py agent/scheduler.py agent/dispatch.py agent/service.py agent/deploy.py \
        tests/test_launcher.py tests/test_slots.py tests/test_scheduler.py tests/test_dispatch.py tests/test_deploy.py
git commit -m "feat(scheduler): run the batch in the launcher and inject tools from the reservation

A Unity batch run cannot happen inside a worker's sandbox: measured, the Editor hangs
for ever on a denied Mach lookup with no file-permission denial to fix. So the pool
composes the argv from the slot's own configuration and the launcher runs it outside
the seatbelt, and the worker is handed the results file, the parsed totals and the
exit code as evidence. A worker now gets no argv, no Editor path and no write access
to the slot in either mode; an interactive reservation still injects exactly one MCP
server for the life of that run. The serve agent also leaves launchd's background
band: the same EditMode suite costs 7.5x there, and a job's band is inherited by
every Editor it spawns.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

