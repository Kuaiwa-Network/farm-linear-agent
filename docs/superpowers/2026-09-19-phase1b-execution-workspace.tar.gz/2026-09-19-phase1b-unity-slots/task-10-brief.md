### Task 10: Two items serialize on the one slot, offline

The task whose only purpose is to prove Phase 1 done-criterion 3. It runs with the `fake` runtime, the Linear stub and a fake slot pool collaborator, drives the receiver and the scheduler in-process, and needs no webhook, no tunnel and no Unity.

**Why:** criterion 3 is a claim about ordering under contention, and ordering under contention is exactly what a live rehearsal demonstrates least reliably. The offline test is the regression guard; Task 11 is the evidence that the same code drives a real Editor.

**Files:**
- Modify: `tests/test_end_to_end.py` (extract the fixture into a mixin; add `TwoPhaseTests`)
- Modify: `agent/config.py` (`StubLinear.fetch_issue` answers `issue-<ref>.json` when it exists)
- Modify: `tests/fake_cli.py` (pick the `:resumed` script when the launch message carries a `resource` block)
- Test: itself

**Interfaces:**
- Consumes: `build(config)`, which now returns a `pool`; `tests/fake_cli.py`'s `cli` mode and its `FAKE_CLI_STEPS`; the `RUNTIMES["fake"]` runtime; `FakeUnity` from `tests/test_slots.py`, imported rather than copied so the double that stands in for the Editor is the same one everywhere.
- Produces: no production **behaviour**. Two test classes over one shared fixture, plus one line in `agent.config.StubLinear.fetch_issue` — which lives in `agent/` but is the offline Linear double, reached only when the config names the `stub` API, and therefore test scaffolding wherever it sits. Nothing on a real Linear path changes.

**Three things the fixture has to get right**, each of which the obvious version gets wrong:

- **The shared fixture is a mixin, not a base `TestCase`.** Subclassing `EndToEndTests` would re-run its two heavyweight, timing-sensitive tests a second time under a setUp that has built a real slot worktree and a pool — duplicated work for no coverage, and two tests the totals would not account for. The setup moves into a plain `Fixture` class that does not derive from `TestCase`, and `EndToEndTests` and `TwoPhaseTests` both use it.
- **The stub has to answer per issue.** `agent.config.StubLinear.fetch_issue` ignores its argument and always returns `issue.json`, so two `enqueue` calls would observe the same issue row and the second `create_work_item` would raise `an active work item already exists for this issue`. The stub gains one line: it reads `issue-<ref>.json` when that file exists and falls back to `issue.json` otherwise, and the fixture writes one file per issue. The test then asserts the two items really do carry different `issue_id`s.
- **The proof is durable evidence, not a collaborator's call log.** A batch switch calls the MCP zero times by design (Task 4 asserts exactly that), and `park` never calls it either, so a recording double can only ever see the interactive commit — an assertion like `mcp.switched == [commit_a, commit_b, main]` is unsatisfiable and an executor would "fix" the proof rather than the system. Criterion 3 is asserted against the reservations table, `slots.parked_commit`, the audit trail and `Worktrees.head` sampled at each stage.
- **The unsandboxed runner is substituted too, for the same reason the MCP is.** `service.build` hands the real pool `launcher.run_unsandboxed`, and after Task 7 a batch grant calls it — so a fixture that replaced only `mcp` would start a real Editor from the end-to-end suite, against the global constraint that no test in this suite starts Unity. The fixture replaces both, and its slot entry carries a `unity` override pointing at a touched file so `editor_path` never looks in `/Applications` either.

- [ ] **Step 1: Write the failing tests**

In `tests/test_end_to_end.py`, extract the existing `setUp` body into `class Fixture:` (a plain object with a `build_environment(self)` method — it takes no arguments, because it uses `self.addCleanup` and builds its own temporary root), leave `EndToEndTests` calling it, and add a second class. The fixture gains a real slot: a bare clone, an editors root, one configured slot entry, and a `SlotPool` whose `mcp` is `RecordingMcp`. Each item gets its own `FAKE_CLI_STEPS`, selected through one script that reads `FARMBOT_ITEM_ID`.

```python
class TwoPhaseTests(unittest.TestCase, Fixture):
    def setUp(self):
        self.build_environment()   # the mixin's own method; it uses self.addCleanup, so it needs a TestCase
        self.pool = self.c.pool
        self.pool.mcp = RecordingMcp()
        # Both collaborators, not just the MCP: after Task 7 a batch grant calls run_unsandboxed, and the one
        # build() supplied is the real launcher's. FakeUnity writes the results file the way a real batch run
        # does, so `resource.batch_result` reaches the resumed fake worker exactly as it would in production.
        self.pool.run_unsandboxed = FakeUnity(total=4388, passed=4362, failed=26, code=2)
        self.pool.ensure()
        self.commit_a = self.new_commit("a")
        self.commit_b = self.new_commit("b")
        self.folder = Path(self.c.ledger.slot("unity_slot:1")["folder"])
        self.heads = []

    def drain(self, timeout=60):
        """One turn of the three loops serve() runs, in this thread, in the order serve() starts them —
        yielding *between* the scheduler and the pool, because pool.tick() settles and grants in one call and
        a transient state observed only after it would never be seen."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            self.c.receiver.process_one()
            self.c.scheduler.tick()
            yield "before_pool"
            self.pool.tick()
            self.heads.append(self.c.worktrees.head(self.folder))
            yield "after_pool"
            time.sleep(0.1)
        self.fail(f"the loops did not reach a terminal state within {timeout}s")

    def terminal(self, item_id):
        return self.c.ledger.item(item_id)["state"] in ("blocked", "delivered", "failed", "cancelled")

    def test_two_items_needing_unity_serialize_on_the_single_slot(self):
        first = self.enqueue_item(ISSUE, mode="batch", commit=self.commit_a)
        second = self.enqueue_item(OTHER, mode="interactive", commit=self.commit_b)
        self.assertNotEqual(self.c.ledger.item(first)["issue_id"], self.c.ledger.item(second)["issue_id"])
        for phase in self.drain():
            if phase == "before_pool" and self.terminal(first) and not self.terminal(second):
                # Observed between the scheduler and the pool: the first item is done and the second is still
                # waiting, which is the only window in which that pair of states exists.
                self.assertEqual(self.c.ledger.item(second)["state"], "awaiting_resource")
                break
        for _ in self.drain():
            if self.terminal(first) and self.terminal(second):
                break
        # Durable evidence: exactly two reservations were ever acquired, in arrival order, never overlapping.
        acquired = [r for r in self.c.ledger.reservations() if r["acquired_at"] is not None]
        self.assertEqual([(r["item_id"], r["mode"]) for r in acquired],
                         [(first, "batch"), (second, "interactive")])
        self.assertLessEqual(acquired[0]["released_at"], acquired[1]["acquired_at"])

    def test_the_slot_visits_each_pinned_commit_and_is_parked_back_on_main(self):
        first = self.enqueue_item(ISSUE, mode="batch", commit=self.commit_a)
        second = self.enqueue_item(OTHER, mode="interactive", commit=self.commit_b)
        for _ in self.drain():
            if self.terminal(first) and self.terminal(second):
                break
        main = self.c.worktrees.resolve_commit("Farm-Client")
        # The batch item visited commit_a, the interactive item commit_b, and the slot ended on main. `heads`
        # is git's own answer sampled after every pool tick, so no collaborator has to have been told. The
        # last three distinct values are asserted because the first ticks happen while the slot is still
        # parked on main, before either worker has asked for it.
        observed = [h for i, h in enumerate(self.heads) if i == 0 or h != self.heads[i - 1]]
        self.assertEqual(observed[-3:], [self.commit_a, self.commit_b, main])
        parked = [row["reason"] for row in self.c.ledger.connection.execute(
            "SELECT reason FROM audit WHERE item_id='unity_slot:1' AND kind='slot'")]
        self.assertEqual(parked[-1], "idle_open")   # spec §7: after an interactive run the Editor stays open
        slot = self.c.ledger.slot("unity_slot:1")
        self.assertEqual(slot["parked_commit"], main)
        self.assertEqual([o["result"]["aggregate"] for o in self.c.ledger.identity_observations(second)],
                         ["match"])
        self.assertEqual(self.c.ledger.identity_observations(first), [])   # a batch run never probes
```

Two helpers and one double, written out here because the assertions depend on their exact behaviour:

```python
    def new_commit(self, name):
        origin = self.root / "origins" / "Farm-Client"
        (origin / f"{name}.txt").write_text(name, encoding="utf-8")
        git("add", ".", cwd=origin); git("commit", "-qm", name, cwd=origin)
        return subprocess.run(["git", "rev-parse", "HEAD"], cwd=origin, capture_output=True,
                              text=True, check=True).stdout.strip()

    def enqueue_item(self, issue_id, *, mode, commit):
        """One work item created the way a host without a webhook creates them, with its worker's whole
        script decided up front. The first launch asks for the slot and exits; the fresh worker the pool
        resumes gives it back and finishes."""
        (self.stub / f"issue-{issue_id}.json").write_text(
            json.dumps(issue(id=issue_id, labels=["Bug"], delegate_id=APP)), encoding="utf-8")
        item = enqueue(self.c.config, issue_ref=issue_id, skill="fix", commit=commit)
        self.scripts[item["id"]] = [
            ["claim", "--item", "{item}", "--worker-id", "fake"],
            ["await-resource", "--item", "{item}", "--token", "{token}",
             "--resource", "unity_slot", "--mode", mode],
        ]
        self.scripts[item["id"] + ":resumed"] = [
            ["claim", "--item", "{item}", "--worker-id", "fake2"],
            ["release-resource", "--item", "{item}", "--token-file", "{token_file}",
             "--outcome", "quiescent"],
            ["finish", "--item", "{item}", "--token", "{token}", "--outcome", "blocked",
             "--input", str(self.root / "outcome.json")],
        ]
        return item["id"]


class RecordingMcp(FakeMcp):
    """Always matches and is always quiescent, and keeps the lock file honest so the pool's open/closed
    reasoning is the real one. It records nothing the assertions rely on — the evidence is in the ledger."""
```

`FAKE_CLI_STEPS` becomes a map from item id to script, written to the environment by the fixture before each launch; `tests/fake_cli.py` already reads `FARMBOT_ITEM_ID`, and picks `<item>:resumed` when the launch message carries a `resource` block.

- [ ] **Step 2: Run the tests to verify they fail**

Run: `python3 -W error -m unittest discover -s tests -v -k TwoPhase`
Expected: FAIL on the fixture first (`build()` must expose `pool`, Task 6, and `StubLinear.fetch_issue` must answer per ref), then on the ordering assertions.

- [ ] **Step 3: Make the two-phase script work end to end**

The only change outside the test files is the one line in `agent.config.StubLinear.fetch_issue` named in Files, and it is scaffolding for the offline double rather than a behaviour change on any real path. Nothing else should need touching. If a test fails for a reason other than its own fixture, fix the production code and say in the commit body which of Tasks 1 to 9 the gap belonged to — this task exists to find exactly those gaps.

- [ ] **Step 4: Run the tests to verify they pass**

Run: `python3 -W error -m unittest discover -s tests -v -k TwoPhase`
Expected: PASS, two tests. The first proves the serialization, the second proves "switched to each pinned commit and parked back on main afterwards". Confirm they are two and not four: if `TwoPhaseTests` still inherits `EndToEndTests`'s test methods, the extraction into `Fixture` did not happen.

**Both orderings must pass before criterion 3 is marked done.** These two tests run batch first; `PoolTests.test_two_requests_serialize_in_the_other_order_interactive_first_then_batch` (Task 6) covers the reverse, which is the ordering that exercises the graceful close and is the steady state once the Editor stays open. Task 11 Step 4 repeats the live pair in that order.

- [ ] **Step 5: Run the whole suite and commit**

Run: `python3 -W error -m unittest discover -s tests`
Expected: OK, 215 tests (+2).

```bash
git add tests/test_end_to_end.py agent/config.py tests/fake_cli.py
git commit -m "test: two items needing Unity serialize on the single slot

Phase 1 done-criterion 3, offline: one batch item and one interactive item are
granted the one slot in arrival order, the slot visits each item's pinned commit and
is parked back on main afterwards. No webhook, no tunnel and no Editor: the fake
runtime drives the real receiver, scheduler and pool in one process.

Co-Authored-By: <model> <noreply@anthropic.com>"
```

---

