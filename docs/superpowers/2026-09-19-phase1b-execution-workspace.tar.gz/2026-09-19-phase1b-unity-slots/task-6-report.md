# Task 6 report: the pool grants a slot on its own thread and settles it afterwards

Branch `phase1b-tasks-5-11`, on top of 121c249. Suite: **217 → 239**, green and warning-free under
`python3 -W error -m unittest discover -s tests`.

---

## 1. What was implemented

### `agent/ledger.py`
- **`fail_queued`** now accepts an item in `queued` **or** `awaiting_resource`. A switch that fails never
  reaches `resume()`, so the item it has to fail is still waiting for the slot it will not get. Both existing
  callers in `agent/scheduler.py` pass queued items and are unaffected.
- **`requeue_reservation(reservation_id, reason) -> str`**: one more `queued` row at the tail of the queue,
  same item / generation / kind / mode / commit, `attempts + 1`. A new row rather than a reset of the old one,
  because the queue is FIFO by `sequence` and re-opening the original would put a failed attempt back at the
  *head*, ahead of everything that arrived while it was failing.
- **`active_reservation_on(slot_id)`**: the holder of a slot, asked from the slot's side. `park_idle` needs
  this because `release` leaves the slot `switching` and so does `acquire`.
- **`acquire`** now turns the `one_active_owner_per_resource` `sqlite3.IntegrityError` into a `LedgerError`
  naming the slot and its state (carried finding 2, below).

### `agent/slots.py`
- `SlotPool.__init__` gains `state_dir=None, owner="pool"`, `self._departing = {}`, and resolves a `ledger`
  that may be a `Ledger` **or** a zero-argument factory (`self._owns_ledger`).
- `token_path` / `_write_token` (0600, `os.open` with the mode, so the mode is right at creation and not
  after a window) / `_read_token`.
- `tick()` → `{"settled", "granted", "parked"}`, `grant()`, `_hand_over()`, `_switch_failed()`, `settle()`,
  `park_idle()`, `close()`.
- `SlotError.__init__` validates `stage` against `STAGES` (carried finding 1).
- `wait_for_quiet` polls on any collaborator failure, not only `TimeoutError` (carried finding 3).
- `settle`'s batch branch passes `lambda: self.editor_is_open(slot)` to `clear_stale_lock`, not the brief's
  `lambda: False` (defect 3, below).

### `agent/service.py`
- `Components` gains `pool`; `build` constructs it with `lambda: Ledger(paths.ledger, check_same_thread=False)`
  — a factory, never the scheduler's connection.
- `serve` calls `pool.ensure()` inside `try/except SlotError` (logging `slot_pool_unavailable` and serving
  anyway), starts a third daemon thread `guarded("pool", pool_once)` on a 2-second beat, and closes the pool
  in `finally`.

---

## 2. Test names, per file

### `tests/test_slots.py` — `PoolTests` (14 cases incl. subtests; 12 methods)
| test | what it pins |
|---|---|
| `test_a_queued_request_is_granted_switched_and_resumed_for_a_fresh_worker` | grant → switch → token (0600, and the ledger accepts it back, so it really is the reservation's secret) → resume |
| `test_two_requests_serialize_on_the_one_slot_batch_first_then_interactive` | one grant per tick; the identity observation is filed against the item that gets the slot |
| `test_two_requests_serialize_in_the_other_order_interactive_first_then_batch` | `idle_open` after an interactive release, then SIGTERM + lock removal + `reap_server` before the batch grant |
| `test_a_failing_probe_holds_the_slot_and_fails_the_item_without_retrying` | probe stage → `hold` + `fail_queued`, reservation stays `active` |
| `test_a_held_slot_is_not_probed_again_on_the_next_tick` | the next tick is `{0,0,0}` and writes **no audit row** |
| `test_a_slot_is_held_when_the_release_gate_does_not_pass` | 3 subtests: not quiescent / probe raised / token file gone |
| `test_a_stop_between_the_grant_and_the_switch_does_not_kill_the_pool_thread` | `granted=0`, `parked=1`, item cancelled, reservation cancelled, token removed, second tick a no-op |
| `test_a_git_stage_failure_is_requeued_once_at_the_tail_and_fails_the_item_the_second_time` | one retry, at the tail, "verification gap" the second time, two reservation rows |
| `test_a_released_slot_is_parked_back_on_main_when_nothing_is_waiting` | `{settled:1, granted:0, parked:1}` in one tick |
| `test_park_idle_leaves_a_switching_slot_alone_while_a_reservation_still_holds_it` | carried finding 2 |
| `test_a_pool_built_with_a_factory_owns_and_closes_that_connection` | factory called once, closed by `close()`; a borrowed `Ledger` is left open |
| `test_the_pool_grants_from_its_own_thread_while_another_connection_reads` | the grant runs off-thread under `BEGIN IMMEDIATE` while a second connection reads throughout |
| `test_settle_never_deletes_the_lock_of_an_editor_that_is_still_running` | defect 3 |
| `test_a_park_that_cannot_reach_main_holds_the_slot_rather_than_leaving_it_switching` | `park_idle`'s `except SlotError` arm |

Doubles added beside `FakeMcp`: `RaisingQuiescence`, `CancellingMcp`, `BrokenCheckout`, `UnreachableOrigin`.

### `tests/test_slots.py` — `SwitchTests` / `StageTests` (2 new)
- `test_an_editor_that_vanishes_from_the_instance_list_is_waited_for_rather_than_abandoned` — carried finding 3,
  both halves: a transient `SlotError(stage="editor")` is polled through, an `AttributeError` is not.
- `StageTests.test_a_slot_error_refuses_a_stage_that_is_not_one_of_the_four` — carried finding 1.

### `tests/test_ledger.py` — `ReservationTests` (5 new)
- `test_a_mode_preference_is_a_sort_and_never_a_filter` (carried finding 5)
- `test_acquiring_a_slot_a_reservation_still_holds_refuses_as_a_ledger_error` (carried finding 2)
- `test_active_reservation_on_reads_the_holder_of_a_slot_rather_than_of_an_item`
- `test_requeue_reservation_puts_one_more_attempt_at_the_tail_and_refuses_an_open_one`
- `test_fail_queued_accepts_a_waiting_item_and_still_refuses_a_claimed_one`

### `tests/test_service.py` (1 new, 2 edits)
- `test_serve_still_starts_and_keeps_ticking_when_the_slot_pool_cannot_be_prepared` — asserts `/health`
  answers, that `ensure()` really raised, that `slot_pool_unavailable` was logged, **and** that the pool
  thread ticked. `LoopGuardTests`' positional `Components(...)` gained an 11th argument.

### `tests/test_scheduler.py`
- `test_awaiting_resource_stays_parked_in_phase_1a` **renamed** to
  `test_awaiting_resource_is_never_the_schedulers_to_launch` — not deleted. See defect 2.

### `tests/test_end_to_end.py`
- `addCleanup(self.c.pool.close)`: `build` now opens a second connection, and Python 3.13 raises
  `ResourceWarning: unclosed database` for it.

---

## 3. Commands and output

### Failing-first
```
$ python3 -B -W error -m unittest discover -s tests -v -k PoolTests
TypeError: SlotPool.__init__() got an unexpected keyword argument 'state_dir'
Ran 12 tests ... FAILED (errors=14)

$ python3 -B -W error -m unittest discover -s tests -v -k StageTests -k vanishes
AssertionError: ValueError not raised                                      (StageTests)
agent.slots.SlotError: no connected Editor instance reports .../slot-1     (the wait_for_quiet case)
Ran 2 tests ... FAILED (failures=1, errors=1)

$ python3 -B -W error -m unittest discover -s tests -k requeue_reservation -k active_reservation_on \
      -k mode_preference_is_a_sort -k a_reservation_still_holds -k fail_queued_accepts
Ran 6 tests ... FAILED (errors=7)

$ python3 -B -W error -m unittest discover -s tests -k test_service
Ran 5 tests ... FAILED (errors=3)     # AttributeError: 'Components' object has no attribute 'pool'
```

### Selections, after
```
$ python3 -B -W error -m unittest discover -s tests -k PoolTests        → Ran 14 tests  OK
$ python3 -B -W error -m unittest discover -s tests -k StageTests       → Ran  1 test   OK
$ python3 -B -W error -m unittest discover -s tests -k slot_pool        → Ran  1 test   OK
$ python3 -B -W error -m unittest discover -s tests -k ReservationTests → Ran 20 tests  OK
$ python3 -B -W error -m unittest discover -s tests -k test_slots       → Ran 37 tests  OK
$ python3 -B -W error -m unittest discover -s tests -k test_ledger      → Ran 60 tests  OK
```
Every selection matched something; none printed `NO TESTS RAN`.

### Whole suite
```
$ python3 -B -W error -m unittest discover -s tests
Ran 239 tests in 52.546s
OK
```
Baseline before this task was **217**. The brief predicted 195 and a deletion; the real figure is 239 with a
rename. `.local/editors/slot-1` is untouched: still detached at `7d886c72ea3f49fce98b20d7ef19636bd7eabf50`,
working tree clean.

### Mutation checks (all `python3 -B`, reverted after each)
| # | mutation | caught by |
|---|---|---|
| A | `park_idle` drops the `active_reservation_on` guard | `…switching_slot_alone…` (`1 != 0`) |
| B | `park_idle` ignores `_departing` and always parks "batch" | `…interactive_first_then_batch` |
| C | `_hand_over` no longer catches the Stop's `LedgerError` | `…stop_between_the_grant_and_the_switch…` |
| D | `settle` releases instead of holding on a failing gate | 2 failures |
| E | `grant` counts acquisitions rather than hand-overs | `…stop_between…` |
| F | `_switch_failed`'s probe arm never fires | 2 failures |
| G | `settle` no longer holds on a missing token file | `LedgerError: reservation token required` |
| H | `serve` does not start the pool thread | `…cannot_be_prepared` |
| I | `ensure()`'s failure is no longer caught | `…cannot_be_prepared` |
| J | two retries instead of one, and `close()` never closes | 2 failures + the `ResourceWarning` |
| K | `settle` asserts the Editor is gone (`lambda: False`) | `…lock_of_an_editor_that_is_still_running` |
| L | a failed park leaves the slot `switching` | `…holds_the_slot_rather_than_leaving_it_switching` |

---

## 4. Defects found in the brief

**1. `components.launcher.stop_all_unsandboxed()` does not exist — omitted.**
Step 5 asks `serve`'s `finally` to gain

```python
for owner in components.launcher.stop_all_unsandboxed():
    print(json.dumps({"event": "batch_killed_on_shutdown", "item": owner}), flush=True)
```

`Launcher` has no such method. The plan *produces* it in **Task 7** (line 3236: "`Launcher.kill_group`,
`Launcher.stop_unsandboxed`, `Launcher.stop_all_unsandboxed`"), together with `run_unsandboxed`, which is the
only thing that ever registers an owner. So the line is a forward dependency on a method one task away, and
the subject it protects — an unsandboxed batch Editor started by the pool — does not exist yet either. Left
in, it is an `AttributeError` in a `finally` block on **every** shutdown, which fails
`test_serve_answers_health_accepts_a_signed_webhook_and_shuts_down` today.
**Not implemented.** It belongs in Task 7, beside `run_unsandboxed`, where it can be tested against a process
that was really registered. Task 7 must not lose it: without it a `serve` shutdown orphans a real Editor
holding the slot folder.

**2. Deleting `test_awaiting_resource_stays_parked_in_phase_1a` would drop a guard that is still true.**
The brief says the behaviour "stops being true" in this task. It does not. The pool resumes a granted item to
`queued`, and `Scheduler.tick` picks it up from `ledger.queue()` exactly as before — the scheduler still must
not launch an item that is waiting for a slot, and the test exercises the scheduler alone. Only the *name* was
Phase 1a's. **Renamed** to `test_awaiting_resource_is_never_the_schedulers_to_launch` with a docstring saying
why, rather than deleted.

**3. `settle`'s `clear_stale_lock(slot["folder"], lambda: False)` contradicts `clear_stale_lock`'s own
contract, and is reachable.**
The brief justifies `lambda: False` with "the process is confirmed gone by the quiescence check above". That
holds only when there *is* a quiescence check: `settle` sets `quiet = True` without asking anything when
`self.mcp is None`. `clear_stale_lock`'s Task 4 docstring names its callers and states that every one passes a
live check, precisely because "`was_open` is guarded by `self.mcp is not None`, so a pool built without an MCP
client would otherwise assert 'gone' without ever asking" — the identical hole, and Task 4 already has a test
for the two other ways in. Deleting a live Editor's lock loses Unity's one-Editor-per-folder guarantee and
hands the folder to the next `Unity -batchmode`. **Changed** to `lambda: self.editor_is_open(slot)`, covered by
`test_settle_never_deletes_the_lock_of_an_editor_that_is_still_running`, and `clear_stale_lock`'s docstring
updated so it no longer lies about `settle`.

**4. The Stop test's last assertion could not pass.**
`tick()` runs `settle`, `grant` and `park_idle` in one body, so the slot is already back in the pool when the
first call returns; asserting `pool.tick()["parked"] == 1` on a *second* tick reads 0. (The brief half-knew
this: it hedged the preceding assertion with `assertIn(state, ("switching", "idle_closed"))`.) **Rewritten** to
assert `granted == 0` *and* `parked == 1` on the one tick — which is what "the slot comes back to the pool by
itself" means — then `idle_closed`, the token gone, and a genuinely empty second tick.

**5. The `tests/test_service.py` case as written cannot run.**
`Components` is a `namedtuple`, so `components.pool = SimpleNamespace(...)` raises `AttributeError: can't set
attribute`; `self.config`, `self.wait_for_ready` and `_raise` do not exist in `ServeTests`. **Rewritten** using
`self.c._replace(pool=...)` and a local `wait_for_health`, and strengthened: it also asserts that `ensure()`
really raised, that `slot_pool_unavailable` was logged, and that the pool thread ticked — otherwise a `serve`
that never started the third thread would pass.

**6. "the pool calls it once, on the thread that will use it" is not what the code does.**
`build()` runs on the main thread, so the factory is called there. That is fine only because
`check_same_thread=False` is passed, which is exactly what `service.build` does. The comment in the code now
says that instead.

**7. Predicted counts were wrong again** (195 predicted; 217 before, 239 after). Recorded for the pattern.

---

## 5. Carried findings

**`SlotError.STAGES` read by nothing — resolved, but not the way the plan guessed.**
Task 6 is *not* naturally its first reader: `_switch_failed` compares `exc.stage` to literals and never
consults `STAGES`. But that comparison is what makes the constant load-bearing — `stage="prob"` at any raise
site falls through the probe arm and **releases** a slot spec §7 says to hold, silently, on the only slot
there is. `SlotError.__init__` now validates against `STAGES`; all four existing stage literals in `agent/`
were checked first. Covered by `StageTests`.

**`FakeMcp.quiescent` unused — resolved.** `SlotPool.settle` is its first caller, as the plan expected.

**`park_idle` freeing a slot that still carries an active reservation — resolved on both sides.**
`park_idle` skips any slot for which `active_reservation_on` returns a row, so the pool can no longer create
the state (`test_park_idle_leaves_a_switching_slot_alone…`). And `acquire` now surfaces the index violation as
a `LedgerError` naming the slot and its state rather than a raw `sqlite3.IntegrityError` — a caller cannot tell
that one apart from a corrupt database (`test_acquiring_a_slot_a_reservation_still_holds_refuses_as_a_ledger_error`,
which also checks the rollback left the real holder alone). The fence itself was already correct and is
unchanged.

**`wait_for_quiet` catching only `TimeoutError` — fixed.**
The loop now polls on any collaborator failure until the deadline, re-raising `SlotError.FARMBOT_FAULTS`
immediately (a bug in this file answers the same way every second, and the operator needs the type, not a
300-second "never went quiet"). At the deadline a `TimeoutError` still becomes the familiar "still not quiet
after Ns"; anything else goes through `_collaborator_error`, which preserves the farmbot/external blame.
Covered in both directions by `test_an_editor_that_vanishes_from_the_instance_list_is_waited_for_rather_than_abandoned`.

**Memoizing `UnityIdentity._client` — declined, deliberately.**
It does not fall inside this task: Task 6 touches `wait_for_quiet`, not `_client`, and the brief's "only do
this if it falls naturally" condition is not met. It is also not free the way the note assumes. A cache keyed
on `(mcp_address, folder)` outlives `close_editor` and `start`, so after any Editor restart the pool would pin
a **stale instance id** — and `_client`'s whole documented purpose is that the pin is never skipped and never
wrong. Making it safe means invalidating in `close_editor`, in `start`, and in `recover_slot`'s path, which is
a change to Task 4's lifecycle for one saved HTTP round-trip on a fresh slot's poll. Note for whoever takes it:
the invalidation, not the cache, is the work.

**`Ledger.acquire`'s mode preference is a sort, not a filter — now covered.**
`test_a_mode_preference_is_a_sort_and_never_a_filter` asserts both directions (interactive takes the only
`idle_closed` slot; batch takes the only `idle_open` one). It matters more than "uncovered" suggests: on a
one-slot host, turning the preference into a filter would mean an interactive request never runs at all. The
sibling `test_interactive_prefers_an_open_editor_and_batch_prefers_a_closed_one` pins the preference when both
states are available; this one pins what happens when only the unwanted one is.

---

## 6. Self-review

1. **`_hand_over` protects `resume` but not `record_identity` or `_write_token`.** If either raises (a disk
   failure, or a pool built without `state_dir`), the exception escapes `grant()` and `tick()` and the slot is
   left busy with the reservation open — the exact failure the `resume` guard exists to prevent. Left as the
   brief has it: `service.build` always passes `launcher.state_dir`, so the only reachable cause is a disk
   error, and widening the `except` would blur a comment that is specifically about the Stop. Worth a
   `finally`-shaped rewrite if Task 7 adds more work between the switch and the token.
2. **A Stop mid-*interactive*-switch parks the slot as `idle_closed` with the Editor still running.**
   `_departing` is only written by `settle`, so `_hand_over`'s cancel path falls back to `"batch"`. Nothing is
   corrupted — `park` asks the process listing before touching the lock, and both later switch paths ask it
   again — but the slot row is briefly less truthful than it could be. The brief chose this fallback
   deliberately (`park_idle`'s docstring), so it stands; `_departing[slot_id] = reservation["mode"]` on that
   path would be the one-line improvement.
3. **`grant()` only considers kinds that are configured.** A reservation for a kind no longer in
   `config.slots` stays queued for ever with nothing to report it. Out of scope; Task 8's pool view is where
   an operator would see it.
4. **`settle`'s `except Exception` around `quiescent` also swallows FarmBot's own faults** into "probe
   raised `AttributeError`" — which holds the slot, the safe direction, but without the farmbot/external blame
   `switch` draws. Consistent with the brief; a `_collaborator_error`-shaped message would be better and is
   cheap if a reviewer wants it.
5. **Renamed a local `quiet` to `is_quiet` in `settle`**, because `agent.identity.quiet` is imported at module
   level and read by `UnityIdentity.wait_quiet`; the local shadowed the predicate's name.
6. **The threaded test is honest about what it proves.** It runs a real grant — acquire, `git checkout`,
   `resume` — on a second thread with its own connection while the fixture's connection reads throughout, and
   it joins the thread. It would fail on the mutation that matters (drop the factory resolution and
   `self.ledger` is a lambda), and the pre-existing
   `test_two_connections_acquiring_at_once_produce_exactly_one_grant` remains the barrier-based contention
   proof. It is *not* a proof that two threads corrupt one connection — that claim is structural, and the
   honest guard for it is `test_a_pool_built_with_a_factory_owns_and_closes_that_connection`.
7. **No test starts Unity, touches `/Applications`, reaches the network or opens the real ledger.** Unity,
   git-lfs and the MCP stay injected; the new tests shell out to real `git`, use real temp SQLite and real
   threads. Every thread is joined; the one new server-starting test reuses `ServeTests`' server, which is
   both `shutdown()` and `server_close()`d.
8. **A new `ResourceWarning` was exposed and fixed.** Python 3.13 raises it for unclosed `sqlite3`
   connections, and `build()` now opens one more. `tests/test_end_to_end.py` and `tests/test_service.py` both
   close the pool; mutation J confirms the warning returns if `close()` stops closing.

---

# Fix round 1/5 — two Important findings

Suite **239 → 241**, green and warning-free. Commit: see below.

## FINDING 1 — the one-connection-per-thread rule was untested in the production wiring

**What changed.** `tests/test_service.py` gains
`ServeTests.test_build_gives_the_pool_its_own_connection_and_never_the_schedulers`. It asserts, on the
`Components` that `build()` actually returned:

- `self.c.pool.ledger is not self.c.ledger`, and the two `sqlite3.Connection` objects differ;
- and the other half of "it was handed a factory": `pool.close()` closes the pool's connection
  (`sqlite3.ProgrammingError` on use) and leaves the scheduler's open and usable — which is what `serve`'s
  `finally` relies on.

`import sqlite3` added to the file. I took the reviewer's assertion and extended it: `assertIsNot` alone
would still pass a `SlotPool` that borrowed a *different* shared connection or that closed the scheduler's.

**Covering test.** `tests/test_service.py::ServeTests::test_build_gives_the_pool_its_own_connection_and_never_the_schedulers`

**Mutation M — the reviewer's own.** `agent/service.py` `SlotPool(lambda: Ledger(...), ...)` → `SlotPool(ledger, ...)`:

```
$ python3 -B -W error -m unittest discover -s tests -k test_service -k test_end_to_end
    self.assertIsNot(self.c.pool.ledger, self.c.ledger)
AssertionError: unexpectedly identical: <agent.ledger.Ledger object at 0x106dc0b00>
Ran 8 tests in 5.114s
FAILED (failures=1)
```

Before the fix that same selection was 7 tests, OK.

## FINDING 2 — `_hand_over`'s unguarded window could wedge the only slot with no operator signal

**What changed.** Everything after `switch()` now runs inside one `try/finally` in
`agent/slots.py::SlotPool._hand_over`, with two new helpers:

- `_give_the_slot_back(reservation, reason, fail_item)` — releases the reservation, forgets the token, and
  (when the failure was the host's rather than a Stop) calls `fail_queued`, because nothing re-queues the
  reservation and `reservations_to_settle` cannot see an `awaiting_resource` item, so the item would
  otherwise wait for a slot that is never handed to it. `park_idle` returns the slot to main on the same
  pass, so the pool is whole again by the end of the tick that broke it.
- `_forget_token(item_id)` — best effort, because the give-back path runs after a failure that may be the
  very reason the token path cannot be computed (`state_dir=None`) or the file removed.

The Stop path keeps its own arm (`reason="item cancelled mid-switch"`, `fail_item=False`: the item is already
terminal). A real `finally` rather than a chain of `except`s, so a `BaseException` — which `guarded` does not
catch either — also gives the slot back before it propagates; that is why `reason`/`fail_item` carry defaults.

The slot is **released and parked, not held**: the slot itself never misbehaved, the host did, and taking the
only slot out of the pool for a full disk would be the wrong signal. The signal is a failed item carrying
`hand-over failed after the switch: …` in the audit.

**Covering test.**
`tests/test_slots.py::PoolTests::test_a_hand_over_that_fails_after_the_switch_gives_the_slot_back_instead_of_wedging_it`
— two subtests, both real rather than monkeypatched: a `state_dir` under a plain file (`NotADirectoryError`
out of `mkdir`) and `state_dir=None`, which `__init__` accepts today. Each asserts
`tick() == {"settled": 0, "granted": 0, "parked": 1}`, the item `failed`, the reservation `released`, the slot
back at `idle_closed` on main, the reason in the audit, and a clean no-op second tick.

**Mutations (all `python3 -B -W error … -k PoolTests`, 15 tests):**

| # | mutation | result |
|---|---|---|
| N | restore the brief's unguarded window | `FAILED (errors=2)` — `TypeError: 'NoneType' object is not callable` escapes `tick()` |
| O | give the slot back but never `fail_queued` | `FAILED (failures=2)` |
| P | the `finally` never gives the slot back | `FAILED (failures=3)` |

## Whole suite

```
$ python3 -B -W error -m unittest discover -s tests
Ran 241 tests in 52.853s
OK
```

`.local/editors/slot-1` still detached at `7d886c72ea3f49fce98b20d7ef19636bd7eabf50`.

Self-review residual #1 from the first report ("`_hand_over` protects `resume` but not `record_identity` or
`_write_token`") is now closed. The four items the coordinator deferred to the ledger were not touched.
